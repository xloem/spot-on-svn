<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ja_JP">
<context>
    <name>QObject</name>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="186"/>
        <source>gcry_cipher_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="195"/>
        <source>gcry_md_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="204"/>
        <source>gcry_cipher_get_algo_keylen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="254"/>
        <source>gcry_kdf_derive() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="407"/>
        <source>gcry_md_get_algo_dlen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="377"/>
        <source>empty passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="369"/>
        <source>empty hashType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="385"/>
        <source>empty salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="395"/>
        <source>gcry_md_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1653"/>
        <source>gcry_sexp_build() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1677"/>
        <source>gcry_pk_genkey() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1705"/>
        <source>gcry_sexp_find_token() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1716"/>
        <location filename="../Common/spot-on-crypt.cc" line="1731"/>
        <source>gcry_sexp_sprint() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1749"/>
        <source>malloc() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1789"/>
        <source>QSqlQuery::exec() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1798"/>
        <source>encrypted() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2544"/>
        <source>BN_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2552"/>
        <source>BN_set_word() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2560"/>
        <source>RSA_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2568"/>
        <source>RSA_generate_key_ex() returned negative one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2576"/>
        <location filename="../Common/spot-on-crypt.cc" line="2584"/>
        <location filename="../Common/spot-on-crypt.cc" line="2836"/>
        <source>BIO_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2592"/>
        <source>PEM_write_bio_RSAPrivateKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2600"/>
        <source>PEM_write_bio_RSAPublicKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2611"/>
        <location filename="../Common/spot-on-crypt.cc" line="2625"/>
        <location filename="../Common/spot-on-crypt.cc" line="2755"/>
        <location filename="../Common/spot-on-crypt.cc" line="2855"/>
        <source>calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2689"/>
        <source>rsa container is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2697"/>
        <source>EVP_PKEY_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2706"/>
        <source>X509_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2715"/>
        <source>EVP_PKEY_assign_RSA() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2727"/>
        <source>X509_set_version() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2735"/>
        <location filename="../Common/spot-on-crypt.cc" line="2743"/>
        <source>X509_gmtime_adj() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2772"/>
        <source>X509_NAME_ENTRY_create_by_NID() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2782"/>
        <source>X509_NAME_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2790"/>
        <source>X509_NAME_add_entry() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2798"/>
        <source>X509_set_subject_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2808"/>
        <source>X509_set_issuer_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2816"/>
        <source>X509_set_pubkey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2824"/>
        <source>X509_sign() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2844"/>
        <source>PEM_write_bio_X509() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3165"/>
        <source>newCrypt is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3173"/>
        <source>oldCrypt is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3239"/>
        <source>decryption or encryption failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="120"/>
        <source>Re-encoding email.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="58"/>
        <source>Re-encoding buzz_channels.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="280"/>
        <source>Re-encoding friends_public_keys.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="350"/>
        <source>Re-encoding listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="661"/>
        <source>Re-encoding neighbors.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="994"/>
        <source>Re-encoding starbeam.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1020"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>buzzPage</name>
    <message>
        <location filename="../UI/buzzpage.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="61"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="75"/>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="47"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="32"/>
        <source>Please be considerate of others and announce your departure. Departure notifications are not immediate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="68"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="88"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="118"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="141"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="166"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="171"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="176"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="220"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="240"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="245"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="292"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chatwindow</name>
    <message>
        <location filename="../UI/chatwindow.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="36"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="43"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="63"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="106"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>passwordprompt</name>
    <message>
        <location filename="../UI/passwordprompt.ui" line="14"/>
        <source>Spot-On: Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="30"/>
        <source>Please provide the following credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="42"/>
        <source>Account &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="55"/>
        <source>Account &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton</name>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="880"/>
        <location filename="../GUI/spot-on-a.cc" line="4923"/>
        <source>Not connected to the kernel. Is the kernel active?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2609"/>
        <location filename="../GUI/spot-on-a.cc" line="2611"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3103"/>
        <source>The sticky feature enables an indefinite lifetime for a neighbor.
If not checked, the neighbor will be terminated after some internal timer expires.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3622"/>
        <source>Spot-On: Select Kernel Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3605"/>
        <location filename="../GUI/spot-on-a.cc" line="3625"/>
        <location filename="../GUI/spot-on-c.cc" line="424"/>
        <location filename="../GUI/spot-on-c.cc" line="780"/>
        <location filename="../GUI/spot-on-c.cc" line="2862"/>
        <location filename="../GUI/spot-on-c.cc" line="3054"/>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1553"/>
        <location filename="../GUI/spot-on-a.cc" line="1864"/>
        <location filename="../GUI/spot-on-a.cc" line="1869"/>
        <location filename="../GUI/spot-on-a.cc" line="1882"/>
        <location filename="../GUI/spot-on-a.cc" line="2246"/>
        <location filename="../GUI/spot-on-a.cc" line="2251"/>
        <location filename="../GUI/spot-on-a.cc" line="4007"/>
        <location filename="../GUI/spot-on-a.cc" line="4016"/>
        <location filename="../GUI/spot-on-a.cc" line="4024"/>
        <location filename="../GUI/spot-on-a.cc" line="4236"/>
        <location filename="../GUI/spot-on-a.cc" line="4243"/>
        <location filename="../GUI/spot-on-a.cc" line="4254"/>
        <location filename="../GUI/spot-on-a.cc" line="6574"/>
        <location filename="../GUI/spot-on-a.cc" line="6587"/>
        <location filename="../GUI/spot-on-a.cc" line="6661"/>
        <location filename="../GUI/spot-on-a.cc" line="6923"/>
        <location filename="../GUI/spot-on-a.cc" line="6971"/>
        <location filename="../GUI/spot-on-b.cc" line="139"/>
        <location filename="../GUI/spot-on-b.cc" line="1385"/>
        <location filename="../GUI/spot-on-b.cc" line="1392"/>
        <location filename="../GUI/spot-on-b.cc" line="1400"/>
        <location filename="../GUI/spot-on-b.cc" line="1411"/>
        <location filename="../GUI/spot-on-b.cc" line="1425"/>
        <location filename="../GUI/spot-on-b.cc" line="1488"/>
        <location filename="../GUI/spot-on-b.cc" line="1590"/>
        <location filename="../GUI/spot-on-b.cc" line="1597"/>
        <location filename="../GUI/spot-on-b.cc" line="1605"/>
        <location filename="../GUI/spot-on-b.cc" line="1616"/>
        <location filename="../GUI/spot-on-b.cc" line="1651"/>
        <location filename="../GUI/spot-on-b.cc" line="1666"/>
        <location filename="../GUI/spot-on-b.cc" line="1689"/>
        <location filename="../GUI/spot-on-b.cc" line="1697"/>
        <location filename="../GUI/spot-on-b.cc" line="1708"/>
        <location filename="../GUI/spot-on-b.cc" line="1718"/>
        <location filename="../GUI/spot-on-b.cc" line="1733"/>
        <location filename="../GUI/spot-on-b.cc" line="1786"/>
        <location filename="../GUI/spot-on-b.cc" line="1799"/>
        <location filename="../GUI/spot-on-b.cc" line="1811"/>
        <location filename="../GUI/spot-on-b.cc" line="2142"/>
        <location filename="../GUI/spot-on-b.cc" line="2150"/>
        <location filename="../GUI/spot-on-b.cc" line="2914"/>
        <location filename="../GUI/spot-on-b.cc" line="2920"/>
        <location filename="../GUI/spot-on-b.cc" line="2927"/>
        <location filename="../GUI/spot-on-b.cc" line="3348"/>
        <location filename="../GUI/spot-on-b.cc" line="4194"/>
        <location filename="../GUI/spot-on-b.cc" line="4351"/>
        <location filename="../GUI/spot-on-b.cc" line="4372"/>
        <location filename="../GUI/spot-on-b.cc" line="4382"/>
        <location filename="../GUI/spot-on-b.cc" line="4446"/>
        <location filename="../GUI/spot-on-b.cc" line="4456"/>
        <location filename="../GUI/spot-on-b.cc" line="4476"/>
        <location filename="../GUI/spot-on-b.cc" line="4494"/>
        <location filename="../GUI/spot-on-b.cc" line="4703"/>
        <location filename="../GUI/spot-on-b.cc" line="4719"/>
        <location filename="../GUI/spot-on-b.cc" line="4739"/>
        <location filename="../GUI/spot-on-b.cc" line="4749"/>
        <location filename="../GUI/spot-on-c.cc" line="170"/>
        <location filename="../GUI/spot-on-c.cc" line="1002"/>
        <location filename="../GUI/spot-on-c.cc" line="1534"/>
        <location filename="../GUI/spot-on-c.cc" line="1544"/>
        <location filename="../GUI/spot-on-c.cc" line="1593"/>
        <location filename="../GUI/spot-on-c.cc" line="1660"/>
        <location filename="../GUI/spot-on-c.cc" line="1670"/>
        <location filename="../GUI/spot-on-c.cc" line="2221"/>
        <location filename="../GUI/spot-on-c.cc" line="2319"/>
        <location filename="../GUI/spot-on-c.cc" line="2773"/>
        <location filename="../GUI/spot-on-c.cc" line="2942"/>
        <location filename="../GUI/spot-on-c.cc" line="3034"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4008"/>
        <source>The passphrases must contain at least sixteen characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4041"/>
        <location filename="../GUI/spot-on-b.cc" line="560"/>
        <location filename="../GUI/spot-on-b.cc" line="1450"/>
        <location filename="../GUI/spot-on-b.cc" line="1474"/>
        <location filename="../GUI/spot-on-b.cc" line="1507"/>
        <location filename="../GUI/spot-on-b.cc" line="1534"/>
        <location filename="../GUI/spot-on-b.cc" line="1883"/>
        <location filename="../GUI/spot-on-b.cc" line="3275"/>
        <location filename="../GUI/spot-on-b.cc" line="4299"/>
        <location filename="../GUI/spot-on-c.cc" line="2235"/>
        <location filename="../GUI/spot-on-c.cc" line="2788"/>
        <location filename="../GUI/spot-on-c.cc" line="2887"/>
        <location filename="../GUI/spot-on-c.cc" line="3079"/>
        <location filename="../GUI/spot-on-c.cc" line="3619"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4647"/>
        <location filename="../GUI/spot-on-a.cc" line="4774"/>
        <location filename="../GUI/spot-on-a.cc" line="4859"/>
        <location filename="../GUI/spot-on-c.cc" line="2359"/>
        <location filename="../GUI/spot-on-c.cc" line="2393"/>
        <location filename="../GUI/spot-on-c.cc" line="2582"/>
        <source>&amp;Remove participant(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4905"/>
        <source>Connected insecurely to the kernel on port %1 from local port %2. Communications between the interface and the kernel have been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5476"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5478"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5480"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="141"/>
        <location filename="../GUI/spot-on-a.cc" line="144"/>
        <source>Spot-On was configured without libGeoIP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="150"/>
        <location filename="../GUI/spot-on-a.cc" line="153"/>
        <source>Spot-On was configured without libphoton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="882"/>
        <location filename="../GUI/spot-on-a.cc" line="2782"/>
        <source>Listeners are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="883"/>
        <location filename="../GUI/spot-on-a.cc" line="3413"/>
        <source>Neighbors are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="901"/>
        <source>Copy &amp;All Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4700"/>
        <location filename="../GUI/spot-on-c.cc" line="2465"/>
        <source>Share &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1518"/>
        <source>Preparing databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="179"/>
        <location filename="../GUI/spot-on-a.cc" line="180"/>
        <source>SCTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="888"/>
        <source>Copy &amp;Chat Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="891"/>
        <source>Copy &amp;E-Mail Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="894"/>
        <source>Copy &amp;Rosetta Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="897"/>
        <source>Copy &amp;URL Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1579"/>
        <source>Generating SSL data for listener. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1865"/>
        <source>Unable to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1870"/>
        <source>An error (%1) occurred while attempting to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2247"/>
        <source>Unable to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2252"/>
        <source>An error (%1) occurred while attempting to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2450"/>
        <location filename="../GUI/spot-on-a.cc" line="2691"/>
        <location filename="../GUI/spot-on-a.cc" line="2944"/>
        <location filename="../GUI/spot-on-a.cc" line="2972"/>
        <location filename="../GUI/spot-on-a.cc" line="3156"/>
        <location filename="../GUI/spot-on-a.cc" line="3250"/>
        <location filename="../GUI/spot-on-a.cc" line="5504"/>
        <location filename="../GUI/spot-on-b.cc" line="2725"/>
        <location filename="../GUI/spot-on-b.cc" line="2760"/>
        <location filename="../GUI/spot-on-b.cc" line="2843"/>
        <location filename="../GUI/spot-on-b.cc" line="2858"/>
        <location filename="../GUI/spot-on-c.cc" line="244"/>
        <location filename="../GUI/spot-on-c.cc" line="263"/>
        <location filename="../GUI/spot-on-c.cc" line="1152"/>
        <location filename="../GUI/spot-on-c.cc" line="1285"/>
        <location filename="../GUI/spot-on-c.cc" line="1287"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4025"/>
        <source>Please provide a name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4044"/>
        <source>Are you sure that you wish to replace the existing passphrase? Please note that URL data must be re-encoded via a separate tool. Please see the future Tools folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4061"/>
        <source>Generating derived keys. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4117"/>
        <source>Re-encoding public key pair %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4153"/>
        <source>Would you like to generate public key pairs?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4191"/>
        <source>Generating public key %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4237"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4244"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys() or spoton_crypt::reencodePrivatePublicKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4414"/>
        <source>Your confidential information has been saved. You are now ready to use the full power of Spot-On. Enjoy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4641"/>
        <location filename="../GUI/spot-on-c.cc" line="2387"/>
        <source>&amp;Copy keys to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4650"/>
        <location filename="../GUI/spot-on-a.cc" line="4777"/>
        <location filename="../GUI/spot-on-a.cc" line="4862"/>
        <location filename="../GUI/spot-on-c.cc" line="2362"/>
        <location filename="../GUI/spot-on-c.cc" line="2396"/>
        <location filename="../GUI/spot-on-c.cc" line="2585"/>
        <source>&amp;Rename participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4712"/>
        <location filename="../GUI/spot-on-c.cc" line="2477"/>
        <source>&amp;Reset Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4716"/>
        <location filename="../GUI/spot-on-c.cc" line="2481"/>
        <source>&amp;Reset Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4767"/>
        <location filename="../GUI/spot-on-c.cc" line="2352"/>
        <source>&amp;Generate random Gemini pair (AES-256 Key, SHA-512 Key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4795"/>
        <location filename="../GUI/spot-on-a.cc" line="4821"/>
        <location filename="../GUI/spot-on-c.cc" line="2522"/>
        <location filename="../GUI/spot-on-c.cc" line="2549"/>
        <source>&amp;Compute SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4804"/>
        <location filename="../GUI/spot-on-c.cc" line="2531"/>
        <source>Discover &amp;Missing Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4897"/>
        <source>Connected securely to the kernel on port %1 from local port %2 via cipher %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6406"/>
        <source>&lt;b&gt;Cert. Effective Date:&lt;/b&gt; %1&lt;br&gt;&lt;b&gt;Cert. Expiration Date:&lt;/b&gt; %2&lt;br&gt;&lt;b&gt;Cert. Issuer Organization:&lt;/b&gt; %3&lt;br&gt;&lt;b&gt;Cert. Issuer Common Name:&lt;/b&gt; %4&lt;br&gt;&lt;b&gt;Cert. Issuer Locality Name:&lt;/b&gt; %5&lt;br&gt;&lt;b&gt;Cert. Issuer Organizational Unit Name:&lt;/b&gt; %6&lt;br&gt;&lt;b&gt;Cert. Issuer Country Name:&lt;/b&gt; %7&lt;br&gt;&lt;b&gt;Cert. Issuer State or Province Name:&lt;/b&gt; %8&lt;br&gt;&lt;b&gt;Cert. Serial Number:&lt;/b&gt; %9&lt;br&gt;&lt;b&gt;Cert. Subject Organization:&lt;/b&gt; %10&lt;br&gt;&lt;b&gt;Cert. Subject Common Name:&lt;/b&gt; %11&lt;br&gt;&lt;b&gt;Cert. Subject Locality Name:&lt;/b&gt; %12&lt;br&gt;&lt;b&gt;Cert. Subject Organizational Unit Name:&lt;/b&gt; %13&lt;br&gt;&lt;b&gt;Cert. Subject Country Name:&lt;/b&gt; %14&lt;br&gt;&lt;b&gt;Cert. Subject State or Province Name:&lt;/b&gt; %15&lt;br&gt;&lt;b&gt;Cert. Version:&lt;/b&gt; %16&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6588"/>
        <source>Invalid neighbor OID. Please select a neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6827"/>
        <location filename="../GUI/spot-on-a.cc" line="6938"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6918"/>
        <location filename="../GUI/spot-on-b.cc" line="2915"/>
        <location filename="../GUI/spot-on-c.cc" line="157"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6948"/>
        <source>Invalid clipboard object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2775"/>
        <source>There is (are) %1 active listener(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1554"/>
        <location filename="../GUI/spot-on-a.cc" line="1883"/>
        <location filename="../GUI/spot-on-a.cc" line="6575"/>
        <location filename="../GUI/spot-on-a.cc" line="6879"/>
        <location filename="../GUI/spot-on-b.cc" line="4072"/>
        <location filename="../GUI/spot-on-b.cc" line="4352"/>
        <location filename="../GUI/spot-on-b.cc" line="4457"/>
        <location filename="../GUI/spot-on-b.cc" line="4614"/>
        <location filename="../GUI/spot-on-b.cc" line="4720"/>
        <location filename="../GUI/spot-on-c.cc" line="97"/>
        <location filename="../GUI/spot-on-c.cc" line="814"/>
        <location filename="../GUI/spot-on-c.cc" line="1535"/>
        <location filename="../GUI/spot-on-c.cc" line="1661"/>
        <location filename="../GUI/spot-on-c.cc" line="3035"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2464"/>
        <source>Status: %1
SSL Key Size: %2
Local IP: %3 Local Port: %4 Scope ID: %5
External IP: %6
Connections: %7
Echo Mode: %8
Use Accounts: %9
Transport: %10
Share Address: %11
Orientation: %12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2976"/>
        <source>UUID: %1
Status: %2
SSL Key Size: %3
Local IP: %4 Local Port: %5
External IP: %6
Country: %7 Remote IP: %8 Remote Port: %9 Scope ID: %10
Proxy Hostname: %11 Proxy Port: %12
Echo Mode: %13
Communications Mode: %14
Uptime: %15 Minutes
Allow Certificate Exceptions: %16
Bytes Read: %17
Bytes Written: %18
SSL Session Cipher: %19
Account Name: %20
Account Authenticated: %21
Transport: %22
Orientation: %23
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3405"/>
        <source>There is (are) %1 connected neighbor(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3592"/>
        <source>External IP: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3602"/>
        <source>Spot-On: Select GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4017"/>
        <source>The passphrases are not identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4185"/>
        <location filename="../GUI/spot-on-c.cc" line="2262"/>
        <source>Generating public key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4255"/>
        <source>An error (%1) occurred with spoton_crypt::saltedPassphraseHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4800"/>
        <location filename="../GUI/spot-on-a.cc" line="4826"/>
        <location filename="../GUI/spot-on-c.cc" line="2527"/>
        <location filename="../GUI/spot-on-c.cc" line="2553"/>
        <source>&amp;Copy File Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6662"/>
        <source>The account name must be non-empty and the account password must contain at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4667"/>
        <location filename="../GUI/spot-on-c.cc" line="2414"/>
        <source>Detach &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4669"/>
        <location filename="../GUI/spot-on-c.cc" line="2416"/>
        <source>Disconnect &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4672"/>
        <location filename="../GUI/spot-on-c.cc" line="2419"/>
        <source>&amp;Publish Information (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4674"/>
        <location filename="../GUI/spot-on-c.cc" line="2421"/>
        <source>Publish &amp;All (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4709"/>
        <location filename="../GUI/spot-on-c.cc" line="2474"/>
        <source>&amp;Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4727"/>
        <location filename="../GUI/spot-on-c.cc" line="2492"/>
        <source>Delete All Non-Unique &amp;Blocked Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4729"/>
        <location filename="../GUI/spot-on-c.cc" line="2494"/>
        <source>Delete All Non-Unique &amp;UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4732"/>
        <location filename="../GUI/spot-on-c.cc" line="2497"/>
        <source>B&amp;lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4734"/>
        <location filename="../GUI/spot-on-c.cc" line="2499"/>
        <source>U&amp;nblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4677"/>
        <location filename="../GUI/spot-on-a.cc" line="4737"/>
        <location filename="../GUI/spot-on-c.cc" line="2424"/>
        <location filename="../GUI/spot-on-c.cc" line="2502"/>
        <source>&amp;Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4679"/>
        <location filename="../GUI/spot-on-a.cc" line="4739"/>
        <location filename="../GUI/spot-on-c.cc" line="2426"/>
        <location filename="../GUI/spot-on-c.cc" line="2504"/>
        <source>&amp;Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4760"/>
        <location filename="../GUI/spot-on-c.cc" line="2345"/>
        <source>&amp;Call participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4636"/>
        <location filename="../GUI/spot-on-a.cc" line="4757"/>
        <location filename="../GUI/spot-on-a.cc" line="4853"/>
        <location filename="../GUI/spot-on-c.cc" line="2342"/>
        <location filename="../GUI/spot-on-c.cc" line="2382"/>
        <location filename="../GUI/spot-on-c.cc" line="2576"/>
        <source>&amp;Copy Repleo to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4690"/>
        <location filename="../GUI/spot-on-c.cc" line="2455"/>
        <source>Share &amp;Chat Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4695"/>
        <location filename="../GUI/spot-on-c.cc" line="2460"/>
        <source>Share &amp;E-Mail Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4763"/>
        <location filename="../GUI/spot-on-c.cc" line="2348"/>
        <source>&amp;Terminate call.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5482"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5484"/>
        <source>Friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5561"/>
        <location filename="../GUI/spot-on-a.cc" line="5618"/>
        <location filename="../GUI/spot-on-a.cc" line="5663"/>
        <source>User %1 requests your friendship.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4703"/>
        <location filename="../GUI/spot-on-c.cc" line="2468"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1474"/>
        <location filename="../GUI/spot-on-a.cc" line="1478"/>
        <location filename="../GUI/spot-on-a.cc" line="1482"/>
        <source>Broadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4413"/>
        <location filename="../GUI/spot-on-b.cc" line="4591"/>
        <source>Spot-On: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4150"/>
        <location filename="../GUI/spot-on-a.cc" line="4427"/>
        <source>Spot-On: Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4430"/>
        <source>Would you like the kernel to be activated?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4705"/>
        <location filename="../GUI/spot-on-c.cc" line="2470"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4662"/>
        <location filename="../GUI/spot-on-a.cc" line="4723"/>
        <location filename="../GUI/spot-on-a.cc" line="4789"/>
        <location filename="../GUI/spot-on-a.cc" line="4815"/>
        <location filename="../GUI/spot-on-c.cc" line="303"/>
        <location filename="../GUI/spot-on-c.cc" line="2409"/>
        <location filename="../GUI/spot-on-c.cc" line="2441"/>
        <location filename="../GUI/spot-on-c.cc" line="2488"/>
        <location filename="../GUI/spot-on-c.cc" line="2516"/>
        <location filename="../GUI/spot-on-c.cc" line="2544"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4664"/>
        <location filename="../GUI/spot-on-a.cc" line="4725"/>
        <location filename="../GUI/spot-on-a.cc" line="4791"/>
        <location filename="../GUI/spot-on-a.cc" line="4817"/>
        <location filename="../GUI/spot-on-c.cc" line="305"/>
        <location filename="../GUI/spot-on-c.cc" line="2411"/>
        <location filename="../GUI/spot-on-c.cc" line="2443"/>
        <location filename="../GUI/spot-on-c.cc" line="2490"/>
        <location filename="../GUI/spot-on-c.cc" line="2518"/>
        <location filename="../GUI/spot-on-c.cc" line="2546"/>
        <source>Delete &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4630"/>
        <location filename="../GUI/spot-on-a.cc" line="4751"/>
        <location filename="../GUI/spot-on-a.cc" line="4847"/>
        <location filename="../GUI/spot-on-c.cc" line="2336"/>
        <location filename="../GUI/spot-on-c.cc" line="2376"/>
        <location filename="../GUI/spot-on-c.cc" line="2570"/>
        <source>&amp;Add participant as friend.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="74"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="563"/>
        <location filename="../GUI/spot-on-b.cc" line="4302"/>
        <location filename="../GUI/spot-on-c.cc" line="3622"/>
        <source>Are you sure that you wish to remove the selected participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="813"/>
        <location filename="../GUI/spot-on-b.cc" line="818"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1401"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1426"/>
        <location filename="../GUI/spot-on-b.cc" line="1734"/>
        <source>Invalid key type. Expecting &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1453"/>
        <source>Unable to retrieve your %1 public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1477"/>
        <source>Unable to retrieve your %1 signature public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="65"/>
        <location filename="../GUI/spot-on-b.cc" line="2143"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="50"/>
        <location filename="../GUI/spot-on-b.cc" line="3341"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="55"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1393"/>
        <location filename="../GUI/spot-on-b.cc" line="1598"/>
        <source>Empty key. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1412"/>
        <location filename="../GUI/spot-on-b.cc" line="1719"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1537"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos; signature public key signature. Accept?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1606"/>
        <source>Invalid Repleo. The Repleo must start with either the letter R or the letter r.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1617"/>
        <location filename="../GUI/spot-on-b.cc" line="1667"/>
        <source>Irregular data. Expecting 3 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1652"/>
        <source>Asymmetric decryption failure. Are you attempting to add a repleo that you gathered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1709"/>
        <source>Symmetric decryption failure. Serious!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1886"/>
        <source>Are you sure that you wish to reset Spot-On? All data will be lost. Forever.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2151"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2254"/>
        <source>Queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2642"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2645"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2647"/>
        <source>From/To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2904"/>
        <source>Spot-On: Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2904"/>
        <source>&amp;Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4078"/>
        <source>Please provide a channel key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4084"/>
        <source>Please provide a hash key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4095"/>
        <source>Unable to compute a keyed hash from the channel key and channel type as an artificial salt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4447"/>
        <source>Unable to record the IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4643"/>
        <source>Please provide an account name and an account password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4648"/>
        <source>Please provide an account password that contains at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4588"/>
        <source>Empty cipher list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="45"/>
        <location filename="../GUI/spot-on-b.cc" line="3344"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1386"/>
        <location filename="../GUI/spot-on-b.cc" line="1591"/>
        <location filename="../GUI/spot-on-c.cc" line="2222"/>
        <source>Invalid spoton_crypt object(s). This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1489"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1510"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos; public key signature. Accept?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1690"/>
        <source>Unable to compute a keyed hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1698"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1787"/>
        <source>You&apos;re attempting to add your own keys or Spot-On was not able to retrieve your keys for comparison.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1800"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1812"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos; signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2921"/>
        <source>The provided goldbug may be incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2928"/>
        <source>A severe memory issue occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2972"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2975"/>
        <source>&lt;b&gt;To:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2977"/>
        <location filename="../GUI/spot-on-b.cc" line="3005"/>
        <location filename="../GUI/spot-on-b.cc" line="3021"/>
        <source>&lt;b&gt;Subject:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2980"/>
        <location filename="../GUI/spot-on-b.cc" line="3008"/>
        <location filename="../GUI/spot-on-b.cc" line="3024"/>
        <source>&lt;b&gt;Sent: &lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2987"/>
        <location filename="../GUI/spot-on-b.cc" line="2993"/>
        <location filename="../GUI/spot-on-b.cc" line="2995"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3000"/>
        <source>&lt;b&gt;From:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3002"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3015"/>
        <location filename="../GUI/spot-on-b.cc" line="3018"/>
        <source>&lt;b&gt;From/To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3029"/>
        <location filename="../GUI/spot-on-b.cc" line="3035"/>
        <location filename="../GUI/spot-on-b.cc" line="3037"/>
        <location filename="../GUI/spot-on-b.cc" line="3090"/>
        <source>Deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3278"/>
        <source>Are you sure that you wish to empty the Trash folder?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3917"/>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4238"/>
        <source>Generating SSL data for kernel socket. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4373"/>
        <location filename="../GUI/spot-on-b.cc" line="4477"/>
        <location filename="../GUI/spot-on-b.cc" line="4629"/>
        <location filename="../GUI/spot-on-b.cc" line="4740"/>
        <source>Invalid listener OID. Please select a listener.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4383"/>
        <source>Please provide an IP address or the keyword Any.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4495"/>
        <source>Please select an address to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4583"/>
        <source>The following ciphers were discovered. Please note that Spot-On may neglect discovered ciphers if the ciphers are not supported by Qt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4698"/>
        <source>A database error has occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4750"/>
        <source>Please select an account to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5052"/>
        <source>Remote user %1 is requesting authentication credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4835"/>
        <location filename="../GUI/spot-on-c.cc" line="297"/>
        <location filename="../GUI/spot-on-c.cc" line="2435"/>
        <location filename="../GUI/spot-on-c.cc" line="2557"/>
        <source>Copy &amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="121"/>
        <source>Invalid magnet. Are you missing tokens?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="820"/>
        <source>Please select a file to transfer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="828"/>
        <source>The provided file cannot be accessed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2209"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2211"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2213"/>
        <location filename="../GUI/spot-on-c.cc" line="2312"/>
        <source>Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2215"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2238"/>
        <source>Are you sure that you wish to generate the selected key pair? The kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2320"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2728"/>
        <source>&lt;b&gt;Chat Key Pair:&lt;/b&gt; %1, &lt;b&gt;Chat Signature Key Pair:&lt;/b&gt; %2, &lt;b&gt;E-Mail Key Pair:&lt;/b&gt; %3, &lt;b&gt;E-Mail Signature Key Pair:&lt;/b&gt; %4, &lt;b&gt;Rosetta Key Pair:&lt;/b&gt; %5, &lt;b&gt;Rosetta Signature Key Pair:&lt;/b&gt; %6, &lt;b&gt;URL Key Pair:&lt;/b&gt; %7, &lt;b&gt;URL Signature Key Pair:&lt;/b&gt; %8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2774"/>
        <source>A deep failure occurred while gathering your public key pairs. Do you have public keys? Please inspect the Settings tab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2792"/>
        <source>The gathered public keys contain a lot (%1) of data. Are you sure that you wish to export the data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2804"/>
        <source>Spot-On: Select Public Keys Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2851"/>
        <source>Spot-On: Select Public Keys Import File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2951"/>
        <source>Spot-On: Select Listeners Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3043"/>
        <source>Spot-On: Select Neighbors Import File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3701"/>
        <source>Spot-On: New Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3701"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2815"/>
        <location filename="../GUI/spot-on-c.cc" line="2961"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1545"/>
        <source>Please provide a nova. Reach for the stars!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1594"/>
        <source>Unable to store the nova.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1671"/>
        <source>Please select a nova to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2891"/>
        <location filename="../GUI/spot-on-c.cc" line="3083"/>
        <source>The import file contains a lot (%1) of data. Are you sure that you wish to process it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2943"/>
        <source>Unable to export an empty listeners table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="847"/>
        <source>Please select at least one magnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="421"/>
        <source>Spot-On: Select StarBeam Destination Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="777"/>
        <source>Spot-On: Select StarBeam Transmit File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="986"/>
        <location filename="../GUI/spot-on-c.cc" line="989"/>
        <source>A database error (%1) occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="992"/>
        <source>An error occurred within spoton_crypt.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzpage</name>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="186"/>
        <source>Empty kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="191"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="196"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="201"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="210"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="262"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="535"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="591"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="603"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="654"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="406"/>
        <source>&lt;i&gt;%1 has joined %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="439"/>
        <source>&lt;i&gt;%1 is now known as %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="501"/>
        <source>&lt;i&gt;%1 has left %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="536"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="604"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="592"/>
        <source>An error occurred while attempting to save the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="655"/>
        <source>An error occurred while attempting to remove the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_chatwindow</name>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="60"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="62"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="214"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="219"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="229"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="234"/>
        <source>Spot-On: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="128"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="133"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="138"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="149"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="193"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_logviewer</name>
    <message>
        <location filename="../UI/logviewer.ui" line="14"/>
        <source>Spot-On: Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="62"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="81"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="87"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="98"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="103"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="111"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_mainwindow</name>
    <message>
        <location filename="../UI/controlcenter.ui" line="167"/>
        <location filename="../UI/controlcenter.ui" line="306"/>
        <location filename="../UI/controlcenter.ui" line="486"/>
        <location filename="../UI/controlcenter.ui" line="871"/>
        <location filename="../UI/controlcenter.ui" line="3262"/>
        <location filename="../UI/controlcenter.ui" line="4592"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="110"/>
        <location filename="../UI/controlcenter.ui" line="539"/>
        <location filename="../UI/controlcenter.ui" line="1239"/>
        <location filename="../UI/controlcenter.ui" line="3579"/>
        <location filename="../UI/controlcenter.ui" line="5377"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="648"/>
        <location filename="../UI/controlcenter.ui" line="1211"/>
        <location filename="../UI/controlcenter.ui" line="5460"/>
        <source>public_key_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="811"/>
        <location filename="../UI/controlcenter.ui" line="1332"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1102"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2181"/>
        <location filename="../UI/controlcenter.ui" line="2250"/>
        <location filename="../UI/controlcenter.ui" line="3366"/>
        <location filename="../UI/controlcenter.ui" line="4806"/>
        <location filename="../UI/controlcenter.ui" line="5570"/>
        <location filename="../UI/controlcenter.ui" line="5693"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="913"/>
        <source>Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1268"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1351"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2271"/>
        <source>&amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1625"/>
        <location filename="../UI/controlcenter.ui" line="2518"/>
        <source>Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1630"/>
        <location filename="../UI/controlcenter.ui" line="2523"/>
        <source>Local Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1640"/>
        <location filename="../UI/controlcenter.ui" line="2558"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4116"/>
        <source>Set Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5860"/>
        <source>Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2543"/>
        <source>Remote IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2548"/>
        <source>Remote Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2678"/>
        <source>Add Neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2493"/>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1740"/>
        <location filename="../UI/controlcenter.ui" line="2772"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1787"/>
        <location filename="../UI/controlcenter.ui" line="2762"/>
        <location filename="../UI/controlcenter.ui" line="3033"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1813"/>
        <location filename="../UI/controlcenter.ui" line="2743"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1829"/>
        <location filename="../UI/controlcenter.ui" line="2788"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="764"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="759"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2498"/>
        <source>UUID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1645"/>
        <location filename="../UI/controlcenter.ui" line="2528"/>
        <source>External IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="53"/>
        <source>&amp;Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="138"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="97"/>
        <location filename="../UI/controlcenter.ui" line="526"/>
        <location filename="../UI/controlcenter.ui" line="2114"/>
        <location filename="../UI/controlcenter.ui" line="4164"/>
        <location filename="../UI/controlcenter.ui" line="5364"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="272"/>
        <location filename="../UI/controlcenter.ui" line="4657"/>
        <source>Hash &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="285"/>
        <source>Hash &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="311"/>
        <location filename="../UI/controlcenter.ui" line="4361"/>
        <source>Generate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="319"/>
        <source>Join</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="569"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="70"/>
        <source>Accept shared &amp;magnets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="589"/>
        <location filename="../UI/controlcenter.ui" line="1246"/>
        <location filename="../UI/controlcenter.ui" line="1553"/>
        <location filename="../UI/controlcenter.ui" line="2288"/>
        <location filename="../UI/controlcenter.ui" line="4463"/>
        <location filename="../UI/controlcenter.ui" line="4892"/>
        <location filename="../UI/controlcenter.ui" line="4994"/>
        <location filename="../UI/controlcenter.ui" line="5401"/>
        <source>Context Menu Reflection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="658"/>
        <source>Last Status Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="739"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="832"/>
        <source>&amp;E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="884"/>
        <source>Empty Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="897"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="910"/>
        <source>Request e-mail from other participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="947"/>
        <source>&amp;Retrieve e-mail every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="964"/>
        <source>&amp;minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="993"/>
        <source>&amp;Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1014"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1019"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1024"/>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1055"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1087"/>
        <location filename="../UI/controlcenter.ui" line="1456"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1092"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1107"/>
        <source>goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1112"/>
        <source>message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1117"/>
        <source>message_digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1122"/>
        <source>receiver_sender_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1148"/>
        <source>&amp;Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1371"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1361"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="146"/>
        <source>&amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="156"/>
        <source>Demagnetize the link.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="202"/>
        <source>Channel &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="248"/>
        <source>Channel &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="400"/>
        <location filename="../UI/controlcenter.ui" line="940"/>
        <location filename="../UI/controlcenter.ui" line="5321"/>
        <source>Accept shared public &amp;keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="417"/>
        <source>Broadcast odd messages at odd times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="420"/>
        <source>&amp;Impersonate me.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="868"/>
        <source>Clear the contents of the current view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1286"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle the e-mail in an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1289"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1319"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The kernel is responsible for signing messages. Because messages are queued, please avoid toggling this checkbox until queued messages have been processed by the kernel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1322"/>
        <source>Sign &amp;messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1385"/>
        <source>&amp;C/O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1461"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1479"/>
        <source>Data that has not been processed in more than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1496"/>
        <source>&amp;day(s) will be purged automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1560"/>
        <source>Periodically p&amp;ublish plaintext information. External IP information is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1685"/>
        <location filename="../UI/controlcenter.ui" line="2628"/>
        <source>Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1690"/>
        <source>Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1700"/>
        <location filename="../UI/controlcenter.ui" line="2001"/>
        <location filename="../UI/controlcenter.ui" line="2633"/>
        <location filename="../UI/controlcenter.ui" line="2953"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1725"/>
        <source>The uniqueness of a listener is defined by the local IP, the local port, the scope ID, and the transport.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1836"/>
        <location filename="../UI/controlcenter.ui" line="2805"/>
        <source>&amp;Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1850"/>
        <location filename="../UI/controlcenter.ui" line="2824"/>
        <source>TCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1855"/>
        <location filename="../UI/controlcenter.ui" line="2829"/>
        <source>UDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1868"/>
        <source>&amp;Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1973"/>
        <location filename="../UI/controlcenter.ui" line="2407"/>
        <location filename="../UI/controlcenter.ui" line="2938"/>
        <location filename="../UI/controlcenter.ui" line="3886"/>
        <location filename="../UI/controlcenter.ui" line="4246"/>
        <source>8192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2012"/>
        <location filename="../UI/controlcenter.ui" line="2964"/>
        <source>Packet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2017"/>
        <location filename="../UI/controlcenter.ui" line="2969"/>
        <source>Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2218"/>
        <source>The keyword Any is supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2298"/>
        <source>Copy Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2305"/>
        <source>Share Buzz Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2643"/>
        <source>certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2690"/>
        <source>The uniqueness of a neighbor is defined by the proxy hostname, the proxy port, the remote IP, the remote port, the scope ID, and the transport.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3460"/>
        <location filename="../UI/controlcenter.ui" line="3620"/>
        <source>&amp;External IP Retrieval Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3477"/>
        <location filename="../UI/controlcenter.ui" line="3637"/>
        <source>30 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3482"/>
        <location filename="../UI/controlcenter.ui" line="3642"/>
        <source>60 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3487"/>
        <location filename="../UI/controlcenter.ui" line="3647"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3495"/>
        <location filename="../UI/controlcenter.ui" line="3655"/>
        <source>&amp;Secure Memory Pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3725"/>
        <source>&amp;Force Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3817"/>
        <source>&amp;Congestion Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3894"/>
        <source>If enabled, messages that are deciphered correctly will be echoed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3924"/>
        <location filename="../UI/controlcenter.ui" line="3949"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3983"/>
        <source>Statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3988"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4194"/>
        <source>Chat Key Pair: 0, Chat Signature Key Pair: 0, E-Mail Key Pair: 0, E-Mail Signature Key Pair: 0, Rosetta Key Pair: 0, Rosetta Signature Key Pair: 0, URL Key Pair: 0, URL Signature Key Pair: 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4209"/>
        <source>If checked, new key pairs will be generated whenever the passphrase is updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4324"/>
        <source>Key &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4338"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4343"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4348"/>
        <source>Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4353"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4406"/>
        <source>S&amp;tarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4446"/>
        <source>&amp;Magnets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4510"/>
        <source>One-Time-Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4545"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4578"/>
        <source>&amp;Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4677"/>
        <source>Encryption &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4743"/>
        <source>&amp;Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4816"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4839"/>
        <source>&amp;Destination Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4939"/>
        <source>Percent Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4949"/>
        <location filename="../UI/controlcenter.ui" line="5070"/>
        <source>Total Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4959"/>
        <location filename="../UI/controlcenter.ui" line="5090"/>
        <source>SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5085"/>
        <source>Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5195"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle each pulse in an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6163"/>
        <source>&amp;Import Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6168"/>
        <source>&amp;StarBeam Analyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6051"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5212"/>
        <source>&amp;Missing Links Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5950"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://sourceforge.net/p/spot-on/code/HEAD/tree/branches/Documentation/RELEASE-NOTES&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Version 0.09.02&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6127"/>
        <source>&amp;Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6132"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6135"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6140"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6143"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6148"/>
        <source>&amp;Export Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6153"/>
        <source>&amp;Import Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6158"/>
        <source>&amp;Export Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4602"/>
        <source>Generate Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4607"/>
        <source>Generate MAC Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4036"/>
        <location filename="../UI/controlcenter.ui" line="4690"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4019"/>
        <location filename="../UI/controlcenter.ui" line="4647"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5266"/>
        <source> Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4977"/>
        <source>&amp;Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1526"/>
        <source>&amp;Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1620"/>
        <location filename="../UI/controlcenter.ui" line="2508"/>
        <source>SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1650"/>
        <location filename="../UI/controlcenter.ui" line="2533"/>
        <source>External Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1665"/>
        <location filename="../UI/controlcenter.ui" line="2583"/>
        <source>Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1670"/>
        <source>Use Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1713"/>
        <source>Add Listener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1924"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Record the current external IP address in the listener&apos;s certificate. Please do not use this option if you have a dynamic IP address.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1927"/>
        <source>&amp;Ip Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1934"/>
        <source>&amp;Permanent Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1944"/>
        <location filename="../UI/controlcenter.ui" line="2375"/>
        <location filename="../UI/controlcenter.ui" line="2909"/>
        <location filename="../UI/controlcenter.ui" line="3854"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1958"/>
        <location filename="../UI/controlcenter.ui" line="2392"/>
        <location filename="../UI/controlcenter.ui" line="2923"/>
        <location filename="../UI/controlcenter.ui" line="3871"/>
        <location filename="../UI/controlcenter.ui" line="4226"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1968"/>
        <location filename="../UI/controlcenter.ui" line="2402"/>
        <location filename="../UI/controlcenter.ui" line="2933"/>
        <location filename="../UI/controlcenter.ui" line="3881"/>
        <location filename="../UI/controlcenter.ui" line="4236"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1897"/>
        <location filename="../UI/controlcenter.ui" line="2859"/>
        <source>&amp;Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="124"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1911"/>
        <location filename="../UI/controlcenter.ui" line="2873"/>
        <source>Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1916"/>
        <location filename="../UI/controlcenter.ui" line="2878"/>
        <source>Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2087"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2147"/>
        <source>&amp;One-Time Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2342"/>
        <source>Select this option if you would like to accept and connect to published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2352"/>
        <source>Select this option if you would like to accept published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2513"/>
        <source>Status Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2538"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2563"/>
        <source>Proxy Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2568"/>
        <source>Proxy Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2593"/>
        <source>Allow Certificate Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2603"/>
        <source>Bytes Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2608"/>
        <source>Bytes Written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2613"/>
        <source>SSL Session Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2618"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2623"/>
        <source>Account Authenticated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2638"/>
        <source>is_encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2795"/>
        <source>Dynamic DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2798"/>
        <source>&amp;DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On will record peer certificates during initial connections. Subsequent connections will cause Spot-On to inspect peer certificates. If there are discrepancies between recorded certificates and transmitted certificates, Spot-On will sever the connections. Enable this option if you would like Spot-On to ignore discrepancies.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2899"/>
        <source>&amp;Require SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3535"/>
        <source>&amp;GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3586"/>
        <source>Display a list of ciphers produced by the provided SSL Control String.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3589"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3809"/>
        <source>randomized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4212"/>
        <source>&amp;Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4259"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4276"/>
        <location filename="../UI/controlcenter.ui" line="4311"/>
        <source>ElGamal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4281"/>
        <location filename="../UI/controlcenter.ui" line="4316"/>
        <source>RSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4289"/>
        <source>&amp;Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4306"/>
        <source>DSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4759"/>
        <source>Novas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5055"/>
        <source>Paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4944"/>
        <location filename="../UI/controlcenter.ui" line="5065"/>
        <source>Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5121"/>
        <source>Rewind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5256"/>
        <source>&amp;Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5472"/>
        <source>URL Polarizers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6103"/>
        <source>&amp;East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6114"/>
        <source>&amp;North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6122"/>
        <source>&amp;West</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3010"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="235"/>
        <source>&amp;Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2992"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3020"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3043"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2124"/>
        <location filename="../UI/controlcenter.ui" line="3056"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2193"/>
        <source>Allowed IP Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3085"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3090"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3095"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3292"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3332"/>
        <source>Fetch!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3386"/>
        <source>&lt; 1 .. 1 &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3419"/>
        <source>S&amp;ettings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3603"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3745"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3758"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3695"/>
        <source>Spot-On-Kernel &amp;Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4182"/>
        <source>Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4140"/>
        <source>P&amp;assphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6074"/>
        <source>Nuvola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6082"/>
        <source>Nouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6090"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6095"/>
        <source>&amp;Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6087"/>
        <source>&amp;Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1610"/>
        <location filename="../UI/controlcenter.ui" line="3732"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="653"/>
        <location filename="../UI/controlcenter.ui" line="1097"/>
        <location filename="../UI/controlcenter.ui" line="1615"/>
        <location filename="../UI/controlcenter.ui" line="2503"/>
        <location filename="../UI/controlcenter.ui" line="5075"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1635"/>
        <location filename="../UI/controlcenter.ui" line="2553"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1753"/>
        <location filename="../UI/controlcenter.ui" line="2717"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="559"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="564"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="574"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="633"/>
        <location filename="../UI/controlcenter.ui" line="1196"/>
        <location filename="../UI/controlcenter.ui" line="5445"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="643"/>
        <location filename="../UI/controlcenter.ui" line="1206"/>
        <location filename="../UI/controlcenter.ui" line="5455"/>
        <source>neighbor_oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1660"/>
        <source>Max. Conn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1767"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2038"/>
        <location filename="../UI/controlcenter.ui" line="2174"/>
        <location filename="../UI/controlcenter.ui" line="2243"/>
        <location filename="../UI/controlcenter.ui" line="3169"/>
        <location filename="../UI/controlcenter.ui" line="3255"/>
        <location filename="../UI/controlcenter.ui" line="4733"/>
        <location filename="../UI/controlcenter.ui" line="4799"/>
        <location filename="../UI/controlcenter.ui" line="5563"/>
        <location filename="../UI/controlcenter.ui" line="5686"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2144"/>
        <source>If checked, the account will be removed after a client successfully authenticates itself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2295"/>
        <source>Copy your public key pairs to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2896"/>
        <source>Require encrypted connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3194"/>
        <source>Add Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3211"/>
        <source>&amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3221"/>
        <source>&amp;Repleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3409"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3722"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please enable this option if you would like to force kernel registration. By forcing kernel registration, an existing kernel process that Spot-On is aware of will be deactivated. You may wish to use this option if a kernel was not deactivated properly.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3768"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3548"/>
        <location filename="../UI/controlcenter.ui" line="3708"/>
        <location filename="../UI/controlcenter.ui" line="4852"/>
        <location filename="../UI/controlcenter.ui" line="5249"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4053"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1963"/>
        <location filename="../UI/controlcenter.ui" line="2397"/>
        <location filename="../UI/controlcenter.ui" line="2928"/>
        <location filename="../UI/controlcenter.ui" line="3876"/>
        <location filename="../UI/controlcenter.ui" line="4231"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4241"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4251"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4076"/>
        <source>Salt &amp;Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4123"/>
        <location filename="../UI/controlcenter.ui" line="5843"/>
        <source>P&amp;assphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4150"/>
        <source>Minimum of 16 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5488"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5518"/>
        <location filename="../UI/controlcenter.ui" line="5641"/>
        <source>&amp;Accept List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5528"/>
        <location filename="../UI/controlcenter.ui" line="5651"/>
        <source>&amp;Deny List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5611"/>
        <source>&amp;Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="339"/>
        <source>&amp;Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="172"/>
        <location filename="../UI/controlcenter.ui" line="5222"/>
        <source>Demagnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="177"/>
        <source>Magnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="182"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="187"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="215"/>
        <source>&amp;Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="407"/>
        <location filename="../UI/controlcenter.ui" line="1045"/>
        <source>&amp;Accept only signed messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="427"/>
        <source>&amp;Sign messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="456"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="509"/>
        <location filename="../UI/controlcenter.ui" line="5347"/>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="638"/>
        <location filename="../UI/controlcenter.ui" line="1127"/>
        <location filename="../UI/controlcenter.ui" line="1201"/>
        <location filename="../UI/controlcenter.ui" line="1705"/>
        <location filename="../UI/controlcenter.ui" line="2648"/>
        <location filename="../UI/controlcenter.ui" line="4520"/>
        <location filename="../UI/controlcenter.ui" line="4964"/>
        <location filename="../UI/controlcenter.ui" line="5095"/>
        <location filename="../UI/controlcenter.ui" line="5179"/>
        <location filename="../UI/controlcenter.ui" line="5450"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="663"/>
        <source>Gemini AES-256 Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="668"/>
        <source>Gemini SHA-512 Hash Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="681"/>
        <source>&amp;Hide offline participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1309"/>
        <source>&amp;Save copies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1221"/>
        <source>&amp;From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1402"/>
        <source>&amp;Enable C/O service.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1409"/>
        <source>&amp;Reject messages without signatures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1466"/>
        <source>Recipient SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1695"/>
        <location filename="../UI/controlcenter.ui" line="2598"/>
        <source>Certificate SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4515"/>
        <location filename="../UI/controlcenter.ui" line="5174"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4597"/>
        <source>Generate Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4866"/>
        <source>&amp;Maximum Mosaic Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4876"/>
        <source> MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5060"/>
        <source>Percent Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4954"/>
        <location filename="../UI/controlcenter.ui" line="5080"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5282"/>
        <source>Transmit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1655"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2345"/>
        <source>&amp;Accept published listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2355"/>
        <source>&amp;Accept published listeners (disconnected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2365"/>
        <source>&amp;Ignore published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2435"/>
        <source>&amp;Keep only user-defined neighbors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1675"/>
        <location filename="../UI/controlcenter.ui" line="2573"/>
        <source>Max. Buffer Size (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1680"/>
        <location filename="../UI/controlcenter.ui" line="2578"/>
        <source>Max. Content Length (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2588"/>
        <source>Uptime (Seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2889"/>
        <source>&amp;Allow Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3795"/>
        <source>&amp;Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3840"/>
        <source>&amp;Log Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3847"/>
        <source>&amp;Scrambler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3897"/>
        <source>S&amp;uper Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4002"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3562"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3572"/>
        <source>HIGH:!aNULL:!eNULL:!3DES:!EXPORT:@STRENGTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5143"/>
        <source>Add Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5198"/>
        <source>Nova</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5304"/>
        <source>&amp;URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5794"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;quot;The Dalmatian is a breed of dog, noted for its unique black- or brown-spotted coat. This dog is often used as a rescue dog, guardian, athletic partner, and, especially today, the Dalmatian remains most often an active, well-loved family member.&amp;quot; - Wikipedia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5919"/>
        <source>Spot-On Graphical User Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5966"/>
        <source>Build Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5236"/>
        <location filename="../UI/controlcenter.ui" line="6006"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6014"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6018"/>
        <source>&amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6025"/>
        <source>&amp;Tab Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6037"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6063"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6066"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_rosetta</name>
    <message>
        <location filename="../UI/rosetta.ui" line="14"/>
        <source>Spot-On: Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="36"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="875"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="49"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="72"/>
        <source>Copy &amp;Rosetta Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="81"/>
        <source>New Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="118"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="125"/>
        <location filename="../UI/rosetta.ui" line="303"/>
        <location filename="../UI/rosetta.ui" line="350"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="169"/>
        <source>&amp;Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="155"/>
        <source>&amp;Decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="69"/>
        <source>Copy your public key pairs to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="179"/>
        <source>&amp;Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="196"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="203"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="229"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="246"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="263"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="280"/>
        <source>&amp;Sign message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="320"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="391"/>
        <source>Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="398"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="417"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="423"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="434"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="439"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="447"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="452"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="455"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="460"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="463"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="307"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="318"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="326"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="337"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="350"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="411"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="423"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="438"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="650"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="769"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="319"/>
        <source>Empty key. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="327"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="338"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="351"/>
        <source>Invalid key type. Expecting &apos;rosetta&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="412"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="424"/>
        <source>Invalid &apos;rosetta&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="439"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="531"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="554"/>
        <source>Invalid item data. This is a serious flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="560"/>
        <source>Please provide an actual message!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="569"/>
        <source>The method spoton_crypt::cipherKeyLength() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="592"/>
        <source>The method spoton_crypt::publicKeyEncrypt() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="637"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="762"/>
        <source>A serious cryptographic error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="671"/>
        <source>Empty input data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="685"/>
        <source>The method spoton_crypt::publicKeyDecrypt() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="709"/>
        <source>The method spoton_crypt::keyedHash() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="719"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="753"/>
        <source>The message was not signed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="757"/>
        <source>Invalid signature. Perhaps your contacts are not current.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="875"/>
        <source>Spot-On: New Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="374"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="397"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="786"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="308"/>
        <source>Invalid spoton_crypt object(s). This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="377"/>
        <source>Unable to retrieve your %1 public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="400"/>
        <source>Unable to retrieve your %1 signature public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="789"/>
        <source>Are you sure that you wish to remove the selected contact?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_starbeamanalyzer</name>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="14"/>
        <source>Spot-On: StarBeam Analyzer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="53"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="58"/>
        <source>Percent Analyzed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="63"/>
        <source>Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="68"/>
        <source>Total Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="73"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="78"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="83"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="109"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="116"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="145"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/starbeamanalyzer.ui" line="154"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statusbar</name>
    <message>
        <location filename="../UI/statusbar.ui" line="89"/>
        <source>Buzz activity detected!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="102"/>
        <source>You have received a new message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="118"/>
        <source>New e-mail has arrived!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="147"/>
        <source>Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
