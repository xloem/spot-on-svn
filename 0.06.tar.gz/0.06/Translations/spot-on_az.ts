<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="az_AZ">
<context>
    <name>QObject</name>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="173"/>
        <source>gcry_cipher_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="182"/>
        <source>gcry_md_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="191"/>
        <location filename="../Common/spot-on-crypt.cc" line="559"/>
        <location filename="../Common/spot-on-crypt.cc" line="736"/>
        <source>gcry_cipher_get_algo_keylen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="202"/>
        <source>gcry_calloc_secure() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="226"/>
        <source>gcry_kdf_derive() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="346"/>
        <source>gcry_md_get_algo_dlen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="423"/>
        <source>oldPassphrase is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="507"/>
        <source>gcry_cipher_open() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="519"/>
        <source>gcry_cipher_open() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="530"/>
        <location filename="../Common/spot-on-crypt.cc" line="695"/>
        <location filename="../Common/spot-on-crypt.cc" line="705"/>
        <source>gcry_cipher_get_algo_blklen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="544"/>
        <location filename="../Common/spot-on-crypt.cc" line="728"/>
        <source>gcry_cipher_setiv() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="571"/>
        <location filename="../Common/spot-on-crypt.cc" line="749"/>
        <source>gcry_cipher_setkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="463"/>
        <source>error retrieving data from the idiotes table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="320"/>
        <source>empty passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="327"/>
        <source>empty salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="334"/>
        <source>gcry_md_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="491"/>
        <source>gcry_cipher_map_name() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="605"/>
        <source>The length of the decrypted data is irregular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="616"/>
        <source>gcry_cipher_decrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="641"/>
        <source>gcry_sexp_new() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="653"/>
        <source>gcry_sexp_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="664"/>
        <source>gcry_pk_testkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="685"/>
        <source>gcry_cipher_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="715"/>
        <source>gcry_calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="778"/>
        <source>gcry_cipher_encrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2089"/>
        <source>gcry_sexp_build() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2113"/>
        <source>gcry_pk_genkey() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2141"/>
        <source>gcry_sexp_find_token() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2152"/>
        <location filename="../Common/spot-on-crypt.cc" line="2167"/>
        <source>gcry_sexp_sprint() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2185"/>
        <source>malloc() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2223"/>
        <source>QSqlQuery::exec() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2232"/>
        <source>encrypted() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2868"/>
        <source>BN_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2876"/>
        <source>BN_set_word() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2884"/>
        <source>RSA_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2892"/>
        <source>RSA_generate_key_ex() returned negative one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2900"/>
        <location filename="../Common/spot-on-crypt.cc" line="2908"/>
        <location filename="../Common/spot-on-crypt.cc" line="3161"/>
        <source>BIO_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2916"/>
        <source>PEM_write_bio_RSAPrivateKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2924"/>
        <source>PEM_write_bio_RSAPublicKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2934"/>
        <location filename="../Common/spot-on-crypt.cc" line="2948"/>
        <location filename="../Common/spot-on-crypt.cc" line="3079"/>
        <location filename="../Common/spot-on-crypt.cc" line="3179"/>
        <source>calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3013"/>
        <source>rsa container is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3021"/>
        <source>EVP_PKEY_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3030"/>
        <source>X509_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3039"/>
        <source>EVP_PKEY_assign_RSA() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3051"/>
        <source>X509_set_version() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3059"/>
        <location filename="../Common/spot-on-crypt.cc" line="3067"/>
        <source>X509_gmtime_adj() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3097"/>
        <source>X509_NAME_ENTRY_create_by_NID() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3107"/>
        <source>X509_NAME_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3115"/>
        <source>X509_NAME_add_entry() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3123"/>
        <source>X509_set_subject_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3133"/>
        <source>X509_set_issuer_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3141"/>
        <source>X509_set_pubkey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3149"/>
        <source>X509_sign() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3169"/>
        <source>PEM_write_bio_X509() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="58"/>
        <source>Re-encoding accepted_ips.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="278"/>
        <source>Re-encoding email.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="192"/>
        <source>Re-encoding country_inclusion.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="125"/>
        <source>Re-encoding buzz_channels.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="438"/>
        <source>Re-encoding listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="657"/>
        <source>Re-encoding neighbors.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1200"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>buzzPage</name>
    <message>
        <location filename="../UI/buzzpage.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="86"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="31"/>
        <source>Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="45"/>
        <source>Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="59"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="79"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="99"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="129"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="149"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="174"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="179"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="184"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="228"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="248"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="253"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="300"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chatwindow</name>
    <message>
        <location filename="../UI/chatwindow.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="36"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="43"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="63"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="103"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>passwordprompt</name>
    <message>
        <location filename="../UI/passwordprompt.ui" line="14"/>
        <source>Spot-On: Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="30"/>
        <source>Please provide the following credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="42"/>
        <source>Account &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="55"/>
        <source>Account &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton</name>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2897"/>
        <source>Spot-On: Select Kernel Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2874"/>
        <location filename="../GUI/spot-on-a.cc" line="2900"/>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1219"/>
        <location filename="../GUI/spot-on-a.cc" line="1432"/>
        <location filename="../GUI/spot-on-a.cc" line="1444"/>
        <location filename="../GUI/spot-on-a.cc" line="1721"/>
        <location filename="../GUI/spot-on-a.cc" line="3268"/>
        <location filename="../GUI/spot-on-a.cc" line="3277"/>
        <location filename="../GUI/spot-on-a.cc" line="3461"/>
        <location filename="../GUI/spot-on-a.cc" line="3468"/>
        <location filename="../GUI/spot-on-a.cc" line="3479"/>
        <location filename="../GUI/spot-on-a.cc" line="5721"/>
        <location filename="../GUI/spot-on-a.cc" line="5733"/>
        <location filename="../GUI/spot-on-a.cc" line="5806"/>
        <location filename="../GUI/spot-on-a.cc" line="6000"/>
        <location filename="../GUI/spot-on-a.cc" line="6043"/>
        <location filename="../GUI/spot-on-b.cc" line="134"/>
        <location filename="../GUI/spot-on-b.cc" line="1683"/>
        <location filename="../GUI/spot-on-b.cc" line="1690"/>
        <location filename="../GUI/spot-on-b.cc" line="1698"/>
        <location filename="../GUI/spot-on-b.cc" line="1708"/>
        <location filename="../GUI/spot-on-b.cc" line="1720"/>
        <location filename="../GUI/spot-on-b.cc" line="1735"/>
        <location filename="../GUI/spot-on-b.cc" line="1743"/>
        <location filename="../GUI/spot-on-b.cc" line="1753"/>
        <location filename="../GUI/spot-on-b.cc" line="1761"/>
        <location filename="../GUI/spot-on-b.cc" line="1773"/>
        <location filename="../GUI/spot-on-b.cc" line="1788"/>
        <location filename="../GUI/spot-on-b.cc" line="1838"/>
        <location filename="../GUI/spot-on-b.cc" line="1845"/>
        <location filename="../GUI/spot-on-b.cc" line="1853"/>
        <location filename="../GUI/spot-on-b.cc" line="1863"/>
        <location filename="../GUI/spot-on-b.cc" line="1886"/>
        <location filename="../GUI/spot-on-b.cc" line="1896"/>
        <location filename="../GUI/spot-on-b.cc" line="1917"/>
        <location filename="../GUI/spot-on-b.cc" line="1924"/>
        <location filename="../GUI/spot-on-b.cc" line="1934"/>
        <location filename="../GUI/spot-on-b.cc" line="1943"/>
        <location filename="../GUI/spot-on-b.cc" line="1956"/>
        <location filename="../GUI/spot-on-b.cc" line="1966"/>
        <location filename="../GUI/spot-on-b.cc" line="1977"/>
        <location filename="../GUI/spot-on-b.cc" line="2308"/>
        <location filename="../GUI/spot-on-b.cc" line="2316"/>
        <location filename="../GUI/spot-on-b.cc" line="2891"/>
        <location filename="../GUI/spot-on-b.cc" line="2898"/>
        <location filename="../GUI/spot-on-b.cc" line="3276"/>
        <location filename="../GUI/spot-on-b.cc" line="4068"/>
        <location filename="../GUI/spot-on-b.cc" line="4263"/>
        <location filename="../GUI/spot-on-b.cc" line="4272"/>
        <location filename="../GUI/spot-on-b.cc" line="4320"/>
        <location filename="../GUI/spot-on-b.cc" line="4540"/>
        <location filename="../GUI/spot-on-b.cc" line="4565"/>
        <location filename="../GUI/spot-on-b.cc" line="4575"/>
        <location filename="../GUI/spot-on-b.cc" line="4584"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="675"/>
        <location filename="../GUI/spot-on-a.cc" line="4022"/>
        <source>Not connected to the kernel. Is the kernel active?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2014"/>
        <location filename="../GUI/spot-on-a.cc" line="2016"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2401"/>
        <source>The sticky feature enables an indefinite lifetime for a neighbor.
If not checked, the neighbor will be terminated after some internal timer expires.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3269"/>
        <source>The passphrases must contain at least sixteen characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3294"/>
        <location filename="../GUI/spot-on-b.cc" line="509"/>
        <location filename="../GUI/spot-on-b.cc" line="2050"/>
        <location filename="../GUI/spot-on-b.cc" line="3203"/>
        <location filename="../GUI/spot-on-b.cc" line="4211"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3835"/>
        <location filename="../GUI/spot-on-a.cc" line="3972"/>
        <source>&amp;Remove participant(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4001"/>
        <source>Connected insecurely to the kernel on port %1 from local port %2. Communications between the interface and the kernel have been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4578"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4580"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4481"/>
        <location filename="../GUI/spot-on-a.cc" line="4582"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="116"/>
        <location filename="../GUI/spot-on-a.cc" line="118"/>
        <location filename="../GUI/spot-on-a.cc" line="121"/>
        <location filename="../GUI/spot-on-a.cc" line="124"/>
        <location filename="../GUI/spot-on-a.cc" line="127"/>
        <source>Spot-On was configured without libGeoIP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="133"/>
        <location filename="../GUI/spot-on-a.cc" line="136"/>
        <source>Spot-On was configured without libphoton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="677"/>
        <location filename="../GUI/spot-on-a.cc" line="2137"/>
        <source>Listeners are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="678"/>
        <location filename="../GUI/spot-on-a.cc" line="2676"/>
        <source>Neighbors are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="690"/>
        <source>Copy &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="695"/>
        <source>Copy &amp;All Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="704"/>
        <location filename="../GUI/spot-on-a.cc" line="3881"/>
        <source>Share &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="709"/>
        <source>&amp;Demagnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="711"/>
        <source>&amp;Magnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="714"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="716"/>
        <source>Remove &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="720"/>
        <source>&amp;Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="722"/>
        <source>&amp;On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1193"/>
        <source>Preparing databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1220"/>
        <location filename="../GUI/spot-on-a.cc" line="1445"/>
        <location filename="../GUI/spot-on-a.cc" line="5722"/>
        <location filename="../GUI/spot-on-a.cc" line="5955"/>
        <location filename="../GUI/spot-on-b.cc" line="1691"/>
        <location filename="../GUI/spot-on-b.cc" line="1846"/>
        <location filename="../GUI/spot-on-b.cc" line="3952"/>
        <location filename="../GUI/spot-on-b.cc" line="4264"/>
        <location filename="../GUI/spot-on-b.cc" line="4493"/>
        <location filename="../GUI/spot-on-b.cc" line="4576"/>
        <source>Invalid spoton_crypt object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1241"/>
        <source>Generating SSL data for listener. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1433"/>
        <source>Unable to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1722"/>
        <source>Unable to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1896"/>
        <source>Status: %1
SSL Key Size: %2
Local IP: %3 Local Port: %4 Scope ID: %5
External IP: %6
Connections: %7
Echo Mode: %8
Use Accounts: %9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2130"/>
        <source>There is (are) %1 active listener(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2295"/>
        <source>UUID: %1
Status: %2
SSL Key Size: %3
Local IP: %4 Local Port: %5
External IP: %6
Country: %7 Remote IP: %8 Remote Port: %9 Scope ID: %10
Proxy Hostname: %11 Proxy Port: %12
Echo Mode: %13
Communications Mode: %14
Uptime: %15 Minutes
Allow Certificate Exceptions: %16
Bytes Read: %17
Bytes Written: %18
SSL Session Cipher: %19
Account Name: %20
Account Authenticated: %21
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2665"/>
        <source>There is (are) %1 connected neighbor(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2855"/>
        <source>External IP: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2871"/>
        <source>Spot-On: Select GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3278"/>
        <source>The passphrases are not identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3297"/>
        <source>Are you sure that you wish to replace the existing passphrase?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3321"/>
        <source>Generating a derived key. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3412"/>
        <source>Generating public key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3418"/>
        <source>Generating public key pair %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3462"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKey().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3480"/>
        <source>An error (%1) occurred with spoton_crypt::saltedPassphraseHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3613"/>
        <source>Your confidential information has been recorded. You are now ready to use the full power of Spot-On. Enjoy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3894"/>
        <source>&amp;Reset Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5734"/>
        <source>Invalid neighbor OID. Please select a neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5807"/>
        <source>The account name must be non-empty and the account password must contain at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5911"/>
        <location filename="../GUI/spot-on-a.cc" line="6013"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5945"/>
        <source>Invalid action object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5950"/>
        <source>Invalid menu object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5995"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6023"/>
        <source>Invalid clipboard object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3807"/>
        <source>&amp;Delete IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3849"/>
        <source>Detach &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3851"/>
        <source>Disconnect &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3854"/>
        <source>&amp;Publish Information (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3856"/>
        <source>Publish &amp;All (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3891"/>
        <source>&amp;Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3905"/>
        <source>Delete All Non-Unique &amp;Blocked Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3907"/>
        <source>Delete All Non-Unique &amp;UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3910"/>
        <source>B&amp;lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3912"/>
        <source>U&amp;nblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3859"/>
        <location filename="../GUI/spot-on-a.cc" line="3915"/>
        <source>&amp;Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3861"/>
        <location filename="../GUI/spot-on-a.cc" line="3917"/>
        <source>&amp;Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3941"/>
        <source>&amp;Call participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3829"/>
        <location filename="../GUI/spot-on-a.cc" line="3938"/>
        <source>&amp;Copy Repleo to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="683"/>
        <source>Copy &amp;Chat Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="686"/>
        <source>Copy &amp;E-Mail Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="699"/>
        <location filename="../GUI/spot-on-a.cc" line="3870"/>
        <source>Share &amp;Chat Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="701"/>
        <location filename="../GUI/spot-on-a.cc" line="3875"/>
        <source>Share &amp;E-Mail Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3366"/>
        <source>Re-encoding public key pair 1 of %1. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3469"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys() or spoton_crypt::reencodeKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3950"/>
        <source>&amp;Terminate call.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3960"/>
        <source>&amp;Generate random Gemini (AES-256).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3994"/>
        <source>Connected securely to the kernel on port %1 from local port %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4584"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4586"/>
        <source>Friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4657"/>
        <location filename="../GUI/spot-on-a.cc" line="4709"/>
        <source>User %1 requests your friendship.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3885"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1178"/>
        <location filename="../GUI/spot-on-a.cc" line="1182"/>
        <source>Broadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3300"/>
        <source>Are you sure that you wish to replace the existing passphrase? Please note that URL data must be re-encoded via a separate tool. Please see the Tools folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3534"/>
        <source>Initializing country_inclusion.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3612"/>
        <location filename="../GUI/spot-on-b.cc" line="4425"/>
        <source>Spot-On: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3626"/>
        <source>Spot-On: Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3629"/>
        <source>Would you like the kernel to be activated?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3887"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3844"/>
        <location filename="../GUI/spot-on-a.cc" line="3901"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3846"/>
        <location filename="../GUI/spot-on-a.cc" line="3903"/>
        <source>Delete &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3816"/>
        <location filename="../GUI/spot-on-a.cc" line="3926"/>
        <source>&amp;Add participant as friend.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="75"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="512"/>
        <location filename="../GUI/spot-on-b.cc" line="4214"/>
        <source>Are you sure that you wish to remove the selected participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="747"/>
        <location filename="../GUI/spot-on-b.cc" line="752"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1699"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1789"/>
        <location filename="../GUI/spot-on-b.cc" line="1978"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1854"/>
        <source>Invalid repleo. The repleo must start with either the letter R or the letter r.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1967"/>
        <source>Invalid public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="68"/>
        <location filename="../GUI/spot-on-b.cc" line="2309"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2317"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2422"/>
        <source>Queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2657"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2660"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2662"/>
        <source>From/To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2881"/>
        <source>Spot-On: Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2881"/>
        <source>&amp;Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4273"/>
        <source>Please provide an IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4321"/>
        <source>Unable to store the IP address securely.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4417"/>
        <source>The following ciphers were discovered. Please note that Spot-On may override discovered ciphers if the ciphers are not supported by Qt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4422"/>
        <source>Empty cipher list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1744"/>
        <source>You&apos;re attempting to add your own &apos;chat&apos; keys. Please do not do this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="48"/>
        <location filename="../GUI/spot-on-b.cc" line="3273"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="53"/>
        <location filename="../GUI/spot-on-b.cc" line="3270"/>
        <source>Connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="58"/>
        <source>Please provide a message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1684"/>
        <location filename="../GUI/spot-on-b.cc" line="1839"/>
        <source>Empty key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1709"/>
        <location filename="../GUI/spot-on-b.cc" line="1864"/>
        <location filename="../GUI/spot-on-b.cc" line="1897"/>
        <location filename="../GUI/spot-on-b.cc" line="1944"/>
        <source>Irregular data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1721"/>
        <location filename="../GUI/spot-on-b.cc" line="1957"/>
        <source>Invalid key type. Expecting &apos;chat&apos;, &apos;email&apos;, or &apos;url&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1736"/>
        <location filename="../GUI/spot-on-b.cc" line="1754"/>
        <source>Unable to retrieve your public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1762"/>
        <source>You&apos;re attempting to add your own &apos;email&apos; keys. Please do not do this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1774"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, or &apos;url&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1887"/>
        <source>Asymmetric decryption failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1918"/>
        <location filename="../GUI/spot-on-b.cc" line="3970"/>
        <source>Unable to compute a keyed hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1925"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1935"/>
        <source>Symmetric decryption failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2892"/>
        <source>The provided goldbug may be incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2899"/>
        <source>A severe memory issue occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2943"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2946"/>
        <source>&lt;b&gt;To:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2948"/>
        <location filename="../GUI/spot-on-b.cc" line="2976"/>
        <location filename="../GUI/spot-on-b.cc" line="2992"/>
        <source>&lt;b&gt;Subject:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2951"/>
        <location filename="../GUI/spot-on-b.cc" line="2979"/>
        <location filename="../GUI/spot-on-b.cc" line="2995"/>
        <source>&lt;b&gt;Sent: &lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2958"/>
        <location filename="../GUI/spot-on-b.cc" line="2964"/>
        <location filename="../GUI/spot-on-b.cc" line="2966"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2971"/>
        <source>&lt;b&gt;From:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2973"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2986"/>
        <location filename="../GUI/spot-on-b.cc" line="2989"/>
        <source>&lt;b&gt;From/To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3000"/>
        <location filename="../GUI/spot-on-b.cc" line="3006"/>
        <location filename="../GUI/spot-on-b.cc" line="3008"/>
        <location filename="../GUI/spot-on-b.cc" line="3061"/>
        <source>Deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3206"/>
        <source>Are you sure that you wish to empty the Trash folder?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3786"/>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3958"/>
        <source>Please provide a channel name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4114"/>
        <source>Generating SSL data for kernel socket. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4470"/>
        <location filename="../GUI/spot-on-b.cc" line="4566"/>
        <source>Invalid listener OID. Please select a listener.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4475"/>
        <source>The selected listener does not support SSL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4481"/>
        <source>Please provide an account name and a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4486"/>
        <source>Please provide a password having at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4585"/>
        <source>Please select an account to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4799"/>
        <source>Remote user %1 is requesting authentication credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2053"/>
        <source>Are you sure that you wish to reset Spot-On? All data will be lost.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzpage</name>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="205"/>
        <source>Empty kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="210"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="215"/>
        <source>Connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="220"/>
        <source>Please provide a message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="227"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="277"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="596"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="645"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="657"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="702"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="435"/>
        <source>&lt;i&gt;%1 has joined %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="458"/>
        <source>&lt;i&gt;%1 is now known as %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="516"/>
        <source>&lt;i&gt;%1 has left %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="597"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="658"/>
        <source>Invalid spoton_crypt object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="646"/>
        <source>An error occurred while attempting to save the channel data. Please enable logging and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="703"/>
        <source>An error occurred while attempting to remove the channel data. Please enable logging and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_chatwindow</name>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="59"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="61"/>
        <source>Spot-On: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="127"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="132"/>
        <source>Connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="137"/>
        <source>Please provide a message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="145"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="181"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_logviewer</name>
    <message>
        <location filename="../UI/logviewer.ui" line="14"/>
        <source>Spot-On: Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="62"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="81"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="87"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="98"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="103"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="111"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_mainwindow</name>
    <message>
        <location filename="../UI/controlcenter.ui" line="365"/>
        <location filename="../UI/controlcenter.ui" line="715"/>
        <location filename="../UI/controlcenter.ui" line="2852"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="145"/>
        <location filename="../UI/controlcenter.ui" line="415"/>
        <location filename="../UI/controlcenter.ui" line="1155"/>
        <location filename="../UI/controlcenter.ui" line="3107"/>
        <location filename="../UI/controlcenter.ui" line="3749"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="497"/>
        <location filename="../UI/controlcenter.ui" line="1114"/>
        <location filename="../UI/controlcenter.ui" line="3795"/>
        <source>public_key_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="655"/>
        <location filename="../UI/controlcenter.ui" line="1054"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="892"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1821"/>
        <location filename="../UI/controlcenter.ui" line="2956"/>
        <location filename="../UI/controlcenter.ui" line="3912"/>
        <location filename="../UI/controlcenter.ui" line="4035"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="757"/>
        <source>Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="957"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="970"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1961"/>
        <source>&amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1411"/>
        <location filename="../UI/controlcenter.ui" line="2222"/>
        <source>Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1416"/>
        <location filename="../UI/controlcenter.ui" line="2227"/>
        <source>Local Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1426"/>
        <location filename="../UI/controlcenter.ui" line="2262"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3511"/>
        <source>Set Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3674"/>
        <source>Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2135"/>
        <location filename="../UI/controlcenter.ui" line="4202"/>
        <source>Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2247"/>
        <source>Remote IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2252"/>
        <source>Remote Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2364"/>
        <source>Add Neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2197"/>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1496"/>
        <location filename="../UI/controlcenter.ui" line="2458"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1543"/>
        <location filename="../UI/controlcenter.ui" line="2448"/>
        <location filename="../UI/controlcenter.ui" line="2623"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1569"/>
        <location filename="../UI/controlcenter.ui" line="2429"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1585"/>
        <location filename="../UI/controlcenter.ui" line="2474"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="608"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="603"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2202"/>
        <source>UUID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1431"/>
        <location filename="../UI/controlcenter.ui" line="2232"/>
        <source>External IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="53"/>
        <source>&amp;Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="70"/>
        <source>&amp;Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="84"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="92"/>
        <source>Demagnetize link.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="99"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="132"/>
        <location filename="../UI/controlcenter.ui" line="402"/>
        <location filename="../UI/controlcenter.ui" line="1764"/>
        <location filename="../UI/controlcenter.ui" line="3736"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="152"/>
        <source>&amp;Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="215"/>
        <source>Join</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="445"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="507"/>
        <source>Last Status Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="512"/>
        <source>Gemini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="583"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="676"/>
        <source>&amp;E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="712"/>
        <source>Clear contents of current view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="728"/>
        <source>Empty Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="741"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="754"/>
        <source>Request e-mail from other participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="783"/>
        <source>&amp;Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="804"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="809"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="814"/>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="845"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="877"/>
        <location filename="../UI/controlcenter.ui" line="1249"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="882"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="897"/>
        <source>goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="902"/>
        <source>message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="907"/>
        <source>message_digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="912"/>
        <source>receiver_sender_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="935"/>
        <source>&amp;Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="947"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="990"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1011"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1044"/>
        <source>Sign &amp;messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1178"/>
        <source>&amp;C/O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1254"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1259"/>
        <source>Recipient Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1272"/>
        <source>Data that has not been processed in more than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1289"/>
        <source>&amp;day(s) will be purged automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1319"/>
        <source>&amp;Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1406"/>
        <location filename="../UI/controlcenter.ui" line="2212"/>
        <source>SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1436"/>
        <location filename="../UI/controlcenter.ui" line="2237"/>
        <source>External Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1451"/>
        <location filename="../UI/controlcenter.ui" line="2287"/>
        <source>Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1456"/>
        <source>Use Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1469"/>
        <source>Add Listener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1481"/>
        <source>The uniqueness of a listener is defined by the local IP, the local port, and the scope ID.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1626"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Record the current external IP address in the listener&apos;s certificate. Please do not use this option if you have a dynamic IP address.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1629"/>
        <source>&amp;Ip Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1636"/>
        <source>&amp;Permanent Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1646"/>
        <location filename="../UI/controlcenter.ui" line="2080"/>
        <location filename="../UI/controlcenter.ui" line="2548"/>
        <location filename="../UI/controlcenter.ui" line="3293"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1660"/>
        <location filename="../UI/controlcenter.ui" line="2097"/>
        <location filename="../UI/controlcenter.ui" line="2562"/>
        <location filename="../UI/controlcenter.ui" line="3310"/>
        <location filename="../UI/controlcenter.ui" line="3552"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1670"/>
        <location filename="../UI/controlcenter.ui" line="2107"/>
        <location filename="../UI/controlcenter.ui" line="2572"/>
        <location filename="../UI/controlcenter.ui" line="3320"/>
        <location filename="../UI/controlcenter.ui" line="3562"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1599"/>
        <location filename="../UI/controlcenter.ui" line="2498"/>
        <source>&amp;Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1613"/>
        <location filename="../UI/controlcenter.ui" line="2512"/>
        <source>Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1618"/>
        <location filename="../UI/controlcenter.ui" line="2517"/>
        <source>Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1740"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1833"/>
        <source>&amp;Countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1843"/>
        <source>&amp;IP Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1850"/>
        <source>Accepted Countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1880"/>
        <source>Toggle All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1914"/>
        <source>Accepted IP Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1981"/>
        <source>Copy Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1994"/>
        <source>Share my specified public key with the selected neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1997"/>
        <source>Share Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2045"/>
        <source>Select this option if you would like to accept and connect to published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2055"/>
        <source>Select this option if you would like to accept published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2217"/>
        <source>Status Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2242"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2267"/>
        <source>Proxy Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2272"/>
        <source>Proxy Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2297"/>
        <source>Allow Certificate Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2302"/>
        <source>Certificate Digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2307"/>
        <source>Bytes Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2312"/>
        <source>Bytes Written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2317"/>
        <source>SSL Session Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2322"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2327"/>
        <source>Account Authenticated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2332"/>
        <source>is_encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2376"/>
        <source>The uniqueness of a neighbor is defined by the proxy hostname, the proxy port, the remote IP, the remote port, and the scope ID.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2481"/>
        <source>Dynamic DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2484"/>
        <source>&amp;DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2525"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On will record peer certificates during initial connections. Subsequent connections will cause Spot-On to inspect peer certificates. If there are discrepancies between recorded certificates and transmitted certificates, Spot-On will sever the connections. Enable this option if you would like Spot-On to ignore discrepancies.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2535"/>
        <source>Require secure connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2538"/>
        <source>&amp;Require SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3050"/>
        <source>&amp;GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3114"/>
        <source>Display a list of ciphers produced by the provided SSL Control String.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3117"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3245"/>
        <source>randomized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3538"/>
        <source>&amp;Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3580"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3597"/>
        <source>ElGamal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3602"/>
        <location filename="../UI/controlcenter.ui" line="3632"/>
        <source>RSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3610"/>
        <source>&amp;Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3627"/>
        <source>DSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4292"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://sourceforge.net/p/spot-on/code/HEAD/tree/branches/0.06/Documentation/RELEASE-NOTES&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Version 0.06&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4422"/>
        <source>&amp;East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4433"/>
        <source>&amp;North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4441"/>
        <source>&amp;West</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="198"/>
        <location filename="../UI/controlcenter.ui" line="2600"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="185"/>
        <source>&amp;Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1346"/>
        <source>Periodically p&amp;ublish plaintext information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2582"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2610"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2633"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1774"/>
        <location filename="../UI/controlcenter.ui" line="2646"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2675"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2680"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2685"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2882"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2922"/>
        <source>Fetch!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2976"/>
        <source>&lt; 1 .. 1 &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3009"/>
        <source>S&amp;ettings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3144"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3174"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3187"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3204"/>
        <source>Spot-On-Kernel &amp;Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3253"/>
        <source>&amp;Congestion Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3263"/>
        <source>Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3328"/>
        <source>If enabled, messages that are deciphered correctly will be forwarded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3523"/>
        <source>Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3535"/>
        <source>If checked, new RSA key pairs will be generated whenever the passphrase is updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3487"/>
        <source>P&amp;assphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4393"/>
        <source>Nuvola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4401"/>
        <source>Nouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4409"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4414"/>
        <source>&amp;Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4406"/>
        <source>&amp;Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1396"/>
        <location filename="../UI/controlcenter.ui" line="3161"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="502"/>
        <location filename="../UI/controlcenter.ui" line="887"/>
        <location filename="../UI/controlcenter.ui" line="1401"/>
        <location filename="../UI/controlcenter.ui" line="2207"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1421"/>
        <location filename="../UI/controlcenter.ui" line="2257"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1509"/>
        <location filename="../UI/controlcenter.ui" line="2403"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="435"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="440"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="450"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="482"/>
        <location filename="../UI/controlcenter.ui" line="1099"/>
        <location filename="../UI/controlcenter.ui" line="3780"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="492"/>
        <location filename="../UI/controlcenter.ui" line="1109"/>
        <location filename="../UI/controlcenter.ui" line="3790"/>
        <source>neighbor_oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1446"/>
        <source>Max. Conn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1523"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1691"/>
        <location filename="../UI/controlcenter.ui" line="1814"/>
        <location filename="../UI/controlcenter.ui" line="1940"/>
        <location filename="../UI/controlcenter.ui" line="2759"/>
        <location filename="../UI/controlcenter.ui" line="2845"/>
        <location filename="../UI/controlcenter.ui" line="3905"/>
        <location filename="../UI/controlcenter.ui" line="4028"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2784"/>
        <source>Add Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2801"/>
        <source>&amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2811"/>
        <source>&amp;Repleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2999"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3197"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3063"/>
        <location filename="../UI/controlcenter.ui" line="3217"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3407"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1665"/>
        <location filename="../UI/controlcenter.ui" line="2102"/>
        <location filename="../UI/controlcenter.ui" line="2567"/>
        <location filename="../UI/controlcenter.ui" line="3315"/>
        <location filename="../UI/controlcenter.ui" line="3557"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3567"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3572"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3430"/>
        <source>Salt &amp;Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3470"/>
        <location filename="../UI/controlcenter.ui" line="4185"/>
        <source>P&amp;assphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3497"/>
        <source>Minimum of 16 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3830"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3860"/>
        <location filename="../UI/controlcenter.ui" line="3983"/>
        <source>&amp;Accept List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3870"/>
        <location filename="../UI/controlcenter.ui" line="3993"/>
        <source>&amp;Deny List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3953"/>
        <source>&amp;Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="235"/>
        <source>&amp;Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="165"/>
        <source>&amp;Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="296"/>
        <location filename="../UI/controlcenter.ui" line="835"/>
        <source>&amp;Accept only signed messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="306"/>
        <source>&amp;Sign messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="335"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="385"/>
        <location filename="../UI/controlcenter.ui" line="3719"/>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="487"/>
        <location filename="../UI/controlcenter.ui" line="917"/>
        <location filename="../UI/controlcenter.ui" line="1104"/>
        <location filename="../UI/controlcenter.ui" line="1461"/>
        <location filename="../UI/controlcenter.ui" line="2337"/>
        <location filename="../UI/controlcenter.ui" line="3785"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="525"/>
        <source>&amp;Hide offline participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1008"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle the e-mail with an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1031"/>
        <source>&amp;Save copies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1041"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The kernel is responsible for signing messages. Because messages are queued, please avoid toggling this checkbox until queued message have been processed by the kernel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1137"/>
        <source>&amp;From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1195"/>
        <source>&amp;Enable C/O service.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1202"/>
        <source>&amp;Reject messages without signatures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1441"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1978"/>
        <source>Copy my name and the specified public key to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2048"/>
        <source>&amp;Accept published listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2058"/>
        <source>&amp;Accept published listeners (disconnected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2068"/>
        <source>&amp;Ignore published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2142"/>
        <source>&amp;Keep only user-defined neighbors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2277"/>
        <source>Max. Buffer Size (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2282"/>
        <source>Max. Content Length (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2292"/>
        <source>Uptime (Seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2528"/>
        <source>&amp;Allow Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3231"/>
        <location filename="../UI/controlcenter.ui" line="3373"/>
        <source>&amp;Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3279"/>
        <source>&amp;Log Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3286"/>
        <source>&amp;Scrambler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3331"/>
        <source>S&amp;uper Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3356"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3390"/>
        <source>&amp;Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3090"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3100"/>
        <source>HIGH:!aNULL:!eNULL:!3DES:!EXPORT:@STRENGTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3703"/>
        <source>&amp;URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3800"/>
        <location filename="../UI/controlcenter.ui" line="3805"/>
        <source>ignored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3814"/>
        <source>URL Distillers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4136"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;quot;The Dalmatian is a breed of dog, noted for its unique black- or brown-spotted coat. This dog is often used as a rescue dog, guardian, athletic partner, and, especially today, the Dalmatian remains most often an active, well-loved family member.&amp;quot; - Wikipedia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4261"/>
        <source>Spot-On Graphical User Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4308"/>
        <source>Build Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4348"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4356"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4360"/>
        <source>&amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4367"/>
        <source>&amp;Tab Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4382"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4385"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statusbar</name>
    <message>
        <location filename="../UI/statusbar.ui" line="77"/>
        <source>Buzz activity!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="90"/>
        <source>You have received a new message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="106"/>
        <source>New e-mail has arrived!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="135"/>
        <source>Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
