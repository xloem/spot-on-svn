<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="kk_KZ">
<context>
    <name>QObject</name>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="179"/>
        <source>gcry_cipher_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="188"/>
        <source>gcry_md_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="197"/>
        <location filename="../Common/spot-on-crypt.cc" line="567"/>
        <location filename="../Common/spot-on-crypt.cc" line="744"/>
        <source>gcry_cipher_get_algo_keylen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="208"/>
        <source>gcry_calloc_secure() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="231"/>
        <source>gcry_kdf_derive() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="352"/>
        <source>gcry_md_get_algo_dlen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="431"/>
        <source>oldPassphrase is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="515"/>
        <source>gcry_cipher_open() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="527"/>
        <source>gcry_cipher_open() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="538"/>
        <location filename="../Common/spot-on-crypt.cc" line="703"/>
        <location filename="../Common/spot-on-crypt.cc" line="713"/>
        <source>gcry_cipher_get_algo_blklen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="552"/>
        <location filename="../Common/spot-on-crypt.cc" line="736"/>
        <source>gcry_cipher_setiv() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="579"/>
        <location filename="../Common/spot-on-crypt.cc" line="757"/>
        <source>gcry_cipher_setkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="471"/>
        <source>error retrieving data from the idiotes table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="326"/>
        <source>empty passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="333"/>
        <source>empty salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="340"/>
        <source>gcry_md_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="499"/>
        <source>gcry_cipher_map_name() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="613"/>
        <source>The length of the decrypted data is irregular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="624"/>
        <source>gcry_cipher_decrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="649"/>
        <source>gcry_sexp_new() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="661"/>
        <source>gcry_sexp_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="672"/>
        <source>gcry_pk_testkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="693"/>
        <source>gcry_cipher_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="723"/>
        <source>gcry_calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="786"/>
        <source>gcry_cipher_encrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2089"/>
        <source>gcry_sexp_build() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2113"/>
        <source>gcry_pk_genkey() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2141"/>
        <source>gcry_sexp_find_token() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2152"/>
        <location filename="../Common/spot-on-crypt.cc" line="2167"/>
        <source>gcry_sexp_sprint() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2185"/>
        <source>malloc() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2223"/>
        <source>QSqlQuery::exec() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2232"/>
        <source>encrypted() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2971"/>
        <source>BN_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2979"/>
        <source>BN_set_word() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2987"/>
        <source>RSA_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2995"/>
        <source>RSA_generate_key_ex() returned negative one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3003"/>
        <location filename="../Common/spot-on-crypt.cc" line="3011"/>
        <location filename="../Common/spot-on-crypt.cc" line="3264"/>
        <source>BIO_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3019"/>
        <source>PEM_write_bio_RSAPrivateKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3027"/>
        <source>PEM_write_bio_RSAPublicKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3037"/>
        <location filename="../Common/spot-on-crypt.cc" line="3051"/>
        <location filename="../Common/spot-on-crypt.cc" line="3182"/>
        <location filename="../Common/spot-on-crypt.cc" line="3282"/>
        <source>calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3116"/>
        <source>rsa container is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3124"/>
        <source>EVP_PKEY_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3133"/>
        <source>X509_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3142"/>
        <source>EVP_PKEY_assign_RSA() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3154"/>
        <source>X509_set_version() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3162"/>
        <location filename="../Common/spot-on-crypt.cc" line="3170"/>
        <source>X509_gmtime_adj() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3200"/>
        <source>X509_NAME_ENTRY_create_by_NID() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3210"/>
        <source>X509_NAME_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3218"/>
        <source>X509_NAME_add_entry() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3226"/>
        <source>X509_set_subject_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3236"/>
        <source>X509_set_issuer_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3244"/>
        <source>X509_set_pubkey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3252"/>
        <source>X509_sign() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3272"/>
        <source>PEM_write_bio_X509() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="124"/>
        <source>Re-encoding email.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="58"/>
        <source>Re-encoding buzz_channels.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="283"/>
        <source>Re-encoding listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="547"/>
        <location filename="../GUI/spot-on-reencode.cc" line="828"/>
        <source>Re-encoding neighbors.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="994"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>buzzPage</name>
    <message>
        <location filename="../UI/buzzpage.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="45"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="52"/>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="31"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="65"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="95"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="115"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="140"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="145"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="150"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="194"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="214"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="219"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="266"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chatwindow</name>
    <message>
        <location filename="../UI/chatwindow.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="36"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="43"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="63"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="103"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>passwordprompt</name>
    <message>
        <location filename="../UI/passwordprompt.ui" line="14"/>
        <source>Spot-On: Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="30"/>
        <source>Please provide the following credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="42"/>
        <source>Account &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="55"/>
        <source>Account &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton</name>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3411"/>
        <source>Spot-On: Select Kernel Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3394"/>
        <location filename="../GUI/spot-on-a.cc" line="3414"/>
        <location filename="../GUI/spot-on-c.cc" line="450"/>
        <location filename="../GUI/spot-on-c.cc" line="786"/>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1480"/>
        <location filename="../GUI/spot-on-a.cc" line="1754"/>
        <location filename="../GUI/spot-on-a.cc" line="1759"/>
        <location filename="../GUI/spot-on-a.cc" line="1772"/>
        <location filename="../GUI/spot-on-a.cc" line="2078"/>
        <location filename="../GUI/spot-on-a.cc" line="2083"/>
        <location filename="../GUI/spot-on-a.cc" line="3790"/>
        <location filename="../GUI/spot-on-a.cc" line="3799"/>
        <location filename="../GUI/spot-on-a.cc" line="3984"/>
        <location filename="../GUI/spot-on-a.cc" line="3991"/>
        <location filename="../GUI/spot-on-a.cc" line="4002"/>
        <location filename="../GUI/spot-on-a.cc" line="6124"/>
        <location filename="../GUI/spot-on-a.cc" line="6137"/>
        <location filename="../GUI/spot-on-a.cc" line="6210"/>
        <location filename="../GUI/spot-on-a.cc" line="6475"/>
        <location filename="../GUI/spot-on-a.cc" line="6523"/>
        <location filename="../GUI/spot-on-b.cc" line="145"/>
        <location filename="../GUI/spot-on-b.cc" line="1388"/>
        <location filename="../GUI/spot-on-b.cc" line="1395"/>
        <location filename="../GUI/spot-on-b.cc" line="1403"/>
        <location filename="../GUI/spot-on-b.cc" line="1414"/>
        <location filename="../GUI/spot-on-b.cc" line="1427"/>
        <location filename="../GUI/spot-on-b.cc" line="1443"/>
        <location filename="../GUI/spot-on-b.cc" line="1454"/>
        <location filename="../GUI/spot-on-b.cc" line="1463"/>
        <location filename="../GUI/spot-on-b.cc" line="1475"/>
        <location filename="../GUI/spot-on-b.cc" line="1490"/>
        <location filename="../GUI/spot-on-b.cc" line="1540"/>
        <location filename="../GUI/spot-on-b.cc" line="1547"/>
        <location filename="../GUI/spot-on-b.cc" line="1555"/>
        <location filename="../GUI/spot-on-b.cc" line="1566"/>
        <location filename="../GUI/spot-on-b.cc" line="1596"/>
        <location filename="../GUI/spot-on-b.cc" line="1609"/>
        <location filename="../GUI/spot-on-b.cc" line="1631"/>
        <location filename="../GUI/spot-on-b.cc" line="1638"/>
        <location filename="../GUI/spot-on-b.cc" line="1649"/>
        <location filename="../GUI/spot-on-b.cc" line="1659"/>
        <location filename="../GUI/spot-on-b.cc" line="1673"/>
        <location filename="../GUI/spot-on-b.cc" line="1717"/>
        <location filename="../GUI/spot-on-b.cc" line="1730"/>
        <location filename="../GUI/spot-on-b.cc" line="1741"/>
        <location filename="../GUI/spot-on-b.cc" line="2069"/>
        <location filename="../GUI/spot-on-b.cc" line="2077"/>
        <location filename="../GUI/spot-on-b.cc" line="2777"/>
        <location filename="../GUI/spot-on-b.cc" line="2784"/>
        <location filename="../GUI/spot-on-b.cc" line="3202"/>
        <location filename="../GUI/spot-on-b.cc" line="4030"/>
        <location filename="../GUI/spot-on-b.cc" line="4228"/>
        <location filename="../GUI/spot-on-b.cc" line="4249"/>
        <location filename="../GUI/spot-on-b.cc" line="4259"/>
        <location filename="../GUI/spot-on-b.cc" line="4325"/>
        <location filename="../GUI/spot-on-b.cc" line="4335"/>
        <location filename="../GUI/spot-on-b.cc" line="4355"/>
        <location filename="../GUI/spot-on-b.cc" line="4373"/>
        <location filename="../GUI/spot-on-b.cc" line="4597"/>
        <location filename="../GUI/spot-on-b.cc" line="4612"/>
        <location filename="../GUI/spot-on-b.cc" line="4632"/>
        <location filename="../GUI/spot-on-b.cc" line="4642"/>
        <location filename="../GUI/spot-on-c.cc" line="199"/>
        <location filename="../GUI/spot-on-c.cc" line="979"/>
        <location filename="../GUI/spot-on-c.cc" line="1501"/>
        <location filename="../GUI/spot-on-c.cc" line="1511"/>
        <location filename="../GUI/spot-on-c.cc" line="1560"/>
        <location filename="../GUI/spot-on-c.cc" line="1627"/>
        <location filename="../GUI/spot-on-c.cc" line="1637"/>
        <location filename="../GUI/spot-on-c.cc" line="2261"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="817"/>
        <location filename="../GUI/spot-on-a.cc" line="4618"/>
        <source>Not connected to the kernel. Is the kernel active?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2427"/>
        <location filename="../GUI/spot-on-a.cc" line="2429"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2891"/>
        <source>The sticky feature enables an indefinite lifetime for a neighbor.
If not checked, the neighbor will be terminated after some internal timer expires.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3791"/>
        <source>The passphrases must contain at least sixteen characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3816"/>
        <location filename="../GUI/spot-on-b.cc" line="556"/>
        <location filename="../GUI/spot-on-b.cc" line="1812"/>
        <location filename="../GUI/spot-on-b.cc" line="3128"/>
        <location filename="../GUI/spot-on-b.cc" line="4176"/>
        <location filename="../GUI/spot-on-c.cc" line="2190"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3941"/>
        <source>Generating public key %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4367"/>
        <location filename="../GUI/spot-on-a.cc" line="4507"/>
        <source>&amp;Remove participant(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4597"/>
        <source>Connected insecurely to the kernel on port %1 from local port %2. Communications between the interface and the kernel have been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5170"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5172"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5071"/>
        <location filename="../GUI/spot-on-a.cc" line="5174"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="134"/>
        <location filename="../GUI/spot-on-a.cc" line="137"/>
        <source>Spot-On was configured without libGeoIP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="143"/>
        <location filename="../GUI/spot-on-a.cc" line="146"/>
        <source>Spot-On was configured without libphoton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="819"/>
        <location filename="../GUI/spot-on-a.cc" line="2595"/>
        <source>Listeners are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="820"/>
        <location filename="../GUI/spot-on-a.cc" line="3199"/>
        <source>Neighbors are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="835"/>
        <source>Copy &amp;All Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4412"/>
        <source>Share &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1439"/>
        <source>Preparing databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="825"/>
        <source>Copy &amp;Chat Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="828"/>
        <source>Copy &amp;E-Mail Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="831"/>
        <source>Copy &amp;URL Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="839"/>
        <source>Share &amp;Chat Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="841"/>
        <source>Share &amp;E-Mail Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="843"/>
        <source>Share &amp;URL Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1502"/>
        <source>Generating SSL data for listener. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1755"/>
        <source>Unable to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1760"/>
        <source>An error (%1) occurred while attempting to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2079"/>
        <source>Unable to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2084"/>
        <source>An error (%1) occurred while attempting to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2283"/>
        <location filename="../GUI/spot-on-a.cc" line="2507"/>
        <location filename="../GUI/spot-on-a.cc" line="2753"/>
        <location filename="../GUI/spot-on-a.cc" line="2776"/>
        <location filename="../GUI/spot-on-a.cc" line="2944"/>
        <location filename="../GUI/spot-on-a.cc" line="3037"/>
        <location filename="../GUI/spot-on-a.cc" line="5196"/>
        <location filename="../GUI/spot-on-b.cc" line="2607"/>
        <location filename="../GUI/spot-on-b.cc" line="2625"/>
        <location filename="../GUI/spot-on-b.cc" line="2706"/>
        <location filename="../GUI/spot-on-b.cc" line="2722"/>
        <location filename="../GUI/spot-on-c.cc" line="271"/>
        <location filename="../GUI/spot-on-c.cc" line="290"/>
        <location filename="../GUI/spot-on-c.cc" line="1125"/>
        <location filename="../GUI/spot-on-c.cc" line="1254"/>
        <location filename="../GUI/spot-on-c.cc" line="1256"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2297"/>
        <source>Status: %1
SSL Key Size: %2
Local IP: %3 Local Port: %4 Scope ID: %5
External IP: %6
Connections: %7
Echo Mode: %8
Use Accounts: %9
Transport: %10
Share Address: %11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2588"/>
        <source>There is (are) %1 active listener(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3188"/>
        <source>There is (are) %1 connected neighbor(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3381"/>
        <source>External IP: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3391"/>
        <source>Spot-On: Select GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3800"/>
        <source>The passphrases are not identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3840"/>
        <source>Generating a derived key. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3884"/>
        <source>Re-encoding public key pair %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3935"/>
        <location filename="../GUI/spot-on-c.cc" line="2226"/>
        <source>Generating public key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3985"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKey().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4003"/>
        <source>An error (%1) occurred with spoton_crypt::saltedPassphraseHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4141"/>
        <source>Your confidential information has been recorded. You are now ready to use the full power of Spot-On. Enjoy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4424"/>
        <source>&amp;Reset Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4428"/>
        <source>&amp;Reset Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4494"/>
        <source>&amp;Generate random Gemini pair (AES-256 Key, SHA-512 Key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4522"/>
        <location filename="../GUI/spot-on-a.cc" line="4543"/>
        <source>&amp;Compute SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4589"/>
        <source>Connected securely to the kernel on port %1 from local port %2 via cipher %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6138"/>
        <source>Invalid neighbor OID. Please select a neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6211"/>
        <source>The account name must be non-empty and the account password must contain at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6380"/>
        <location filename="../GUI/spot-on-a.cc" line="6490"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6470"/>
        <location filename="../GUI/spot-on-c.cc" line="186"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6500"/>
        <source>Invalid clipboard object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4381"/>
        <source>Detach &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4383"/>
        <source>Disconnect &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4386"/>
        <source>&amp;Publish Information (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4388"/>
        <source>Publish &amp;All (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4421"/>
        <source>&amp;Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4439"/>
        <source>Delete All Non-Unique &amp;Blocked Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4441"/>
        <source>Delete All Non-Unique &amp;UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4444"/>
        <source>B&amp;lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4446"/>
        <source>U&amp;nblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4391"/>
        <location filename="../GUI/spot-on-a.cc" line="4449"/>
        <source>&amp;Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4393"/>
        <location filename="../GUI/spot-on-a.cc" line="4451"/>
        <source>&amp;Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4475"/>
        <source>&amp;Call participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4361"/>
        <location filename="../GUI/spot-on-a.cc" line="4472"/>
        <source>&amp;Copy Repleo to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4402"/>
        <source>Share &amp;Chat Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4407"/>
        <source>Share &amp;E-Mail Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1481"/>
        <location filename="../GUI/spot-on-a.cc" line="1773"/>
        <location filename="../GUI/spot-on-a.cc" line="6125"/>
        <location filename="../GUI/spot-on-a.cc" line="6431"/>
        <location filename="../GUI/spot-on-b.cc" line="1389"/>
        <location filename="../GUI/spot-on-b.cc" line="1541"/>
        <location filename="../GUI/spot-on-b.cc" line="3905"/>
        <location filename="../GUI/spot-on-b.cc" line="4229"/>
        <location filename="../GUI/spot-on-b.cc" line="4336"/>
        <location filename="../GUI/spot-on-b.cc" line="4493"/>
        <location filename="../GUI/spot-on-b.cc" line="4613"/>
        <location filename="../GUI/spot-on-c.cc" line="93"/>
        <location filename="../GUI/spot-on-c.cc" line="820"/>
        <location filename="../GUI/spot-on-c.cc" line="1502"/>
        <location filename="../GUI/spot-on-c.cc" line="1628"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2780"/>
        <source>UUID: %1
Status: %2
SSL Key Size: %3
Local IP: %4 Local Port: %5
External IP: %6
Country: %7 Remote IP: %8 Remote Port: %9 Scope ID: %10
Proxy Hostname: %11 Proxy Port: %12
Echo Mode: %13
Communications Mode: %14
Uptime: %15 Minutes
Allow Certificate Exceptions: %16
Bytes Read: %17
Bytes Written: %18
SSL Session Cipher: %19
Account Name: %20
Account Authenticated: %21
Transport: %22</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3819"/>
        <source>Are you sure that you wish to replace the existing passphrase? Please note that URL data must be re-encoded via a separate tool. Please see the future Tools folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3992"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys() or spoton_crypt::reencodeKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4484"/>
        <source>&amp;Terminate call.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4527"/>
        <location filename="../GUI/spot-on-a.cc" line="4548"/>
        <source>&amp;Copy File Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5176"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5178"/>
        <source>Friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5253"/>
        <location filename="../GUI/spot-on-a.cc" line="5306"/>
        <source>User %1 requests your friendship.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4415"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1400"/>
        <location filename="../GUI/spot-on-a.cc" line="1404"/>
        <source>Broadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4140"/>
        <location filename="../GUI/spot-on-b.cc" line="4468"/>
        <source>Spot-On: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4154"/>
        <source>Spot-On: Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4157"/>
        <source>Would you like the kernel to be activated?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4417"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4376"/>
        <location filename="../GUI/spot-on-a.cc" line="4435"/>
        <location filename="../GUI/spot-on-a.cc" line="4516"/>
        <location filename="../GUI/spot-on-a.cc" line="4537"/>
        <location filename="../GUI/spot-on-c.cc" line="329"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4378"/>
        <location filename="../GUI/spot-on-a.cc" line="4437"/>
        <location filename="../GUI/spot-on-a.cc" line="4518"/>
        <location filename="../GUI/spot-on-a.cc" line="4539"/>
        <location filename="../GUI/spot-on-c.cc" line="331"/>
        <source>Delete &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4348"/>
        <location filename="../GUI/spot-on-a.cc" line="4460"/>
        <source>&amp;Add participant as friend.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="78"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="559"/>
        <location filename="../GUI/spot-on-b.cc" line="4179"/>
        <source>Are you sure that you wish to remove the selected participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="806"/>
        <location filename="../GUI/spot-on-b.cc" line="811"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1404"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1491"/>
        <location filename="../GUI/spot-on-b.cc" line="1742"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1556"/>
        <source>Invalid repleo. The repleo must start with either the letter R or the letter r.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1731"/>
        <source>Invalid public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="69"/>
        <location filename="../GUI/spot-on-b.cc" line="2070"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="54"/>
        <location filename="../GUI/spot-on-b.cc" line="3195"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="59"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1396"/>
        <location filename="../GUI/spot-on-b.cc" line="1548"/>
        <source>Empty key. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1415"/>
        <location filename="../GUI/spot-on-b.cc" line="1660"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1567"/>
        <source>Irregular data. Expecting 3 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1597"/>
        <source>Asymmetric decryption failure. Are you attempting to add a repleo that you gathered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1610"/>
        <source>Irregular data. Expecting 2 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1650"/>
        <source>Symmetric decryption failure. Serious!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1815"/>
        <source>Are you sure that you wish to reset Spot-On? All data will be lost. Forever.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2078"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2181"/>
        <source>Queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2526"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2529"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2531"/>
        <source>From/To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2767"/>
        <source>Spot-On: Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2767"/>
        <source>&amp;Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4326"/>
        <source>Unable to record the IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4540"/>
        <source>Please provide an account name and an account password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4545"/>
        <source>Please provide an account password that contains at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4465"/>
        <source>Empty cipher list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="49"/>
        <location filename="../GUI/spot-on-b.cc" line="3198"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1428"/>
        <location filename="../GUI/spot-on-b.cc" line="1674"/>
        <source>Invalid key type. Expecting &apos;chat&apos;, &apos;email&apos;, or &apos;url&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1444"/>
        <source>Unable to retrieve your %1 public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1455"/>
        <source>Unable to retrieve your %1 signature public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1464"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1476"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, or &apos;url&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1632"/>
        <location filename="../GUI/spot-on-b.cc" line="3923"/>
        <source>Unable to compute a keyed hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1639"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1718"/>
        <source>You&apos;re attempting to add your own keys or Spot-On was not able to retrieve your keys for comparison.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2778"/>
        <source>The provided goldbug may be incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2785"/>
        <source>A severe memory issue occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2829"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2832"/>
        <source>&lt;b&gt;To:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2834"/>
        <location filename="../GUI/spot-on-b.cc" line="2862"/>
        <location filename="../GUI/spot-on-b.cc" line="2878"/>
        <source>&lt;b&gt;Subject:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2837"/>
        <location filename="../GUI/spot-on-b.cc" line="2865"/>
        <location filename="../GUI/spot-on-b.cc" line="2881"/>
        <source>&lt;b&gt;Sent: &lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2844"/>
        <location filename="../GUI/spot-on-b.cc" line="2850"/>
        <location filename="../GUI/spot-on-b.cc" line="2852"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2857"/>
        <source>&lt;b&gt;From:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2859"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2872"/>
        <location filename="../GUI/spot-on-b.cc" line="2875"/>
        <source>&lt;b&gt;From/To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2886"/>
        <location filename="../GUI/spot-on-b.cc" line="2892"/>
        <location filename="../GUI/spot-on-b.cc" line="2894"/>
        <location filename="../GUI/spot-on-b.cc" line="2947"/>
        <source>Deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3131"/>
        <source>Are you sure that you wish to empty the Trash folder?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3737"/>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3911"/>
        <source>Please provide a channel name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4076"/>
        <source>Generating SSL data for kernel socket. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4250"/>
        <location filename="../GUI/spot-on-b.cc" line="4356"/>
        <location filename="../GUI/spot-on-b.cc" line="4521"/>
        <location filename="../GUI/spot-on-b.cc" line="4633"/>
        <source>Invalid listener OID. Please select a listener.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4260"/>
        <source>Please provide an IP address or the keyword Any.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4374"/>
        <source>Please select an address to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4460"/>
        <source>The following ciphers were discovered. Please note that Spot-On may neglect discovered ciphers if the ciphers are not supported by Qt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4526"/>
        <source>The selected listener does not support SSL.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4592"/>
        <source>A database error has occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4643"/>
        <source>Please select an account to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4926"/>
        <source>Remote user %1 is requesting authentication credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4555"/>
        <location filename="../GUI/spot-on-c.cc" line="323"/>
        <source>Copy &amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="150"/>
        <source>Invalid magnet. Are you missing tokens?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="447"/>
        <source>Spot-On: Select Destination Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="783"/>
        <source>Spot-On: Select Transmit File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="826"/>
        <source>Please select a file to transfer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="834"/>
        <source>The provided file cannot be accessed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1512"/>
        <source>Please provide a Nova. Reach for the stars!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2193"/>
        <source>Are you sure that you wish to regenerate the selected key pair?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2201"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2203"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2205"/>
        <location filename="../GUI/spot-on-c.cc" line="2254"/>
        <source>Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2207"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2262"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="853"/>
        <source>Please select at least one magnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="963"/>
        <location filename="../GUI/spot-on-c.cc" line="966"/>
        <source>A database error (%1) occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="969"/>
        <source>An error occurred within spoton_crypt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1561"/>
        <source>Unable to store the Nova.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1638"/>
        <source>Please select a Nova to delete.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzpage</name>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="231"/>
        <source>Empty kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="236"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="241"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="246"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="255"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="309"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="634"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="689"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="701"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="752"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="477"/>
        <source>&lt;i&gt;%1 has joined %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="503"/>
        <source>&lt;i&gt;%1 is now known as %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="564"/>
        <source>&lt;i&gt;%1 has left %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="635"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="702"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="690"/>
        <source>An error occurred while attempting to save the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="753"/>
        <source>An error occurred while attempting to remove the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_chatwindow</name>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="59"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="61"/>
        <source>Spot-On: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="128"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="133"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="138"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="148"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="184"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_logviewer</name>
    <message>
        <location filename="../UI/logviewer.ui" line="14"/>
        <source>Spot-On: Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="62"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="81"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="87"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="98"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="103"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="111"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_mainwindow</name>
    <message>
        <location filename="../UI/controlcenter.ui" line="157"/>
        <location filename="../UI/controlcenter.ui" line="296"/>
        <location filename="../UI/controlcenter.ui" line="469"/>
        <location filename="../UI/controlcenter.ui" line="824"/>
        <location filename="../UI/controlcenter.ui" line="3115"/>
        <location filename="../UI/controlcenter.ui" line="4369"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="110"/>
        <location filename="../UI/controlcenter.ui" line="519"/>
        <location filename="../UI/controlcenter.ui" line="1321"/>
        <location filename="../UI/controlcenter.ui" line="3429"/>
        <location filename="../UI/controlcenter.ui" line="5094"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="601"/>
        <location filename="../UI/controlcenter.ui" line="1280"/>
        <location filename="../UI/controlcenter.ui" line="5153"/>
        <source>public_key_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="764"/>
        <location filename="../UI/controlcenter.ui" line="1220"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1058"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2069"/>
        <location filename="../UI/controlcenter.ui" line="2138"/>
        <location filename="../UI/controlcenter.ui" line="3219"/>
        <location filename="../UI/controlcenter.ui" line="4583"/>
        <location filename="../UI/controlcenter.ui" line="5270"/>
        <location filename="../UI/controlcenter.ui" line="5393"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="866"/>
        <source>Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1123"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1136"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2159"/>
        <source>&amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1577"/>
        <location filename="../UI/controlcenter.ui" line="2433"/>
        <source>Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1582"/>
        <location filename="../UI/controlcenter.ui" line="2438"/>
        <source>Local Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1592"/>
        <location filename="../UI/controlcenter.ui" line="2473"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3962"/>
        <source>Set Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4181"/>
        <source>Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2346"/>
        <location filename="../UI/controlcenter.ui" line="5560"/>
        <source>Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2458"/>
        <source>Remote IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2463"/>
        <source>Remote Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2580"/>
        <source>Add Neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2408"/>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1687"/>
        <location filename="../UI/controlcenter.ui" line="2674"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1734"/>
        <location filename="../UI/controlcenter.ui" line="2664"/>
        <location filename="../UI/controlcenter.ui" line="2886"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1760"/>
        <location filename="../UI/controlcenter.ui" line="2645"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1776"/>
        <location filename="../UI/controlcenter.ui" line="2690"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="717"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="712"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2413"/>
        <source>UUID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1597"/>
        <location filename="../UI/controlcenter.ui" line="2443"/>
        <source>External IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="53"/>
        <source>&amp;Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="138"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="146"/>
        <source>Demagnetize link.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="97"/>
        <location filename="../UI/controlcenter.ui" line="506"/>
        <location filename="../UI/controlcenter.ui" line="2012"/>
        <location filename="../UI/controlcenter.ui" line="5081"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="192"/>
        <source>&amp;Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="262"/>
        <source>Hash &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="275"/>
        <source>Hash &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="301"/>
        <source>Generate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="309"/>
        <source>Join</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5035"/>
        <source>Accept &amp;keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="549"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="70"/>
        <source>Accept shared &amp;magnets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="390"/>
        <location filename="../UI/controlcenter.ui" line="893"/>
        <source>Accept shared &amp;keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="611"/>
        <source>Last Status Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="692"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="785"/>
        <source>&amp;E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="821"/>
        <source>Clear contents of current view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="837"/>
        <source>Empty Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="850"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="863"/>
        <source>Request e-mail from other participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="903"/>
        <source>&amp;Retrieve e-mail every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="920"/>
        <source>&amp;minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="949"/>
        <source>&amp;Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="970"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="975"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="980"/>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1011"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1043"/>
        <location filename="../UI/controlcenter.ui" line="1415"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1048"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1063"/>
        <source>goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1068"/>
        <source>message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1073"/>
        <source>message_digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1078"/>
        <source>receiver_sender_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1101"/>
        <source>&amp;Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1113"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1156"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1177"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1210"/>
        <source>Sign &amp;messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1344"/>
        <source>&amp;C/O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1420"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1438"/>
        <source>Data that has not been processed in more than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1455"/>
        <source>&amp;day(s) will be purged automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1637"/>
        <location filename="../UI/controlcenter.ui" line="2543"/>
        <source>Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1642"/>
        <source>Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1672"/>
        <source>The uniqueness of a listener is defined by the local IP, the local port, the scope ID, and the transport.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1783"/>
        <location filename="../UI/controlcenter.ui" line="2707"/>
        <source>&amp;Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1797"/>
        <location filename="../UI/controlcenter.ui" line="2726"/>
        <source>TCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1802"/>
        <location filename="../UI/controlcenter.ui" line="2731"/>
        <source>UDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1815"/>
        <source>&amp;Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2106"/>
        <source>The keyword Any is supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2179"/>
        <source>Copy Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2192"/>
        <source>Share Buzz Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2208"/>
        <source>Share Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2592"/>
        <source>The uniqueness of a neighbor is defined by the proxy hostname, the proxy port, the remote IP, the remote port, the scope ID, and the transport.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3313"/>
        <location filename="../UI/controlcenter.ui" line="3470"/>
        <source>&amp;External IP Retrieval Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3327"/>
        <location filename="../UI/controlcenter.ui" line="3484"/>
        <source>30 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3332"/>
        <location filename="../UI/controlcenter.ui" line="3489"/>
        <source>60 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3337"/>
        <location filename="../UI/controlcenter.ui" line="3494"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3345"/>
        <location filename="../UI/controlcenter.ui" line="3502"/>
        <source>&amp;Secure Memory Pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3754"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3788"/>
        <source>Statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3793"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4101"/>
        <source>Key &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4115"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4120"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4125"/>
        <source>Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4130"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4138"/>
        <source>Regenerate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4210"/>
        <source>S&amp;tarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4250"/>
        <source>&amp;Magnets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4287"/>
        <source>One-Time-Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4322"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4355"/>
        <source>&amp;Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4520"/>
        <source>&amp;Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4593"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4616"/>
        <source>&amp;Destination Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4709"/>
        <source>Percent Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4714"/>
        <location filename="../UI/controlcenter.ui" line="4808"/>
        <source>Total Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4724"/>
        <location filename="../UI/controlcenter.ui" line="4828"/>
        <source>SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4823"/>
        <source>Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5811"/>
        <source>&amp;Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4379"/>
        <source>Generate Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4384"/>
        <source>Generate MAC Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4454"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4471"/>
        <source>&amp;MAC Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4424"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4441"/>
        <source>&amp;Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4980"/>
        <source> Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4742"/>
        <source>&amp;Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1485"/>
        <source>&amp;Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1572"/>
        <location filename="../UI/controlcenter.ui" line="2423"/>
        <source>SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1602"/>
        <location filename="../UI/controlcenter.ui" line="2448"/>
        <source>External Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1617"/>
        <location filename="../UI/controlcenter.ui" line="2498"/>
        <source>Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1622"/>
        <source>Use Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1660"/>
        <source>Add Listener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1871"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Record the current external IP address in the listener&apos;s certificate. Please do not use this option if you have a dynamic IP address.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1874"/>
        <source>&amp;Ip Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1881"/>
        <source>&amp;Permanent Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1891"/>
        <location filename="../UI/controlcenter.ui" line="2291"/>
        <location filename="../UI/controlcenter.ui" line="2811"/>
        <location filename="../UI/controlcenter.ui" line="3694"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1905"/>
        <location filename="../UI/controlcenter.ui" line="2308"/>
        <location filename="../UI/controlcenter.ui" line="2825"/>
        <location filename="../UI/controlcenter.ui" line="3711"/>
        <location filename="../UI/controlcenter.ui" line="4008"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1915"/>
        <location filename="../UI/controlcenter.ui" line="2318"/>
        <location filename="../UI/controlcenter.ui" line="2835"/>
        <location filename="../UI/controlcenter.ui" line="3721"/>
        <location filename="../UI/controlcenter.ui" line="4018"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1844"/>
        <location filename="../UI/controlcenter.ui" line="2761"/>
        <source>&amp;Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="124"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1858"/>
        <location filename="../UI/controlcenter.ui" line="2775"/>
        <source>Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1863"/>
        <location filename="../UI/controlcenter.ui" line="2780"/>
        <source>Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1985"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2205"/>
        <source>Share my specified public key with the selected neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2256"/>
        <source>Select this option if you would like to accept and connect to published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2266"/>
        <source>Select this option if you would like to accept published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2428"/>
        <source>Status Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2453"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2478"/>
        <source>Proxy Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2483"/>
        <source>Proxy Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2508"/>
        <source>Allow Certificate Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2518"/>
        <source>Bytes Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2523"/>
        <source>Bytes Written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2528"/>
        <source>SSL Session Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2533"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2538"/>
        <source>Account Authenticated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2548"/>
        <source>is_encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2697"/>
        <source>Dynamic DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2700"/>
        <source>&amp;DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2788"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On will record peer certificates during initial connections. Subsequent connections will cause Spot-On to inspect peer certificates. If there are discrepancies between recorded certificates and transmitted certificates, Spot-On will sever the connections. Enable this option if you would like Spot-On to ignore discrepancies.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2798"/>
        <source>Require secure connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2801"/>
        <source>&amp;Require SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3385"/>
        <source>&amp;GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3436"/>
        <source>Display a list of ciphers produced by the provided SSL Control String.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3439"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3646"/>
        <source>randomized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3994"/>
        <source>&amp;Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4036"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4053"/>
        <location filename="../UI/controlcenter.ui" line="4088"/>
        <source>ElGamal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4058"/>
        <location filename="../UI/controlcenter.ui" line="4093"/>
        <source>RSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4066"/>
        <source>&amp;Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4083"/>
        <source>DSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4536"/>
        <source>Novas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4793"/>
        <source>Paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4803"/>
        <source>Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4859"/>
        <source>Rewind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4933"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle each pulse with an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4970"/>
        <source>&amp;Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5787"/>
        <source>&amp;East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5798"/>
        <source>&amp;North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5806"/>
        <source>&amp;West</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="238"/>
        <location filename="../UI/controlcenter.ui" line="2863"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="225"/>
        <source>&amp;Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1512"/>
        <source>Periodically p&amp;ublish plaintext information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2845"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2873"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2896"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2022"/>
        <location filename="../UI/controlcenter.ui" line="2909"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2081"/>
        <source>Allowed IP Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2938"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2943"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2948"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3145"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3185"/>
        <source>Fetch!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3239"/>
        <source>&lt; 1 .. 1 &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3272"/>
        <source>S&amp;ettings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3453"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3582"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3595"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3542"/>
        <source>Spot-On-Kernel &amp;Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3654"/>
        <source>&amp;Congestion Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3664"/>
        <source>Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3729"/>
        <source>If enabled, messages that are deciphered correctly will be forwarded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3974"/>
        <source>Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3991"/>
        <source>If checked, new RSA key pairs will be generated whenever the passphrase is updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3938"/>
        <source>P&amp;assphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5758"/>
        <source>Nuvola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5766"/>
        <source>Nouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5774"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5779"/>
        <source>&amp;Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5771"/>
        <source>&amp;Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1562"/>
        <location filename="../UI/controlcenter.ui" line="3569"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="606"/>
        <location filename="../UI/controlcenter.ui" line="1053"/>
        <location filename="../UI/controlcenter.ui" line="1567"/>
        <location filename="../UI/controlcenter.ui" line="2418"/>
        <location filename="../UI/controlcenter.ui" line="4813"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1587"/>
        <location filename="../UI/controlcenter.ui" line="2468"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1700"/>
        <location filename="../UI/controlcenter.ui" line="2619"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="539"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="544"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="554"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="586"/>
        <location filename="../UI/controlcenter.ui" line="1265"/>
        <location filename="../UI/controlcenter.ui" line="5138"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="596"/>
        <location filename="../UI/controlcenter.ui" line="1275"/>
        <location filename="../UI/controlcenter.ui" line="5148"/>
        <source>neighbor_oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1612"/>
        <source>Max. Conn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1714"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1936"/>
        <location filename="../UI/controlcenter.ui" line="2062"/>
        <location filename="../UI/controlcenter.ui" line="2131"/>
        <location filename="../UI/controlcenter.ui" line="3022"/>
        <location filename="../UI/controlcenter.ui" line="3108"/>
        <location filename="../UI/controlcenter.ui" line="4510"/>
        <location filename="../UI/controlcenter.ui" line="4576"/>
        <location filename="../UI/controlcenter.ui" line="5263"/>
        <location filename="../UI/controlcenter.ui" line="5386"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3047"/>
        <source>Add Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3064"/>
        <source>&amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3074"/>
        <source>&amp;Repleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3262"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3605"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3398"/>
        <location filename="../UI/controlcenter.ui" line="3555"/>
        <location filename="../UI/controlcenter.ui" line="4629"/>
        <location filename="../UI/controlcenter.ui" line="4963"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3858"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1910"/>
        <location filename="../UI/controlcenter.ui" line="2313"/>
        <location filename="../UI/controlcenter.ui" line="2830"/>
        <location filename="../UI/controlcenter.ui" line="3716"/>
        <location filename="../UI/controlcenter.ui" line="4013"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4023"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4028"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3881"/>
        <source>Salt &amp;Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3921"/>
        <location filename="../UI/controlcenter.ui" line="5543"/>
        <source>P&amp;assphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3948"/>
        <source>Minimum of 16 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5188"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5218"/>
        <location filename="../UI/controlcenter.ui" line="5341"/>
        <source>&amp;Accept List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5228"/>
        <location filename="../UI/controlcenter.ui" line="5351"/>
        <source>&amp;Deny List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5311"/>
        <source>&amp;Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="329"/>
        <source>&amp;Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="162"/>
        <source>Demagnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="167"/>
        <source>Magnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="172"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="177"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="205"/>
        <source>&amp;Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="400"/>
        <location filename="../UI/controlcenter.ui" line="1001"/>
        <source>&amp;Accept only signed messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="410"/>
        <source>&amp;Sign messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="439"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="489"/>
        <location filename="../UI/controlcenter.ui" line="5064"/>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="591"/>
        <location filename="../UI/controlcenter.ui" line="1083"/>
        <location filename="../UI/controlcenter.ui" line="1270"/>
        <location filename="../UI/controlcenter.ui" line="1652"/>
        <location filename="../UI/controlcenter.ui" line="2553"/>
        <location filename="../UI/controlcenter.ui" line="4297"/>
        <location filename="../UI/controlcenter.ui" line="4729"/>
        <location filename="../UI/controlcenter.ui" line="4833"/>
        <location filename="../UI/controlcenter.ui" line="4917"/>
        <location filename="../UI/controlcenter.ui" line="5143"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="616"/>
        <source>Gemini AES-256 Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="621"/>
        <source>Gemini SHA-512 Hash Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="634"/>
        <source>&amp;Hide offline participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1174"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle the e-mail with an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1197"/>
        <source>&amp;Save copies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1207"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The kernel is responsible for signing messages. Because messages are queued, please avoid toggling this checkbox until queued message have been processed by the kernel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1303"/>
        <source>&amp;From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1361"/>
        <source>&amp;Enable C/O service.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1368"/>
        <source>&amp;Reject messages without signatures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1425"/>
        <source>Recipient SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1647"/>
        <location filename="../UI/controlcenter.ui" line="2513"/>
        <source>Certificate SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4292"/>
        <location filename="../UI/controlcenter.ui" line="4912"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4374"/>
        <source>Generate Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4643"/>
        <source>&amp;Maximum Mosaic Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4653"/>
        <source> MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4798"/>
        <source>Percent Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4719"/>
        <location filename="../UI/controlcenter.ui" line="4818"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4996"/>
        <source>Transmit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1607"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2176"/>
        <source>Copy my name and the specified public key to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2259"/>
        <source>&amp;Accept published listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2269"/>
        <source>&amp;Accept published listeners (disconnected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2279"/>
        <source>&amp;Ignore published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2353"/>
        <source>&amp;Keep only user-defined neighbors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1627"/>
        <location filename="../UI/controlcenter.ui" line="2488"/>
        <source>Max. Buffer Size (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1632"/>
        <location filename="../UI/controlcenter.ui" line="2493"/>
        <source>Max. Content Length (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2503"/>
        <source>Uptime (Seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2791"/>
        <source>&amp;Allow Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3632"/>
        <location filename="../UI/controlcenter.ui" line="3824"/>
        <source>&amp;Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3680"/>
        <source>&amp;Log Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3687"/>
        <source>&amp;Scrambler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3732"/>
        <source>S&amp;uper Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3807"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3841"/>
        <source>&amp;Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3412"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3422"/>
        <source>HIGH:!aNULL:!eNULL:!3DES:!EXPORT:@STRENGTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4881"/>
        <source>Add Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4936"/>
        <source>Nova</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5018"/>
        <source>&amp;URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5158"/>
        <location filename="../UI/controlcenter.ui" line="5163"/>
        <source>ignored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5172"/>
        <source>URL Distillers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5494"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;quot;The Dalmatian is a breed of dog, noted for its unique black- or brown-spotted coat. This dog is often used as a rescue dog, guardian, athletic partner, and, especially today, the Dalmatian remains most often an active, well-loved family member.&amp;quot; - Wikipedia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5619"/>
        <source>Spot-On Graphical User Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5650"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://sourceforge.net/p/spot-on/code/HEAD/tree/branches/Documentation/RELEASE-NOTES&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Version 0.08&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5666"/>
        <source>Build Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4950"/>
        <location filename="../UI/controlcenter.ui" line="5706"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5714"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5718"/>
        <source>&amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5725"/>
        <source>&amp;Tab Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5737"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5747"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5750"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_rosetta</name>
    <message>
        <location filename="../UI/rosetta.ui" line="14"/>
        <source>Spot-On: Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="36"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="49"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="69"/>
        <source>Copy My &amp;Rosetta Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="78"/>
        <source>New Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="115"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="122"/>
        <location filename="../UI/rosetta.ui" line="262"/>
        <location filename="../UI/rosetta.ui" line="373"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="152"/>
        <source>&amp;Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="162"/>
        <source>&amp;Decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="189"/>
        <source>&amp;Contacts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="206"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="232"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="276"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="293"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="310"/>
        <source>&amp;Sign message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="343"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="411"/>
        <source>Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="430"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="439"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="444"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="452"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="288"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="299"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="307"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="318"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="331"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="347"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="357"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="366"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="378"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="393"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="598"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="700"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="289"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="300"/>
        <source>Empty key. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="308"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="319"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="332"/>
        <source>Invalid key type. Expecting &apos;rosetta&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="348"/>
        <source>Unable to retrieve your %1 public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="358"/>
        <source>Unable to retrieve your %1 signature public key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="367"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="379"/>
        <source>Invalid &apos;rosetta&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="394"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="487"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="510"/>
        <source>Invalid item data. This is a serious flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="516"/>
        <source>Please provide an actual message!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="525"/>
        <source>The method spoton_crypt::cipherKeyLength() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="585"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="693"/>
        <source>A serious cryptographic error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="619"/>
        <source>Empty input data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="650"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="684"/>
        <source>The message was not signed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="688"/>
        <source>Invalid signature. Perhaps your contacts are not current.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="717"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="720"/>
        <source>Are you sure that you wish to remove the selected contact?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statusbar</name>
    <message>
        <location filename="../UI/statusbar.ui" line="89"/>
        <source>Buzz activity!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="102"/>
        <source>You have received a new message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="118"/>
        <source>New e-mail has arrived!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="147"/>
        <source>Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
