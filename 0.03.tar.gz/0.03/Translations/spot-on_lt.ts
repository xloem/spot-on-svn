<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="lt_LT">
<context>
    <name>QObject</name>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="165"/>
        <source>gcry_cipher_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="174"/>
        <source>gcry_md_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="183"/>
        <location filename="../Common/spot-on-crypt.cc" line="467"/>
        <location filename="../Common/spot-on-crypt.cc" line="628"/>
        <source>gcry_cipher_get_algo_keylen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="194"/>
        <source>gcry_calloc_secure() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="218"/>
        <source>gcry_kdf_derive() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="256"/>
        <source>gcry_md_get_algo_dlen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="339"/>
        <source>oldPassphrase is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="423"/>
        <source>gcry_cipher_open() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="431"/>
        <source>gcry_cipher_open() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="442"/>
        <location filename="../Common/spot-on-crypt.cc" line="587"/>
        <location filename="../Common/spot-on-crypt.cc" line="597"/>
        <source>gcry_cipher_get_algo_blklen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="456"/>
        <location filename="../Common/spot-on-crypt.cc" line="620"/>
        <source>gcry_cipher_setiv() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="479"/>
        <location filename="../Common/spot-on-crypt.cc" line="641"/>
        <source>gcry_cipher_setkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="379"/>
        <source>error retrieving data from the idiotes table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="244"/>
        <source>gcry_md_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="407"/>
        <source>gcry_cipher_map_name() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="509"/>
        <source>The length of the decrypted data is irregular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="520"/>
        <source>gcry_cipher_decrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="541"/>
        <source>gcry_sexp_new() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="549"/>
        <source>gcry_sexp_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="560"/>
        <source>gcry_pk_testkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="577"/>
        <source>gcry_cipher_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="607"/>
        <source>gcry_calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="666"/>
        <source>gcry_cipher_encrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1892"/>
        <source>gcry_sexp_build() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1911"/>
        <source>gcry_pk_genkey() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1934"/>
        <source>gcry_sexp_find_token() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1945"/>
        <location filename="../Common/spot-on-crypt.cc" line="1960"/>
        <source>gcry_sexp_sprint() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="1978"/>
        <source>malloc() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2016"/>
        <source>QSqlQuery::exec() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2025"/>
        <source>encrypted() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2539"/>
        <source>BN_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2547"/>
        <source>BN_set_word() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2555"/>
        <source>RSA_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2563"/>
        <source>RSA_generate_key_ex() returned negative one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2571"/>
        <location filename="../Common/spot-on-crypt.cc" line="2579"/>
        <location filename="../Common/spot-on-crypt.cc" line="2776"/>
        <source>BIO_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2587"/>
        <source>PEM_write_bio_RSAPrivateKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2595"/>
        <source>PEM_write_bio_RSAPublicKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2605"/>
        <location filename="../Common/spot-on-crypt.cc" line="2618"/>
        <location filename="../Common/spot-on-crypt.cc" line="2794"/>
        <source>calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2679"/>
        <source>rsa container is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2687"/>
        <source>EVP_PKEY_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2696"/>
        <source>X509_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2705"/>
        <source>EVP_PKEY_assign_RSA() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2717"/>
        <source>X509_set_version() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2725"/>
        <location filename="../Common/spot-on-crypt.cc" line="2738"/>
        <source>X509_gmtime_adj() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2748"/>
        <source>X509_set_issuer_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2756"/>
        <source>X509_set_pubkey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2764"/>
        <source>X509_sign() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2784"/>
        <source>PEM_write_bio_X509() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="59"/>
        <source>Re-encoding email.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="219"/>
        <source>Re-encoding country_inclusion.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="305"/>
        <source>Re-encoding listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="428"/>
        <source>Re-encoding neighbors.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1108"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>buzzPage</name>
    <message>
        <location filename="../UI/buzzpage.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="22"/>
        <source>Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="36"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="62"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="83"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="103"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="125"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="130"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="135"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="173"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="193"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="198"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="242"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton</name>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2374"/>
        <source>Spot-On: Select Kernel Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2351"/>
        <location filename="../GUI/spot-on-a.cc" line="2377"/>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2684"/>
        <location filename="../GUI/spot-on-a.cc" line="2693"/>
        <location filename="../GUI/spot-on-a.cc" line="2859"/>
        <location filename="../GUI/spot-on-a.cc" line="2866"/>
        <location filename="../GUI/spot-on-a.cc" line="2877"/>
        <location filename="../GUI/spot-on-b.cc" line="1347"/>
        <location filename="../GUI/spot-on-b.cc" line="1373"/>
        <location filename="../GUI/spot-on-b.cc" line="1388"/>
        <location filename="../GUI/spot-on-b.cc" line="1403"/>
        <location filename="../GUI/spot-on-b.cc" line="1462"/>
        <location filename="../GUI/spot-on-b.cc" line="1548"/>
        <location filename="../GUI/spot-on-b.cc" line="1558"/>
        <location filename="../GUI/spot-on-b.cc" line="1569"/>
        <location filename="../GUI/spot-on-b.cc" line="1884"/>
        <location filename="../GUI/spot-on-b.cc" line="1892"/>
        <location filename="../GUI/spot-on-b.cc" line="2398"/>
        <location filename="../GUI/spot-on-b.cc" line="2405"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="556"/>
        <location filename="../GUI/spot-on-a.cc" line="3325"/>
        <source>Not connected to the kernel. Is the kernel active?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1621"/>
        <location filename="../GUI/spot-on-a.cc" line="1623"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1932"/>
        <source>The sticky feature enables an indefinite lifetime for a neighbor.
If not checked, the neighbor will be terminated after some internal timer expires.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2685"/>
        <source>The passphrases must contain at least sixteen characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2694"/>
        <source>The passphrases are not equal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2710"/>
        <location filename="../GUI/spot-on-b.cc" line="347"/>
        <location filename="../GUI/spot-on-b.cc" line="1642"/>
        <location filename="../GUI/spot-on-b.cc" line="2708"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3280"/>
        <source>&amp;Remove participant(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3304"/>
        <source>Connected insecurely to the kernel on port %1 from local port %2. Communications between the interface and the kernel have been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3856"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3858"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3765"/>
        <location filename="../GUI/spot-on-a.cc" line="3860"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="105"/>
        <location filename="../GUI/spot-on-a.cc" line="108"/>
        <location filename="../GUI/spot-on-a.cc" line="111"/>
        <location filename="../GUI/spot-on-a.cc" line="114"/>
        <source>Spot-On was configured without libGeoIP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="120"/>
        <location filename="../GUI/spot-on-a.cc" line="123"/>
        <source>Spot-On was configured without libphoton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="558"/>
        <location filename="../GUI/spot-on-a.cc" line="1743"/>
        <source>Listeners are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="559"/>
        <location filename="../GUI/spot-on-a.cc" line="2175"/>
        <source>Neighbors are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="563"/>
        <source>Copy &amp;Messaging Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="565"/>
        <source>Copy &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="569"/>
        <location filename="../GUI/spot-on-a.cc" line="3193"/>
        <source>Share &amp;Messaging Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="571"/>
        <location filename="../GUI/spot-on-a.cc" line="3198"/>
        <source>Share &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="575"/>
        <source>&amp;Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="577"/>
        <source>&amp;On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="964"/>
        <source>Preparing databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1531"/>
        <source>Status: %1
SSL Key Size: %2
Local IP: %3 Local Port: %4 Scope ID: %5
External IP: %6
Connections: %7
Echo Mode: %8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1736"/>
        <source>There is (are) %1 active listener(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2164"/>
        <source>There is (are) %1 connected neighbor(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2348"/>
        <source>Spot-On: Select GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2733"/>
        <source>Generating a derived key. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2765"/>
        <source>Re-encoding public key pair 1 of 3. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2780"/>
        <source>Re-encoding public key pair 2 of 3. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2797"/>
        <source>Re-encoding public key pair 3 of 3. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2819"/>
        <source>Generating public key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2825"/>
        <source>Generating public key pair %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2860"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKey().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2867"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys() or spoton_crypt::reencodeRSAKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2878"/>
        <source>An error (%1) occurred with spoton_crypt::saltedPassphraseHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2979"/>
        <source>Your passphrase and public key pairs have been recorded. You are now ready to use the full power of Spot-On. Enjoy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3172"/>
        <source>Detach &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3174"/>
        <source>Disconnect &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3177"/>
        <source>&amp;Publish Information (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3179"/>
        <source>Publish &amp;All (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3213"/>
        <source>Delete All Non-Unique &amp;Blocked Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3215"/>
        <source>Delete All Non-Unique &amp;UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3218"/>
        <source>B&amp;lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3220"/>
        <source>U&amp;nblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3182"/>
        <location filename="../GUI/spot-on-a.cc" line="3223"/>
        <source>&amp;Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3184"/>
        <location filename="../GUI/spot-on-a.cc" line="3225"/>
        <source>&amp;Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3249"/>
        <source>&amp;Call participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3246"/>
        <source>&amp;Copy Repleo to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1858"/>
        <source>UUID: %1
Status: %2
SSL Key Size: %3
Local IP: %4 Local Port: %5
External IP: %6
Country: %7 Remote IP: %8 Remote Port: %9 Scope ID: %10
Proxy Hostname: %11 Proxy Port: %12
Echo Mode: %13
Communications Mode: %14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3258"/>
        <source>&amp;Terminate call.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3268"/>
        <source>&amp;Generate random Gemini (AES-256).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3297"/>
        <source>Connected securely to the kernel on port %1 from local port %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3862"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3864"/>
        <source>Friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3901"/>
        <source>Your friend %1 is away.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3911"/>
        <source>Your friend %1 is busy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3922"/>
        <source>Your friend %1 is offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3932"/>
        <source>User %1 is online.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3936"/>
        <source>User %1 is a permanent friend.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3948"/>
        <source>User %1 requests your friendship.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3201"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="955"/>
        <location filename="../GUI/spot-on-a.cc" line="959"/>
        <source>Broadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2713"/>
        <source>Are you sure that you wish to replace the existing passphrase? Please note that URL data must be re-encoded via a separate tool. Please see the Tools folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2927"/>
        <source>Initializing country_inclusion.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2978"/>
        <source>Spot-On: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2992"/>
        <source>Spot-On: Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2995"/>
        <source>Would you like the kernel to be activated?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3203"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3167"/>
        <location filename="../GUI/spot-on-a.cc" line="3209"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3169"/>
        <location filename="../GUI/spot-on-a.cc" line="3211"/>
        <source>Delete &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3234"/>
        <source>&amp;Add participant as friend.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="59"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="350"/>
        <source>Are you sure that you wish to remove the selected participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="547"/>
        <location filename="../GUI/spot-on-b.cc" line="552"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1348"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1374"/>
        <location filename="../GUI/spot-on-b.cc" line="1549"/>
        <source>Invalid key type. Expecting &apos;messaging&apos; or &apos;url&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1404"/>
        <location filename="../GUI/spot-on-b.cc" line="1570"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1463"/>
        <source>Invalid repleo. The repleo must start with either the letter R or the letter r.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1559"/>
        <source>Invalid public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1885"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1893"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1988"/>
        <source>Queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2167"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2170"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2172"/>
        <source>From/To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2388"/>
        <source>Spot-On: Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2388"/>
        <source>&amp;Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1389"/>
        <source>Invalid messaging or url public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2399"/>
        <source>The provided goldbug may be incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2406"/>
        <source>A severe memory issue occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2450"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2453"/>
        <source>&lt;b&gt;To:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2455"/>
        <location filename="../GUI/spot-on-b.cc" line="2483"/>
        <location filename="../GUI/spot-on-b.cc" line="2499"/>
        <source>&lt;b&gt;Subject:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2458"/>
        <location filename="../GUI/spot-on-b.cc" line="2486"/>
        <location filename="../GUI/spot-on-b.cc" line="2502"/>
        <source>&lt;b&gt;Sent: &lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2465"/>
        <location filename="../GUI/spot-on-b.cc" line="2471"/>
        <location filename="../GUI/spot-on-b.cc" line="2473"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2478"/>
        <source>&lt;b&gt;From:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2480"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2493"/>
        <location filename="../GUI/spot-on-b.cc" line="2496"/>
        <source>&lt;b&gt;From/To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2507"/>
        <location filename="../GUI/spot-on-b.cc" line="2513"/>
        <location filename="../GUI/spot-on-b.cc" line="2515"/>
        <location filename="../GUI/spot-on-b.cc" line="2567"/>
        <source>Deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2711"/>
        <source>Are you sure that you wish to empty the Trash folder?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3260"/>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3521"/>
        <source>Generating SSL data for kernel socket. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1645"/>
        <source>Are you sure that you wish to reset Spot-On? All data will be lost.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzpage</name>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="182"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="373"/>
        <source>&lt;i&gt;%1 has joined %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="396"/>
        <source>&lt;i&gt;%1 is now known as %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="449"/>
        <source>&lt;i&gt;%1 has left %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_docviewer</name>
    <message>
        <location filename="../UI/docviewer.ui" line="14"/>
        <source>Spot-On: Documentation Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/docviewer.ui" line="25"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Lucida Grande&apos;; font-size:13pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:12pt; font-weight:600;&quot;&gt;Buzz&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:12pt;&quot;&gt;Buzz provides a simple interface for public communications. Spot-On uses the channel name to derive an encryption key. The channel type describes the cipher algorithm that&apos;s to be used. An optional salt may be specified. Please note that the provided salt must be known by other parties in order for the derived key to be common.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Sans&apos;; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Sans&apos;; font-size:12pt;&quot;&gt;User names are not necessarily unique, however, each client on a particular channel attempts a unique ID. The ID exists for the duration of a UI session.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Chat&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;The Chat page allows known participants to communicate via a hybrid system. Here, one may accept a participant that has shared a public key. To accept a participant, highlight the intended participant and activate a context menu via the left or right mouse button. Once a participant is accepted, your name, public key, and signature key shall be transferred to the participant. Accepting and sharing public keys require direct connections. If a connection is severed before a participant has been accepted, the participant will be removed.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;AES-256 keys may be set via the Gemini input field. Geminis provide another layer of encryption. Interested parties must agree on common geminis. Randomly-generated geminis may be transferred automatically via the calling feature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;All data transferred over Spot-On sockets are encoded to appear as hypertext. Future revisions may expand or replace this format.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Please note that all data within this page must be properly signed if signatures are required.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;E-Mail&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;The E-Mail panel is a simple interface for Echo e-mail. Participants must be known in order for e-mail to be useful.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Similar to the Gemini, the Gold Bug provides another layer of AES-256 encryption. If specified, portions of an outbound letter shall be encrypted via the provided key. Recipients will be prompted to provide correct gold bugs whenever they attempt to open letters that have been enclosed by gold bugs.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;The C/O sub-panel allows participants to house off-line e-mail of other participants. The intent of this feature is to provide a means of storing data for later retrieval. Please note that two participants must have a common participant in order for the feature to function correctly. Whenever a participant requests e-mail, a broadcast message is sent to reachable nodes. The broadcast includes the participant&apos;s signature. E-mail will then be distributed in a timely manner.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Please note that you may receive duplicate messages because of the Echo Protocol. A future revision may resolve this mishap.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Please note that all data within this page must be properly signed if signatures are required.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Listeners&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;In order to accept incoming connections, at least one active listener is required. The maximum number of connections that Spot-On will accept on a listener may also be modified. Echo modes and SSL key sizes may be selected as well. A context menu may be activated via the left or right mouse buttons on the Listeners table. The menu provides several other options that are not readily available.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Data that is transmitted on the Echo Protocol is subject to echoes. To restrict echoed data on a listener, simply select the Echo Mode. Please note that in order for a connection to be either full or half echo, both endpoints must agree on an identical mode.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Restricting connections by country is provided on this page. A future version of Spot-On will provide more elaborate mechanisms for limiting remote connections.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Neighbors&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;The Neighbors page lists all Spot-On network connections that are present on a node. This page also allows users to define new connections. A context menu may be activated via the left or right mouse buttons on the Neighbors table. The menu provides several other options that are not readily available.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;The Neighbors page also allows owners to copy their public keys to clipboard buffers. Adding other participants may also be performed on this page.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Search&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Not yet implemented.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Settings&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Please prepare a passphrase after launching Spot-On. To do so, complete the Passphrase and Passphrase Confirmation fields. Also review, and perhaps modify, the cipher type, hash type, iteration count, RSA key size, and salt length. Please note that the initialization process may take a significant amount of time to complete.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Please also select the location of the GeoIP.dat file.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Spot-On is separated into two major processes, a kernel and a user interface. The kernel is responsible for establishing and maintaining the network aspects of Spot-On. The data between a kernel process and one or more user interfaces are transferred over SSL.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;URLs&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt;&quot;&gt;Not yet implemented.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:12pt;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/docviewer.ui" line="103"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/docviewer.ui" line="112"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/docviewer.ui" line="117"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_logviewer</name>
    <message>
        <location filename="../UI/logviewer.ui" line="14"/>
        <source>Spot-On: Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="53"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="72"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="78"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="89"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="94"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="102"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_mainwindow</name>
    <message>
        <location filename="../UI/controlcenter.ui" line="241"/>
        <location filename="../UI/controlcenter.ui" line="559"/>
        <location filename="../UI/controlcenter.ui" line="2287"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="68"/>
        <location filename="../UI/controlcenter.ui" line="285"/>
        <location filename="../UI/controlcenter.ui" line="2983"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="367"/>
        <location filename="../UI/controlcenter.ui" line="932"/>
        <location filename="../UI/controlcenter.ui" line="3029"/>
        <source>public_key_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="508"/>
        <location filename="../UI/controlcenter.ui" line="877"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="727"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2379"/>
        <location filename="../UI/controlcenter.ui" line="3125"/>
        <location filename="../UI/controlcenter.ui" line="3233"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="601"/>
        <source>Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="786"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="799"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1513"/>
        <source>&amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1165"/>
        <location filename="../UI/controlcenter.ui" line="1741"/>
        <source>Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1170"/>
        <location filename="../UI/controlcenter.ui" line="1746"/>
        <source>Local Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1180"/>
        <location filename="../UI/controlcenter.ui" line="1781"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2882"/>
        <source>Set Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2923"/>
        <source>Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3385"/>
        <source>Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1766"/>
        <source>Remote IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1771"/>
        <source>Remote Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1828"/>
        <source>Add Neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1716"/>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1236"/>
        <location filename="../UI/controlcenter.ui" line="1916"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1283"/>
        <location filename="../UI/controlcenter.ui" line="1906"/>
        <location filename="../UI/controlcenter.ui" line="2079"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1309"/>
        <location filename="../UI/controlcenter.ui" line="1887"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1325"/>
        <location filename="../UI/controlcenter.ui" line="1932"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="464"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="459"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1721"/>
        <source>UUID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1185"/>
        <location filename="../UI/controlcenter.ui" line="1751"/>
        <source>External IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="44"/>
        <source>&amp;Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="52"/>
        <location filename="../UI/controlcenter.ui" line="269"/>
        <location filename="../UI/controlcenter.ui" line="2970"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="65"/>
        <location filename="../UI/controlcenter.ui" line="282"/>
        <source>Save my name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="75"/>
        <source>&amp;Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="88"/>
        <source>&amp;Salt (Optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="118"/>
        <source>Join</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="315"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="377"/>
        <source>Gemini</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="439"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="529"/>
        <source>&amp;E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="556"/>
        <source>Clear contents of current view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="572"/>
        <source>Empty Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="585"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="598"/>
        <source>Request e-mail from other participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="627"/>
        <source>&amp;Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="639"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="644"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="649"/>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="680"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="712"/>
        <location filename="../UI/controlcenter.ui" line="1018"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="717"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="732"/>
        <source>goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="737"/>
        <source>message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="742"/>
        <source>message_digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="747"/>
        <source>receiver_sender_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="770"/>
        <source>&amp;Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="776"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="819"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="834"/>
        <source>Bundle the e-mail with an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="837"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="867"/>
        <source>Sign &amp;messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="956"/>
        <source>&amp;C/O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1023"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1028"/>
        <source>Recipient Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1038"/>
        <source>Data that has not been processed in more than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1055"/>
        <source>&amp;day(s) will be purged automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1085"/>
        <source>&amp;Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1160"/>
        <location filename="../UI/controlcenter.ui" line="1731"/>
        <source>SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1190"/>
        <location filename="../UI/controlcenter.ui" line="1756"/>
        <source>External Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1205"/>
        <location filename="../UI/controlcenter.ui" line="1806"/>
        <source>Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1218"/>
        <source>Add Listener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1224"/>
        <source>The uniqueness of a listener is defined by the local IP, the local port, and the scope ID.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1334"/>
        <location filename="../UI/controlcenter.ui" line="1614"/>
        <location filename="../UI/controlcenter.ui" line="1951"/>
        <location filename="../UI/controlcenter.ui" line="2655"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1345"/>
        <location filename="../UI/controlcenter.ui" line="1631"/>
        <location filename="../UI/controlcenter.ui" line="1965"/>
        <location filename="../UI/controlcenter.ui" line="2669"/>
        <location filename="../UI/controlcenter.ui" line="2790"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1355"/>
        <location filename="../UI/controlcenter.ui" line="1641"/>
        <location filename="../UI/controlcenter.ui" line="1975"/>
        <location filename="../UI/controlcenter.ui" line="2679"/>
        <location filename="../UI/controlcenter.ui" line="2800"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1380"/>
        <location filename="../UI/controlcenter.ui" line="2000"/>
        <source>&amp;Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1394"/>
        <location filename="../UI/controlcenter.ui" line="2014"/>
        <source>Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1399"/>
        <location filename="../UI/controlcenter.ui" line="2019"/>
        <source>Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1452"/>
        <source>Accepted Countries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1473"/>
        <source>Toggle All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1521"/>
        <source>Copy my name and specified public key to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1524"/>
        <source>Copy Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1537"/>
        <source>Share my specified public key with the selected neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1540"/>
        <source>Share Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1579"/>
        <source>Select this option if you would like to accept and connect to published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1589"/>
        <source>Select this option if you would like to accept published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1736"/>
        <source>Status Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1761"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1786"/>
        <source>Proxy Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1791"/>
        <source>Proxy Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1796"/>
        <source>Max. Buffer Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1801"/>
        <source>Max. Content Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1811"/>
        <source>is_encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1837"/>
        <source>The uniqueness of a neighbor is defined by the proxy hostname, the proxy port, the remote IP, the remote port, and the scope ID.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1939"/>
        <source>Dynamic DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1942"/>
        <source>&amp;DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="101"/>
        <location filename="../UI/controlcenter.ui" line="2056"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1100"/>
        <source>Periodically p&amp;ublish plaintext information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2044"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2066"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2089"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2102"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2128"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2133"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2138"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2317"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2348"/>
        <source>Fetch!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2399"/>
        <source>&lt; 1 .. 1 &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2432"/>
        <source>S&amp;ettings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2495"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2516"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2529"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2553"/>
        <source>Spot-On-Kernel &amp;Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2587"/>
        <source>Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2610"/>
        <source>Enable &amp;Scrambler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2624"/>
        <source>If enabled, messages that are deciphered correctly will be forwarded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2627"/>
        <source>Enable S&amp;uper Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2776"/>
        <source>If checked, new RSA key pairs will be generated whenever the passphrase is updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2855"/>
        <source>P&amp;assphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3472"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://sourceforge.net/p/spot-on/code/HEAD/tree/branches/0.03/Documentation/RELEASE-NOTES&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Version 0.03&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3562"/>
        <source>&amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3570"/>
        <source>Nuvola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3578"/>
        <source>Nouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3586"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3591"/>
        <source>&amp;Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3583"/>
        <source>&amp;Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1150"/>
        <location filename="../UI/controlcenter.ui" line="2503"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="372"/>
        <location filename="../UI/controlcenter.ui" line="722"/>
        <location filename="../UI/controlcenter.ui" line="1155"/>
        <location filename="../UI/controlcenter.ui" line="1726"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1175"/>
        <location filename="../UI/controlcenter.ui" line="1776"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1249"/>
        <location filename="../UI/controlcenter.ui" line="1861"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="305"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="310"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="320"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="352"/>
        <location filename="../UI/controlcenter.ui" line="922"/>
        <location filename="../UI/controlcenter.ui" line="3014"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="362"/>
        <location filename="../UI/controlcenter.ui" line="3024"/>
        <source>neighbor_oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1200"/>
        <source>Max. Conn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1263"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1439"/>
        <location filename="../UI/controlcenter.ui" line="2206"/>
        <location filename="../UI/controlcenter.ui" line="2280"/>
        <location filename="../UI/controlcenter.ui" line="3118"/>
        <location filename="../UI/controlcenter.ui" line="3226"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2231"/>
        <source>Add Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2239"/>
        <source>&amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2249"/>
        <source>&amp;Repleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2422"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2539"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2471"/>
        <location filename="../UI/controlcenter.ui" line="2566"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2705"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2753"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1350"/>
        <location filename="../UI/controlcenter.ui" line="1636"/>
        <location filename="../UI/controlcenter.ui" line="1970"/>
        <location filename="../UI/controlcenter.ui" line="2674"/>
        <location filename="../UI/controlcenter.ui" line="2795"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2805"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2810"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2818"/>
        <source>Salt &amp;Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2872"/>
        <location filename="../UI/controlcenter.ui" line="3368"/>
        <source>P&amp;assphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2865"/>
        <source>Minimum of 16 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3058"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3079"/>
        <location filename="../UI/controlcenter.ui" line="3187"/>
        <source>&amp;Accept List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3089"/>
        <location filename="../UI/controlcenter.ui" line="3197"/>
        <source>&amp;Deny List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3166"/>
        <source>&amp;Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="138"/>
        <source>&amp;Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="181"/>
        <location filename="../UI/controlcenter.ui" line="670"/>
        <source>&amp;Accept only signed messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="191"/>
        <source>&amp;Sign messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="220"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="261"/>
        <location filename="../UI/controlcenter.ui" line="2962"/>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="357"/>
        <location filename="../UI/controlcenter.ui" line="752"/>
        <location filename="../UI/controlcenter.ui" line="927"/>
        <location filename="../UI/controlcenter.ui" line="1210"/>
        <location filename="../UI/controlcenter.ui" line="1816"/>
        <location filename="../UI/controlcenter.ui" line="3019"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="387"/>
        <source>&amp;Hide offline participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="857"/>
        <source>&amp;Save copies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="964"/>
        <source>&amp;Enable C/O service.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="971"/>
        <source>&amp;Reject messages without signatures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1195"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1582"/>
        <source>&amp;Accept published listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1592"/>
        <source>&amp;Accept published listeners (disconnected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1602"/>
        <source>&amp;Ignore published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1666"/>
        <source>&amp;Keep only user-defined neighbors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2461"/>
        <source>GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2577"/>
        <source>&amp;Enable congestion control.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2641"/>
        <source>&amp;Log events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2719"/>
        <source>&amp;Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2736"/>
        <source>&amp;Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2779"/>
        <source>&amp;RSA Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2952"/>
        <source>&amp;URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3034"/>
        <location filename="../UI/controlcenter.ui" line="3039"/>
        <source>ignored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3048"/>
        <source>URL Distillers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3322"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;quot;The Dalmatian is a breed of dog, noted for its unique black- or brown-spotted coat. This dog is often used as a rescue dog, guardian, athletic partner, and, especially today, the Dalmatian remains most often an active, well-loved family member.&amp;quot; - Wikipedia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3441"/>
        <source>Spot-On Graphical User Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3488"/>
        <source>Build Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3528"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3536"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3540"/>
        <source>&amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3554"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3557"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statusbar</name>
    <message>
        <location filename="../UI/statusbar.ui" line="70"/>
        <source>Buzz activity!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="86"/>
        <source>You have received a new message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="105"/>
        <source>New e-mail has arrived!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="140"/>
        <source>Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
