<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fi_FI">
<context>
    <name>QObject</name>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="181"/>
        <source>gcry_cipher_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="190"/>
        <source>gcry_md_test_algo() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="199"/>
        <location filename="../Common/spot-on-crypt.cc" line="619"/>
        <location filename="../Common/spot-on-crypt.cc" line="795"/>
        <source>gcry_cipher_get_algo_keylen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="249"/>
        <source>gcry_kdf_derive() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="399"/>
        <source>gcry_md_get_algo_dlen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="568"/>
        <source>gcry_cipher_open() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="580"/>
        <source>gcry_cipher_open() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="591"/>
        <location filename="../Common/spot-on-crypt.cc" line="754"/>
        <location filename="../Common/spot-on-crypt.cc" line="764"/>
        <source>gcry_cipher_get_algo_blklen() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="604"/>
        <location filename="../Common/spot-on-crypt.cc" line="787"/>
        <source>gcry_cipher_setiv() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="631"/>
        <location filename="../Common/spot-on-crypt.cc" line="807"/>
        <source>gcry_cipher_setkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="369"/>
        <source>empty passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="361"/>
        <source>empty hashType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="377"/>
        <source>empty salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="387"/>
        <source>gcry_md_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="478"/>
        <source>oldKey is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="552"/>
        <source>gcry_cipher_map_name() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="665"/>
        <source>The length of the decrypted data is irregular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="676"/>
        <source>gcry_cipher_decrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="700"/>
        <source>gcry_sexp_new() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="712"/>
        <source>gcry_sexp_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="723"/>
        <source>gcry_pk_testkey() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="744"/>
        <source>gcry_cipher_map_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="774"/>
        <source>gcry_calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="832"/>
        <source>QDataStream failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="849"/>
        <source>gcry_cipher_encrypt() returned non-zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="895"/>
        <source>a database error occurred</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2083"/>
        <source>gcry_sexp_build() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2107"/>
        <source>gcry_pk_genkey() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2135"/>
        <source>gcry_sexp_find_token() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2146"/>
        <location filename="../Common/spot-on-crypt.cc" line="2161"/>
        <source>gcry_sexp_sprint() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2179"/>
        <source>malloc() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2217"/>
        <source>QSqlQuery::exec() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2226"/>
        <source>encrypted() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2972"/>
        <source>BN_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2980"/>
        <source>BN_set_word() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2988"/>
        <source>RSA_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="2996"/>
        <source>RSA_generate_key_ex() returned negative one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3004"/>
        <location filename="../Common/spot-on-crypt.cc" line="3012"/>
        <location filename="../Common/spot-on-crypt.cc" line="3264"/>
        <source>BIO_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3020"/>
        <source>PEM_write_bio_RSAPrivateKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3028"/>
        <source>PEM_write_bio_RSAPublicKey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3039"/>
        <location filename="../Common/spot-on-crypt.cc" line="3053"/>
        <location filename="../Common/spot-on-crypt.cc" line="3183"/>
        <location filename="../Common/spot-on-crypt.cc" line="3283"/>
        <source>calloc() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3117"/>
        <source>rsa container is zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3125"/>
        <source>EVP_PKEY_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3134"/>
        <source>X509_new() failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3143"/>
        <source>EVP_PKEY_assign_RSA() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3155"/>
        <source>X509_set_version() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3163"/>
        <location filename="../Common/spot-on-crypt.cc" line="3171"/>
        <source>X509_gmtime_adj() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3200"/>
        <source>X509_NAME_ENTRY_create_by_NID() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3210"/>
        <source>X509_NAME_new() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3218"/>
        <source>X509_NAME_add_entry() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3226"/>
        <source>X509_set_subject_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3236"/>
        <source>X509_set_issuer_name() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3244"/>
        <source>X509_set_pubkey() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3252"/>
        <source>X509_sign() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-crypt.cc" line="3272"/>
        <source>PEM_write_bio_X509() returned zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="124"/>
        <source>Re-encoding email.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="58"/>
        <source>Re-encoding buzz_channels.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="283"/>
        <source>Re-encoding friends_public_keys.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="357"/>
        <source>Re-encoding listeners.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-reencode.cc" line="649"/>
        <location filename="../GUI/spot-on-reencode.cc" line="960"/>
        <source>Re-encoding neighbors.db.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Common/spot-on-misc.cc" line="1020"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>buzzPage</name>
    <message>
        <location filename="../UI/buzzpage.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="61"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="75"/>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="47"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="32"/>
        <source>Please be considerate of others and announce your departure. Departure notifications are not immediate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="68"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="88"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="118"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="141"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="166"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="171"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="176"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="220"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="240"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="245"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/buzzpage.ui" line="292"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chatwindow</name>
    <message>
        <location filename="../UI/chatwindow.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="36"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="43"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="63"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/chatwindow.ui" line="106"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>passwordprompt</name>
    <message>
        <location filename="../UI/passwordprompt.ui" line="14"/>
        <source>Spot-On: Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="30"/>
        <source>Please provide the following credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="42"/>
        <source>Account &amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/passwordprompt.ui" line="55"/>
        <source>Account &amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton</name>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3592"/>
        <source>Spot-On: Select Kernel Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3575"/>
        <location filename="../GUI/spot-on-a.cc" line="3595"/>
        <location filename="../GUI/spot-on-c.cc" line="424"/>
        <location filename="../GUI/spot-on-c.cc" line="780"/>
        <location filename="../GUI/spot-on-c.cc" line="2825"/>
        <location filename="../GUI/spot-on-c.cc" line="3017"/>
        <source>&amp;Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1526"/>
        <location filename="../GUI/spot-on-a.cc" line="1837"/>
        <location filename="../GUI/spot-on-a.cc" line="1842"/>
        <location filename="../GUI/spot-on-a.cc" line="1855"/>
        <location filename="../GUI/spot-on-a.cc" line="2219"/>
        <location filename="../GUI/spot-on-a.cc" line="2224"/>
        <location filename="../GUI/spot-on-a.cc" line="3977"/>
        <location filename="../GUI/spot-on-a.cc" line="3986"/>
        <location filename="../GUI/spot-on-a.cc" line="3994"/>
        <location filename="../GUI/spot-on-a.cc" line="4200"/>
        <location filename="../GUI/spot-on-a.cc" line="4207"/>
        <location filename="../GUI/spot-on-a.cc" line="4218"/>
        <location filename="../GUI/spot-on-a.cc" line="6536"/>
        <location filename="../GUI/spot-on-a.cc" line="6549"/>
        <location filename="../GUI/spot-on-a.cc" line="6622"/>
        <location filename="../GUI/spot-on-a.cc" line="6888"/>
        <location filename="../GUI/spot-on-a.cc" line="6936"/>
        <location filename="../GUI/spot-on-b.cc" line="139"/>
        <location filename="../GUI/spot-on-b.cc" line="1372"/>
        <location filename="../GUI/spot-on-b.cc" line="1379"/>
        <location filename="../GUI/spot-on-b.cc" line="1387"/>
        <location filename="../GUI/spot-on-b.cc" line="1398"/>
        <location filename="../GUI/spot-on-b.cc" line="1412"/>
        <location filename="../GUI/spot-on-b.cc" line="1475"/>
        <location filename="../GUI/spot-on-b.cc" line="1577"/>
        <location filename="../GUI/spot-on-b.cc" line="1584"/>
        <location filename="../GUI/spot-on-b.cc" line="1592"/>
        <location filename="../GUI/spot-on-b.cc" line="1603"/>
        <location filename="../GUI/spot-on-b.cc" line="1638"/>
        <location filename="../GUI/spot-on-b.cc" line="1653"/>
        <location filename="../GUI/spot-on-b.cc" line="1676"/>
        <location filename="../GUI/spot-on-b.cc" line="1684"/>
        <location filename="../GUI/spot-on-b.cc" line="1695"/>
        <location filename="../GUI/spot-on-b.cc" line="1705"/>
        <location filename="../GUI/spot-on-b.cc" line="1720"/>
        <location filename="../GUI/spot-on-b.cc" line="1773"/>
        <location filename="../GUI/spot-on-b.cc" line="1786"/>
        <location filename="../GUI/spot-on-b.cc" line="1797"/>
        <location filename="../GUI/spot-on-b.cc" line="2127"/>
        <location filename="../GUI/spot-on-b.cc" line="2135"/>
        <location filename="../GUI/spot-on-b.cc" line="2902"/>
        <location filename="../GUI/spot-on-b.cc" line="2908"/>
        <location filename="../GUI/spot-on-b.cc" line="2915"/>
        <location filename="../GUI/spot-on-b.cc" line="3334"/>
        <location filename="../GUI/spot-on-b.cc" line="4181"/>
        <location filename="../GUI/spot-on-b.cc" line="4338"/>
        <location filename="../GUI/spot-on-b.cc" line="4359"/>
        <location filename="../GUI/spot-on-b.cc" line="4369"/>
        <location filename="../GUI/spot-on-b.cc" line="4433"/>
        <location filename="../GUI/spot-on-b.cc" line="4443"/>
        <location filename="../GUI/spot-on-b.cc" line="4463"/>
        <location filename="../GUI/spot-on-b.cc" line="4481"/>
        <location filename="../GUI/spot-on-b.cc" line="4687"/>
        <location filename="../GUI/spot-on-b.cc" line="4703"/>
        <location filename="../GUI/spot-on-b.cc" line="4723"/>
        <location filename="../GUI/spot-on-b.cc" line="4733"/>
        <location filename="../GUI/spot-on-c.cc" line="170"/>
        <location filename="../GUI/spot-on-c.cc" line="973"/>
        <location filename="../GUI/spot-on-c.cc" line="1500"/>
        <location filename="../GUI/spot-on-c.cc" line="1510"/>
        <location filename="../GUI/spot-on-c.cc" line="1559"/>
        <location filename="../GUI/spot-on-c.cc" line="1626"/>
        <location filename="../GUI/spot-on-c.cc" line="1636"/>
        <location filename="../GUI/spot-on-c.cc" line="2187"/>
        <location filename="../GUI/spot-on-c.cc" line="2285"/>
        <location filename="../GUI/spot-on-c.cc" line="2736"/>
        <location filename="../GUI/spot-on-c.cc" line="2905"/>
        <location filename="../GUI/spot-on-c.cc" line="2997"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="855"/>
        <location filename="../GUI/spot-on-a.cc" line="4884"/>
        <source>Not connected to the kernel. Is the kernel active?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2439"/>
        <source>Status: %1
SSL Key Size: %2
Local IP: %3 Local Port: %4 Scope ID: %5
External IP: %6
Connections: %7
Echo Mode: %8
Use Accounts: %9
Transport: %10
Share Address: %11
Orientation: %12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2583"/>
        <location filename="../GUI/spot-on-a.cc" line="2585"/>
        <source>Unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3074"/>
        <source>The sticky feature enables an indefinite lifetime for a neighbor.
If not checked, the neighbor will be terminated after some internal timer expires.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3978"/>
        <source>The passphrases must contain at least sixteen characters each.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4011"/>
        <location filename="../GUI/spot-on-b.cc" line="547"/>
        <location filename="../GUI/spot-on-b.cc" line="1437"/>
        <location filename="../GUI/spot-on-b.cc" line="1461"/>
        <location filename="../GUI/spot-on-b.cc" line="1494"/>
        <location filename="../GUI/spot-on-b.cc" line="1521"/>
        <location filename="../GUI/spot-on-b.cc" line="1868"/>
        <location filename="../GUI/spot-on-b.cc" line="3261"/>
        <location filename="../GUI/spot-on-b.cc" line="4286"/>
        <location filename="../GUI/spot-on-c.cc" line="2201"/>
        <location filename="../GUI/spot-on-c.cc" line="2751"/>
        <location filename="../GUI/spot-on-c.cc" line="2850"/>
        <location filename="../GUI/spot-on-c.cc" line="3042"/>
        <location filename="../GUI/spot-on-c.cc" line="3567"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4031"/>
        <source>Generating derived keys. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4155"/>
        <source>Generating public key %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4201"/>
        <source>An error (%1) occurred with spoton_crypt::derivedKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4611"/>
        <location filename="../GUI/spot-on-a.cc" line="4738"/>
        <location filename="../GUI/spot-on-a.cc" line="4820"/>
        <location filename="../GUI/spot-on-c.cc" line="2325"/>
        <location filename="../GUI/spot-on-c.cc" line="2359"/>
        <location filename="../GUI/spot-on-c.cc" line="2545"/>
        <source>&amp;Remove participant(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4866"/>
        <source>Connected insecurely to the kernel on port %1 from local port %2. Communications between the interface and the kernel have been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5437"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5439"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5441"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="140"/>
        <location filename="../GUI/spot-on-a.cc" line="143"/>
        <source>Spot-On was configured without libGeoIP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="149"/>
        <location filename="../GUI/spot-on-a.cc" line="152"/>
        <source>Spot-On was configured without libphoton.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="857"/>
        <location filename="../GUI/spot-on-a.cc" line="2755"/>
        <source>Listeners are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="858"/>
        <location filename="../GUI/spot-on-a.cc" line="3383"/>
        <source>Neighbors are offline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="876"/>
        <source>Copy &amp;All Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4664"/>
        <location filename="../GUI/spot-on-c.cc" line="2431"/>
        <source>Share &amp;URL Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1492"/>
        <source>Preparing databases. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="178"/>
        <location filename="../GUI/spot-on-a.cc" line="179"/>
        <source>SCTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="863"/>
        <source>Copy &amp;Chat Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="866"/>
        <source>Copy &amp;E-Mail Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="869"/>
        <source>Copy &amp;Rosetta Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="872"/>
        <source>Copy &amp;URL Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1552"/>
        <source>Generating SSL data for listener. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1838"/>
        <source>Unable to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1843"/>
        <source>An error (%1) occurred while attempting to add the specified listener. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2220"/>
        <source>Unable to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2225"/>
        <source>An error (%1) occurred while attempting to add the specified neighbor. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2425"/>
        <location filename="../GUI/spot-on-a.cc" line="2664"/>
        <location filename="../GUI/spot-on-a.cc" line="2917"/>
        <location filename="../GUI/spot-on-a.cc" line="2945"/>
        <location filename="../GUI/spot-on-a.cc" line="3127"/>
        <location filename="../GUI/spot-on-a.cc" line="3220"/>
        <location filename="../GUI/spot-on-a.cc" line="5466"/>
        <location filename="../GUI/spot-on-b.cc" line="2710"/>
        <location filename="../GUI/spot-on-b.cc" line="2746"/>
        <location filename="../GUI/spot-on-b.cc" line="2830"/>
        <location filename="../GUI/spot-on-b.cc" line="2846"/>
        <location filename="../GUI/spot-on-c.cc" line="244"/>
        <location filename="../GUI/spot-on-c.cc" line="263"/>
        <location filename="../GUI/spot-on-c.cc" line="1120"/>
        <location filename="../GUI/spot-on-c.cc" line="1251"/>
        <location filename="../GUI/spot-on-c.cc" line="1253"/>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2748"/>
        <source>There is (are) %1 active listener(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="2949"/>
        <source>UUID: %1
Status: %2
SSL Key Size: %3
Local IP: %4 Local Port: %5
External IP: %6
Country: %7 Remote IP: %8 Remote Port: %9 Scope ID: %10
Proxy Hostname: %11 Proxy Port: %12
Echo Mode: %13
Communications Mode: %14
Uptime: %15 Minutes
Allow Certificate Exceptions: %16
Bytes Read: %17
Bytes Written: %18
SSL Session Cipher: %19
Account Name: %20
Account Authenticated: %21
Transport: %22
Orientation: %23
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3375"/>
        <source>There is (are) %1 connected neighbor(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3562"/>
        <source>External IP: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3572"/>
        <source>Spot-On: Select GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3987"/>
        <source>The passphrases are not identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="3995"/>
        <source>Please provide a name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4078"/>
        <source>Re-encoding public key pair %1 of %2. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4117"/>
        <source>Would you like to generate public key pairs?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4149"/>
        <location filename="../GUI/spot-on-c.cc" line="2228"/>
        <source>Generating public key pairs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4219"/>
        <source>An error (%1) occurred with spoton_crypt::saltedPassphraseHash().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4378"/>
        <source>Your confidential information has been recorded. You are now ready to use the full power of Spot-On. Enjoy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4605"/>
        <location filename="../GUI/spot-on-c.cc" line="2353"/>
        <source>&amp;Copy keys to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4614"/>
        <location filename="../GUI/spot-on-a.cc" line="4741"/>
        <location filename="../GUI/spot-on-a.cc" line="4823"/>
        <location filename="../GUI/spot-on-c.cc" line="2328"/>
        <location filename="../GUI/spot-on-c.cc" line="2362"/>
        <location filename="../GUI/spot-on-c.cc" line="2548"/>
        <source>&amp;Rename participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4676"/>
        <location filename="../GUI/spot-on-c.cc" line="2443"/>
        <source>&amp;Reset Account Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4680"/>
        <location filename="../GUI/spot-on-c.cc" line="2447"/>
        <source>&amp;Reset Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4731"/>
        <location filename="../GUI/spot-on-c.cc" line="2318"/>
        <source>&amp;Generate random Gemini pair (AES-256 Key, SHA-512 Key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4759"/>
        <location filename="../GUI/spot-on-a.cc" line="4782"/>
        <location filename="../GUI/spot-on-c.cc" line="2488"/>
        <location filename="../GUI/spot-on-c.cc" line="2512"/>
        <source>&amp;Compute SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4858"/>
        <source>Connected securely to the kernel on port %1 from local port %2 via cipher %3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6368"/>
        <source>&lt;b&gt;Cert. Effective Date:&lt;/b&gt; %1&lt;br&gt;&lt;b&gt;Cert. Expiration Date:&lt;/b&gt; %2&lt;br&gt;&lt;b&gt;Cert. Issuer Organization:&lt;/b&gt; %3&lt;br&gt;&lt;b&gt;Cert. Issuer Common Name:&lt;/b&gt; %4&lt;br&gt;&lt;b&gt;Cert. Issuer Locality Name:&lt;/b&gt; %5&lt;br&gt;&lt;b&gt;Cert. Issuer Organizational Unit Name:&lt;/b&gt; %6&lt;br&gt;&lt;b&gt;Cert. Issuer Country Name:&lt;/b&gt; %7&lt;br&gt;&lt;b&gt;Cert. Issuer State or Province Name:&lt;/b&gt; %8&lt;br&gt;&lt;b&gt;Cert. Serial Number:&lt;/b&gt; %9&lt;br&gt;&lt;b&gt;Cert. Subject Organization:&lt;/b&gt; %10&lt;br&gt;&lt;b&gt;Cert. Subject Common Name:&lt;/b&gt; %11&lt;br&gt;&lt;b&gt;Cert. Subject Locality Name:&lt;/b&gt; %12&lt;br&gt;&lt;b&gt;Cert. Subject Organizational Unit Name:&lt;/b&gt; %13&lt;br&gt;&lt;b&gt;Cert. Subject Country Name:&lt;/b&gt; %14&lt;br&gt;&lt;b&gt;Cert. Subject State or Province Name:&lt;/b&gt; %15&lt;br&gt;&lt;b&gt;Cert. Version:&lt;/b&gt; %16&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6550"/>
        <source>Invalid neighbor OID. Please select a neighbor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6623"/>
        <source>The account name must be non-empty and the account password must contain at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6792"/>
        <location filename="../GUI/spot-on-a.cc" line="6903"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6883"/>
        <location filename="../GUI/spot-on-b.cc" line="2903"/>
        <location filename="../GUI/spot-on-c.cc" line="157"/>
        <source>A database error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="6913"/>
        <source>Invalid clipboard object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4631"/>
        <location filename="../GUI/spot-on-c.cc" line="2380"/>
        <source>Detach &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4633"/>
        <location filename="../GUI/spot-on-c.cc" line="2382"/>
        <source>Disconnect &amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4636"/>
        <location filename="../GUI/spot-on-c.cc" line="2385"/>
        <source>&amp;Publish Information (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4638"/>
        <location filename="../GUI/spot-on-c.cc" line="2387"/>
        <source>Publish &amp;All (Plaintext)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4673"/>
        <location filename="../GUI/spot-on-c.cc" line="2440"/>
        <source>&amp;Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4691"/>
        <location filename="../GUI/spot-on-c.cc" line="2458"/>
        <source>Delete All Non-Unique &amp;Blocked Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4693"/>
        <location filename="../GUI/spot-on-c.cc" line="2460"/>
        <source>Delete All Non-Unique &amp;UUIDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4696"/>
        <location filename="../GUI/spot-on-c.cc" line="2463"/>
        <source>B&amp;lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4698"/>
        <location filename="../GUI/spot-on-c.cc" line="2465"/>
        <source>U&amp;nblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4641"/>
        <location filename="../GUI/spot-on-a.cc" line="4701"/>
        <location filename="../GUI/spot-on-c.cc" line="2390"/>
        <location filename="../GUI/spot-on-c.cc" line="2468"/>
        <source>&amp;Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4643"/>
        <location filename="../GUI/spot-on-a.cc" line="4703"/>
        <location filename="../GUI/spot-on-c.cc" line="2392"/>
        <location filename="../GUI/spot-on-c.cc" line="2470"/>
        <source>&amp;Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4724"/>
        <location filename="../GUI/spot-on-c.cc" line="2311"/>
        <source>&amp;Call participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4600"/>
        <location filename="../GUI/spot-on-a.cc" line="4721"/>
        <location filename="../GUI/spot-on-a.cc" line="4814"/>
        <location filename="../GUI/spot-on-c.cc" line="2308"/>
        <location filename="../GUI/spot-on-c.cc" line="2348"/>
        <location filename="../GUI/spot-on-c.cc" line="2539"/>
        <source>&amp;Copy Repleo to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4654"/>
        <location filename="../GUI/spot-on-c.cc" line="2421"/>
        <source>Share &amp;Chat Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4659"/>
        <location filename="../GUI/spot-on-c.cc" line="2426"/>
        <source>Share &amp;E-Mail Public Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1527"/>
        <location filename="../GUI/spot-on-a.cc" line="1856"/>
        <location filename="../GUI/spot-on-a.cc" line="6537"/>
        <location filename="../GUI/spot-on-a.cc" line="6844"/>
        <location filename="../GUI/spot-on-b.cc" line="4059"/>
        <location filename="../GUI/spot-on-b.cc" line="4339"/>
        <location filename="../GUI/spot-on-b.cc" line="4444"/>
        <location filename="../GUI/spot-on-b.cc" line="4599"/>
        <location filename="../GUI/spot-on-b.cc" line="4704"/>
        <location filename="../GUI/spot-on-c.cc" line="97"/>
        <location filename="../GUI/spot-on-c.cc" line="814"/>
        <location filename="../GUI/spot-on-c.cc" line="1501"/>
        <location filename="../GUI/spot-on-c.cc" line="1627"/>
        <location filename="../GUI/spot-on-c.cc" line="2998"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4014"/>
        <source>Are you sure that you wish to replace the existing passphrase? Please note that URL data must be re-encoded via a separate tool. Please see the future Tools folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4208"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys() or spoton_crypt::reencodeKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4727"/>
        <location filename="../GUI/spot-on-c.cc" line="2314"/>
        <source>&amp;Terminate call.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4764"/>
        <location filename="../GUI/spot-on-a.cc" line="4787"/>
        <location filename="../GUI/spot-on-c.cc" line="2493"/>
        <location filename="../GUI/spot-on-c.cc" line="2516"/>
        <source>&amp;Copy File Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5443"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5445"/>
        <source>Friend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="5523"/>
        <location filename="../GUI/spot-on-a.cc" line="5580"/>
        <location filename="../GUI/spot-on-a.cc" line="5625"/>
        <source>User %1 requests your friendship.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4667"/>
        <location filename="../GUI/spot-on-c.cc" line="2434"/>
        <source>&amp;Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="1448"/>
        <location filename="../GUI/spot-on-a.cc" line="1452"/>
        <location filename="../GUI/spot-on-a.cc" line="1456"/>
        <source>Broadcast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4377"/>
        <location filename="../GUI/spot-on-b.cc" line="4576"/>
        <source>Spot-On: Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4114"/>
        <location filename="../GUI/spot-on-a.cc" line="4391"/>
        <source>Spot-On: Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4394"/>
        <source>Would you like the kernel to be activated?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4669"/>
        <location filename="../GUI/spot-on-c.cc" line="2436"/>
        <source>&amp;Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4626"/>
        <location filename="../GUI/spot-on-a.cc" line="4687"/>
        <location filename="../GUI/spot-on-a.cc" line="4753"/>
        <location filename="../GUI/spot-on-a.cc" line="4776"/>
        <location filename="../GUI/spot-on-c.cc" line="303"/>
        <location filename="../GUI/spot-on-c.cc" line="2375"/>
        <location filename="../GUI/spot-on-c.cc" line="2407"/>
        <location filename="../GUI/spot-on-c.cc" line="2454"/>
        <location filename="../GUI/spot-on-c.cc" line="2482"/>
        <location filename="../GUI/spot-on-c.cc" line="2507"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4628"/>
        <location filename="../GUI/spot-on-a.cc" line="4689"/>
        <location filename="../GUI/spot-on-a.cc" line="4755"/>
        <location filename="../GUI/spot-on-a.cc" line="4778"/>
        <location filename="../GUI/spot-on-c.cc" line="305"/>
        <location filename="../GUI/spot-on-c.cc" line="2377"/>
        <location filename="../GUI/spot-on-c.cc" line="2409"/>
        <location filename="../GUI/spot-on-c.cc" line="2456"/>
        <location filename="../GUI/spot-on-c.cc" line="2484"/>
        <location filename="../GUI/spot-on-c.cc" line="2509"/>
        <source>Delete &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4594"/>
        <location filename="../GUI/spot-on-a.cc" line="4715"/>
        <location filename="../GUI/spot-on-a.cc" line="4808"/>
        <location filename="../GUI/spot-on-c.cc" line="2302"/>
        <location filename="../GUI/spot-on-c.cc" line="2342"/>
        <location filename="../GUI/spot-on-c.cc" line="2533"/>
        <source>&amp;Add participant as friend.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="74"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="550"/>
        <location filename="../GUI/spot-on-b.cc" line="4289"/>
        <location filename="../GUI/spot-on-c.cc" line="3570"/>
        <source>Are you sure that you wish to remove the selected participant(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="800"/>
        <location filename="../GUI/spot-on-b.cc" line="805"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1388"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1413"/>
        <location filename="../GUI/spot-on-b.cc" line="1721"/>
        <source>Invalid key type. Expecting &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1440"/>
        <source>Unable to retrieve your %1 public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1464"/>
        <source>Unable to retrieve your %1 signature public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1798"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1593"/>
        <source>Invalid repleo. The repleo must start with either the letter R or the letter r.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1787"/>
        <source>Invalid public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="65"/>
        <location filename="../GUI/spot-on-b.cc" line="2128"/>
        <source>Please select at least one participant.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="50"/>
        <location filename="../GUI/spot-on-b.cc" line="3327"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="55"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1380"/>
        <location filename="../GUI/spot-on-b.cc" line="1585"/>
        <source>Empty key. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1399"/>
        <location filename="../GUI/spot-on-b.cc" line="1706"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1604"/>
        <location filename="../GUI/spot-on-b.cc" line="1654"/>
        <source>Irregular data. Expecting 3 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1639"/>
        <source>Asymmetric decryption failure. Are you attempting to add a repleo that you gathered?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1696"/>
        <source>Symmetric decryption failure. Serious!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1871"/>
        <source>Are you sure that you wish to reset Spot-On? All data will be lost. Forever.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2136"/>
        <source>Please compose an actual letter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2239"/>
        <source>Queued</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2626"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2629"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2631"/>
        <source>From/To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2892"/>
        <source>Spot-On: Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2892"/>
        <source>&amp;Goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4065"/>
        <source>Please provide a channel key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4071"/>
        <source>Please provide a hash key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4082"/>
        <source>Unable to compute a keyed hash from the channel key and channel type as an artificial salt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4434"/>
        <source>Unable to record the IP address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4628"/>
        <source>Please provide an account name and an account password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4633"/>
        <source>Please provide an account password that contains at least sixteen characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4573"/>
        <source>Empty cipher list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="45"/>
        <location filename="../GUI/spot-on-b.cc" line="3330"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1373"/>
        <location filename="../GUI/spot-on-b.cc" line="1578"/>
        <location filename="../GUI/spot-on-c.cc" line="2188"/>
        <source>Invalid spoton_crypt object(s). This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1476"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1497"/>
        <source>Invalid &apos;chat&apos;, &apos;email&apos;, &apos;rosetta&apos;, or &apos;url&apos; public key signature. Accept?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1524"/>
        <source>Invalid signature public key signature. Accept?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1677"/>
        <source>Unable to compute a keyed hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1685"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="1774"/>
        <source>You&apos;re attempting to add your own keys or Spot-On was not able to retrieve your keys for comparison.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2909"/>
        <source>The provided goldbug may be incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2916"/>
        <source>A severe memory issue occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2960"/>
        <source>&lt;b&gt;From:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2963"/>
        <source>&lt;b&gt;To:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2965"/>
        <location filename="../GUI/spot-on-b.cc" line="2993"/>
        <location filename="../GUI/spot-on-b.cc" line="3009"/>
        <source>&lt;b&gt;Subject:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2968"/>
        <location filename="../GUI/spot-on-b.cc" line="2996"/>
        <location filename="../GUI/spot-on-b.cc" line="3012"/>
        <source>&lt;b&gt;Sent: &lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2975"/>
        <location filename="../GUI/spot-on-b.cc" line="2981"/>
        <location filename="../GUI/spot-on-b.cc" line="2983"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2988"/>
        <source>&lt;b&gt;From:&lt;/b&gt; me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="2990"/>
        <source>&lt;b&gt;To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3003"/>
        <location filename="../GUI/spot-on-b.cc" line="3006"/>
        <source>&lt;b&gt;From/To:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3017"/>
        <location filename="../GUI/spot-on-b.cc" line="3023"/>
        <location filename="../GUI/spot-on-b.cc" line="3025"/>
        <location filename="../GUI/spot-on-b.cc" line="3078"/>
        <source>Deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3264"/>
        <source>Are you sure that you wish to empty the Trash folder?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="3904"/>
        <source>Re: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4225"/>
        <source>Generating SSL data for kernel socket. Please be patient.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4360"/>
        <location filename="../GUI/spot-on-b.cc" line="4464"/>
        <location filename="../GUI/spot-on-b.cc" line="4614"/>
        <location filename="../GUI/spot-on-b.cc" line="4724"/>
        <source>Invalid listener OID. Please select a listener.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4370"/>
        <source>Please provide an IP address or the keyword Any.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4482"/>
        <source>Please select an address to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4568"/>
        <source>The following ciphers were discovered. Please note that Spot-On may neglect discovered ciphers if the ciphers are not supported by Qt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4682"/>
        <source>A database error has occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="4734"/>
        <source>Please select an account to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-b.cc" line="5040"/>
        <source>Remote user %1 is requesting authentication credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-a.cc" line="4796"/>
        <location filename="../GUI/spot-on-c.cc" line="297"/>
        <location filename="../GUI/spot-on-c.cc" line="2401"/>
        <location filename="../GUI/spot-on-c.cc" line="2520"/>
        <source>Copy &amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="121"/>
        <source>Invalid magnet. Are you missing tokens?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="820"/>
        <source>Please select a file to transfer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="828"/>
        <source>The provided file cannot be accessed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2175"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2177"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2179"/>
        <location filename="../GUI/spot-on-c.cc" line="2278"/>
        <source>Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2181"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2204"/>
        <source>Are you sure that you wish to generate the selected key pair? The kernel will be deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2286"/>
        <source>An error (%1) occurred with spoton_crypt::generatePrivatePublicKeys().</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2691"/>
        <source>&lt;b&gt;Chat Key Pair:&lt;/b&gt; %1, &lt;b&gt;Chat Signature Key Pair:&lt;/b&gt; %2, &lt;b&gt;E-Mail Key Pair:&lt;/b&gt; %3, &lt;b&gt;E-Mail Signature Key Pair:&lt;/b&gt; %4, &lt;b&gt;Rosetta Key Pair:&lt;/b&gt; %5, &lt;b&gt;Rosetta Signature Key Pair:&lt;/b&gt; %6, &lt;b&gt;URL Key Pair:&lt;/b&gt; %7, &lt;b&gt;URL Signature Key Pair:&lt;/b&gt; %8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2737"/>
        <source>A deep failure occurred while gathering your public key pairs. Do you have public keys? Please inspect the Settings tab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2755"/>
        <source>The gathered public keys contain a lot (%1) of data. Are you sure that you wish to export the data?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2767"/>
        <source>Spot-On: Select Public Keys Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2814"/>
        <source>Spot-On: Select Public Keys Import File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2914"/>
        <source>Spot-On: Select Listeners Export File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3006"/>
        <source>Spot-On: Select Neighbors Import File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3649"/>
        <source>Spot-On: New Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="3649"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2778"/>
        <location filename="../GUI/spot-on-c.cc" line="2924"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1511"/>
        <source>Please provide a nova. Reach for the stars!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1560"/>
        <source>Unable to store the nova.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="1637"/>
        <source>Please select a nova to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2854"/>
        <location filename="../GUI/spot-on-c.cc" line="3046"/>
        <source>The import file contains a lot (%1) of data. Are you sure that you wish to process it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="2906"/>
        <source>Unable to export an empty listeners table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="847"/>
        <source>Please select at least one magnet.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="421"/>
        <source>Spot-On: Select StarBeam Destination Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="777"/>
        <source>Spot-On: Select StarBeam Transmit File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="957"/>
        <location filename="../GUI/spot-on-c.cc" line="960"/>
        <source>A database error (%1) occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-c.cc" line="963"/>
        <source>An error occurred within spoton_crypt.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_buzzpage</name>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="186"/>
        <source>Empty kernel socket.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="191"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="196"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="201"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="210"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="262"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="535"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="590"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="602"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="653"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="406"/>
        <source>&lt;i&gt;%1 has joined %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="439"/>
        <source>&lt;i&gt;%1 is now known as %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="501"/>
        <source>&lt;i&gt;%1 has left %2.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="536"/>
        <location filename="../GUI/spot-on-buzzpage.cc" line="603"/>
        <source>Invalid spoton_crypt object. This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="591"/>
        <source>An error occurred while attempting to save the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-buzzpage.cc" line="654"/>
        <source>An error occurred while attempting to remove the channel data. Please enable logging via the Log Viewer and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_chatwindow</name>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="60"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="62"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="214"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="219"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="229"/>
        <location filename="../GUI/spot-on-chatwindow.cc" line="234"/>
        <source>Spot-On: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="128"/>
        <source>Not connected to the kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="133"/>
        <source>The connection to the kernel is not encrypted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="138"/>
        <source>Please provide a real message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="149"/>
        <source>&lt;b&gt;me:&lt;/b&gt; </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-chatwindow.cc" line="193"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_logviewer</name>
    <message>
        <location filename="../UI/logviewer.ui" line="14"/>
        <source>Spot-On: Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="62"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="81"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="87"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="98"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="103"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/logviewer.ui" line="111"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_mainwindow</name>
    <message>
        <location filename="../UI/controlcenter.ui" line="167"/>
        <location filename="../UI/controlcenter.ui" line="306"/>
        <location filename="../UI/controlcenter.ui" line="486"/>
        <location filename="../UI/controlcenter.ui" line="871"/>
        <location filename="../UI/controlcenter.ui" line="3262"/>
        <location filename="../UI/controlcenter.ui" line="4592"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="110"/>
        <location filename="../UI/controlcenter.ui" line="539"/>
        <location filename="../UI/controlcenter.ui" line="1239"/>
        <location filename="../UI/controlcenter.ui" line="3579"/>
        <location filename="../UI/controlcenter.ui" line="5353"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="648"/>
        <location filename="../UI/controlcenter.ui" line="1211"/>
        <location filename="../UI/controlcenter.ui" line="5436"/>
        <source>public_key_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="811"/>
        <location filename="../UI/controlcenter.ui" line="1332"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1102"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2181"/>
        <location filename="../UI/controlcenter.ui" line="2250"/>
        <location filename="../UI/controlcenter.ui" line="3366"/>
        <location filename="../UI/controlcenter.ui" line="4806"/>
        <location filename="../UI/controlcenter.ui" line="5546"/>
        <location filename="../UI/controlcenter.ui" line="5669"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="913"/>
        <source>Retrieve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1268"/>
        <source>&amp;Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1351"/>
        <source>&amp;Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2271"/>
        <source>&amp;Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1625"/>
        <location filename="../UI/controlcenter.ui" line="2518"/>
        <source>Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1630"/>
        <location filename="../UI/controlcenter.ui" line="2523"/>
        <source>Local Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1640"/>
        <location filename="../UI/controlcenter.ui" line="2558"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4116"/>
        <source>Set Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5836"/>
        <source>Authenticate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2543"/>
        <source>Remote IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2548"/>
        <source>Remote Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2678"/>
        <source>Add Neighbor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2493"/>
        <source>Sticky</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1740"/>
        <location filename="../UI/controlcenter.ui" line="2772"/>
        <source>&amp;Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1787"/>
        <location filename="../UI/controlcenter.ui" line="2762"/>
        <location filename="../UI/controlcenter.ui" line="3033"/>
        <source>&amp;Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1813"/>
        <location filename="../UI/controlcenter.ui" line="2743"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1829"/>
        <location filename="../UI/controlcenter.ui" line="2788"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="764"/>
        <source>Artificial GET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="759"/>
        <source>Normal POST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2498"/>
        <source>UUID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1645"/>
        <location filename="../UI/controlcenter.ui" line="2528"/>
        <source>External IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="14"/>
        <source>Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="53"/>
        <source>&amp;Buzz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="138"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="97"/>
        <location filename="../UI/controlcenter.ui" line="526"/>
        <location filename="../UI/controlcenter.ui" line="2114"/>
        <location filename="../UI/controlcenter.ui" line="4164"/>
        <location filename="../UI/controlcenter.ui" line="5340"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="272"/>
        <location filename="../UI/controlcenter.ui" line="4657"/>
        <source>Hash &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="285"/>
        <source>Hash &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="311"/>
        <location filename="../UI/controlcenter.ui" line="4361"/>
        <source>Generate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="319"/>
        <source>Join</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="569"/>
        <source>Offline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="70"/>
        <source>Accept shared &amp;magnets.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="589"/>
        <location filename="../UI/controlcenter.ui" line="1246"/>
        <location filename="../UI/controlcenter.ui" line="1553"/>
        <location filename="../UI/controlcenter.ui" line="2288"/>
        <location filename="../UI/controlcenter.ui" line="4463"/>
        <location filename="../UI/controlcenter.ui" line="4892"/>
        <location filename="../UI/controlcenter.ui" line="4994"/>
        <location filename="../UI/controlcenter.ui" line="5377"/>
        <source>Context Menu Reflection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="658"/>
        <source>Last Status Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="739"/>
        <source>&amp;Preferred Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="832"/>
        <source>&amp;E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="884"/>
        <source>Empty Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="897"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="910"/>
        <source>Request e-mail from other participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="947"/>
        <source>&amp;Retrieve e-mail every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="964"/>
        <source>&amp;minutes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="993"/>
        <source>&amp;Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1014"/>
        <source>Inbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1019"/>
        <source>Sent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1024"/>
        <source>Trash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1055"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1087"/>
        <location filename="../UI/controlcenter.ui" line="1456"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1092"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1107"/>
        <source>goldbug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1112"/>
        <source>message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1117"/>
        <source>message_digest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1122"/>
        <source>receiver_sender_hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1148"/>
        <source>&amp;Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1371"/>
        <source>&amp;To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1361"/>
        <source>&amp;Optional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="146"/>
        <source>&amp;Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="156"/>
        <source>Demagnetize the link.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="202"/>
        <source>Channel &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="248"/>
        <source>Channel &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="400"/>
        <location filename="../UI/controlcenter.ui" line="940"/>
        <location filename="../UI/controlcenter.ui" line="5297"/>
        <source>Accept shared public &amp;keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="417"/>
        <source>Broadcast odd messages at odd times.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="420"/>
        <source>&amp;Impersonate me.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="868"/>
        <source>Clear the contents of the current view.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1286"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle the e-mail in an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1289"/>
        <source>Gold Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1319"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The kernel is responsible for signing messages. Because messages are queued, please avoid toggling this checkbox until queued messages have been processed by the kernel.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1322"/>
        <source>Sign &amp;messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1385"/>
        <source>&amp;C/O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1461"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1479"/>
        <source>Data that has not been processed in more than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1496"/>
        <source>&amp;day(s) will be purged automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1685"/>
        <location filename="../UI/controlcenter.ui" line="2628"/>
        <source>Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1690"/>
        <source>Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1700"/>
        <location filename="../UI/controlcenter.ui" line="2001"/>
        <location filename="../UI/controlcenter.ui" line="2633"/>
        <location filename="../UI/controlcenter.ui" line="2953"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1725"/>
        <source>The uniqueness of a listener is defined by the local IP, the local port, the scope ID, and the transport.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1836"/>
        <location filename="../UI/controlcenter.ui" line="2805"/>
        <source>&amp;Transport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1850"/>
        <location filename="../UI/controlcenter.ui" line="2824"/>
        <source>TCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1855"/>
        <location filename="../UI/controlcenter.ui" line="2829"/>
        <source>UDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1868"/>
        <source>&amp;Share Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1973"/>
        <location filename="../UI/controlcenter.ui" line="2407"/>
        <location filename="../UI/controlcenter.ui" line="2938"/>
        <location filename="../UI/controlcenter.ui" line="3886"/>
        <location filename="../UI/controlcenter.ui" line="4246"/>
        <source>8192</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2012"/>
        <location filename="../UI/controlcenter.ui" line="2964"/>
        <source>Packet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2017"/>
        <location filename="../UI/controlcenter.ui" line="2969"/>
        <source>Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2218"/>
        <source>The keyword Any is supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2298"/>
        <source>Copy Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2305"/>
        <source>Share Buzz Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2643"/>
        <source>certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2690"/>
        <source>The uniqueness of a neighbor is defined by the proxy hostname, the proxy port, the remote IP, the remote port, the scope ID, and the transport.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3460"/>
        <location filename="../UI/controlcenter.ui" line="3620"/>
        <source>&amp;External IP Retrieval Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3477"/>
        <location filename="../UI/controlcenter.ui" line="3637"/>
        <source>30 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3482"/>
        <location filename="../UI/controlcenter.ui" line="3642"/>
        <source>60 Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3487"/>
        <location filename="../UI/controlcenter.ui" line="3647"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3495"/>
        <location filename="../UI/controlcenter.ui" line="3655"/>
        <source>&amp;Secure Memory Pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3725"/>
        <source>&amp;Force Registration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3817"/>
        <source>&amp;Congestion Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3894"/>
        <source>If enabled, messages that are deciphered correctly will be echoed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3924"/>
        <location filename="../UI/controlcenter.ui" line="3949"/>
        <source>Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3983"/>
        <source>Statistic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3988"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4194"/>
        <source>Chat Key Pair: 0, Chat Signature Key Pair: 0, E-Mail Key Pair: 0, E-Mail Signature Key Pair: 0, Rosetta Key Pair: 0, Rosetta Signature Key Pair: 0, URL Key Pair: 0, URL Signature Key Pair: 0.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4209"/>
        <source>If checked, new key pairs will be generated whenever the passphrase is updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4324"/>
        <source>Key &amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4338"/>
        <source>Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4343"/>
        <source>E-Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4348"/>
        <source>Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4353"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4406"/>
        <source>S&amp;tarBeam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4446"/>
        <source>&amp;Magnets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4510"/>
        <source>One-Time-Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4545"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4578"/>
        <source>&amp;Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4677"/>
        <source>Encryption &amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4743"/>
        <source>&amp;Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4816"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4839"/>
        <source>&amp;Destination Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4939"/>
        <source>Percent Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4949"/>
        <location filename="../UI/controlcenter.ui" line="5070"/>
        <source>Total Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4959"/>
        <location filename="../UI/controlcenter.ui" line="5090"/>
        <source>SHA-1 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5085"/>
        <source>Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5195"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Bundle each pulse in an additional layer of AES-256 encryption. Do remember to notify all recipients of the key.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5926"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://sourceforge.net/p/spot-on/code/HEAD/tree/branches/Documentation/RELEASE-NOTES&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Version 0.09.01&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6137"/>
        <source>&amp;Import Neighbors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6025"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6101"/>
        <source>&amp;Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6106"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6109"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6114"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6117"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6122"/>
        <source>&amp;Export Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6127"/>
        <source>&amp;Import Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6132"/>
        <source>&amp;Export Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4602"/>
        <source>Generate Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4607"/>
        <source>Generate MAC Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4036"/>
        <location filename="../UI/controlcenter.ui" line="4690"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4019"/>
        <location filename="../UI/controlcenter.ui" line="4647"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5242"/>
        <source> Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4977"/>
        <source>&amp;Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1526"/>
        <source>&amp;Listeners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1620"/>
        <location filename="../UI/controlcenter.ui" line="2508"/>
        <source>SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1650"/>
        <location filename="../UI/controlcenter.ui" line="2533"/>
        <source>External Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1665"/>
        <location filename="../UI/controlcenter.ui" line="2583"/>
        <source>Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1670"/>
        <source>Use Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1713"/>
        <source>Add Listener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1924"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Record the current external IP address in the listener&apos;s certificate. Please do not use this option if you have a dynamic IP address.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1927"/>
        <source>&amp;Ip Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1934"/>
        <source>&amp;Permanent Certificate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1944"/>
        <location filename="../UI/controlcenter.ui" line="2375"/>
        <location filename="../UI/controlcenter.ui" line="2909"/>
        <location filename="../UI/controlcenter.ui" line="3854"/>
        <source>&amp;SSL Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1958"/>
        <location filename="../UI/controlcenter.ui" line="2392"/>
        <location filename="../UI/controlcenter.ui" line="2923"/>
        <location filename="../UI/controlcenter.ui" line="3871"/>
        <location filename="../UI/controlcenter.ui" line="4226"/>
        <source>2048</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1968"/>
        <location filename="../UI/controlcenter.ui" line="2402"/>
        <location filename="../UI/controlcenter.ui" line="2933"/>
        <location filename="../UI/controlcenter.ui" line="3881"/>
        <location filename="../UI/controlcenter.ui" line="4236"/>
        <source>4096</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1897"/>
        <location filename="../UI/controlcenter.ui" line="2859"/>
        <source>&amp;Echo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="124"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1911"/>
        <location filename="../UI/controlcenter.ui" line="2873"/>
        <source>Full Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1916"/>
        <location filename="../UI/controlcenter.ui" line="2878"/>
        <source>Half Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2087"/>
        <source>Accounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2147"/>
        <source>&amp;One-Time Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2342"/>
        <source>Select this option if you would like to accept and connect to published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2352"/>
        <source>Select this option if you would like to accept published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2513"/>
        <source>Status Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2538"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2563"/>
        <source>Proxy Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2568"/>
        <source>Proxy Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2593"/>
        <source>Allow Certificate Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2603"/>
        <source>Bytes Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2608"/>
        <source>Bytes Written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2613"/>
        <source>SSL Session Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2618"/>
        <source>Account Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2623"/>
        <source>Account Authenticated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2638"/>
        <source>is_encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2795"/>
        <source>Dynamic DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2798"/>
        <source>&amp;DDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2886"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spot-On will record peer certificates during initial connections. Subsequent connections will cause Spot-On to inspect peer certificates. If there are discrepancies between recorded certificates and transmitted certificates, Spot-On will sever the connections. Enable this option if you would like Spot-On to ignore discrepancies.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2899"/>
        <source>&amp;Require SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3535"/>
        <source>&amp;GeoIP Data Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3586"/>
        <source>Display a list of ciphers produced by the provided SSL Control String.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3589"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3809"/>
        <source>randomized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4212"/>
        <source>&amp;Key Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4259"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4276"/>
        <location filename="../UI/controlcenter.ui" line="4311"/>
        <source>ElGamal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4281"/>
        <location filename="../UI/controlcenter.ui" line="4316"/>
        <source>RSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4289"/>
        <source>&amp;Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4306"/>
        <source>DSA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4759"/>
        <source>Novas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5055"/>
        <source>Paused</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4944"/>
        <location filename="../UI/controlcenter.ui" line="5065"/>
        <source>Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5121"/>
        <source>Rewind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5232"/>
        <source>&amp;Pulse Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5448"/>
        <source>URL Polarizers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6077"/>
        <source>&amp;East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6088"/>
        <source>&amp;North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6096"/>
        <source>&amp;West</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3010"/>
        <source>&amp;Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="235"/>
        <source>&amp;Salt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1560"/>
        <source>Periodically p&amp;ublish plaintext information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2992"/>
        <source>Pro&amp;xy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3020"/>
        <source>&amp;Hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3043"/>
        <source>&amp;Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2124"/>
        <location filename="../UI/controlcenter.ui" line="3056"/>
        <source>&amp;Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2193"/>
        <source>Allowed IP Addresses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3085"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3090"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3095"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3292"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3332"/>
        <source>Fetch!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3386"/>
        <source>&lt; 1 .. 1 &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3419"/>
        <source>S&amp;ettings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3603"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3745"/>
        <source>PID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3758"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3695"/>
        <source>Spot-On-Kernel &amp;Executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4182"/>
        <source>Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4140"/>
        <source>P&amp;assphrase Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6048"/>
        <source>Nuvola</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6056"/>
        <source>Nouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6064"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6069"/>
        <source>&amp;Reset Spot-On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6061"/>
        <source>&amp;Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1610"/>
        <location filename="../UI/controlcenter.ui" line="3732"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="653"/>
        <location filename="../UI/controlcenter.ui" line="1097"/>
        <location filename="../UI/controlcenter.ui" line="1615"/>
        <location filename="../UI/controlcenter.ui" line="2503"/>
        <location filename="../UI/controlcenter.ui" line="5075"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1635"/>
        <location filename="../UI/controlcenter.ui" line="2553"/>
        <source>Scope ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1753"/>
        <location filename="../UI/controlcenter.ui" line="2717"/>
        <source>&amp;IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="559"/>
        <source>Away</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="564"/>
        <source>Busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="574"/>
        <source>Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="633"/>
        <location filename="../UI/controlcenter.ui" line="1196"/>
        <location filename="../UI/controlcenter.ui" line="5421"/>
        <source>Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="643"/>
        <location filename="../UI/controlcenter.ui" line="1206"/>
        <location filename="../UI/controlcenter.ui" line="5431"/>
        <source>neighbor_oid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1660"/>
        <source>Max. Conn.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1767"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2038"/>
        <location filename="../UI/controlcenter.ui" line="2174"/>
        <location filename="../UI/controlcenter.ui" line="2243"/>
        <location filename="../UI/controlcenter.ui" line="3169"/>
        <location filename="../UI/controlcenter.ui" line="3255"/>
        <location filename="../UI/controlcenter.ui" line="4733"/>
        <location filename="../UI/controlcenter.ui" line="4799"/>
        <location filename="../UI/controlcenter.ui" line="5539"/>
        <location filename="../UI/controlcenter.ui" line="5662"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2144"/>
        <source>If checked, the account will be removed after a client successfully authenticates itself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2295"/>
        <source>Copy your public key pairs to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2896"/>
        <source>Require encrypted connections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3194"/>
        <source>Add Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3211"/>
        <source>&amp;Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3221"/>
        <source>&amp;Repleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3409"/>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3722"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please enable this option if you would like to force kernel registration. By forcing kernel registration, an existing kernel process that Spot-On is aware of will be deactivated. You may wish to use this option if a kernel was not deactivated properly.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3768"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3548"/>
        <location filename="../UI/controlcenter.ui" line="3708"/>
        <location filename="../UI/controlcenter.ui" line="4852"/>
        <location filename="../UI/controlcenter.ui" line="5225"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4053"/>
        <source>Iteration &amp;Count</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1963"/>
        <location filename="../UI/controlcenter.ui" line="2397"/>
        <location filename="../UI/controlcenter.ui" line="2928"/>
        <location filename="../UI/controlcenter.ui" line="3876"/>
        <location filename="../UI/controlcenter.ui" line="4231"/>
        <source>3072</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4241"/>
        <source>7680</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4251"/>
        <source>15360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4076"/>
        <source>Salt &amp;Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4123"/>
        <location filename="../UI/controlcenter.ui" line="5819"/>
        <source>P&amp;assphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4150"/>
        <source>Minimum of 16 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5464"/>
        <source>&amp;Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5494"/>
        <location filename="../UI/controlcenter.ui" line="5617"/>
        <source>&amp;Accept List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5504"/>
        <location filename="../UI/controlcenter.ui" line="5627"/>
        <source>&amp;Deny List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5587"/>
        <source>&amp;Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="339"/>
        <source>&amp;Chat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="172"/>
        <source>Demagnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="177"/>
        <source>Magnetize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="182"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="187"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="215"/>
        <source>&amp;Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="407"/>
        <location filename="../UI/controlcenter.ui" line="1045"/>
        <source>&amp;Accept only signed messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="427"/>
        <source>&amp;Sign messages.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="456"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="509"/>
        <location filename="../UI/controlcenter.ui" line="5323"/>
        <source>Participants</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="638"/>
        <location filename="../UI/controlcenter.ui" line="1127"/>
        <location filename="../UI/controlcenter.ui" line="1201"/>
        <location filename="../UI/controlcenter.ui" line="1705"/>
        <location filename="../UI/controlcenter.ui" line="2648"/>
        <location filename="../UI/controlcenter.ui" line="4520"/>
        <location filename="../UI/controlcenter.ui" line="4964"/>
        <location filename="../UI/controlcenter.ui" line="5095"/>
        <location filename="../UI/controlcenter.ui" line="5179"/>
        <location filename="../UI/controlcenter.ui" line="5426"/>
        <source>OID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="663"/>
        <source>Gemini AES-256 Encryption Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="668"/>
        <source>Gemini SHA-512 Hash Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="681"/>
        <source>&amp;Hide offline participants.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1309"/>
        <source>&amp;Save copies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1221"/>
        <source>&amp;From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1402"/>
        <source>&amp;Enable C/O service.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1409"/>
        <source>&amp;Reject messages without signatures.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1466"/>
        <source>Recipient SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1695"/>
        <location filename="../UI/controlcenter.ui" line="2598"/>
        <source>Certificate SHA-512 Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4515"/>
        <location filename="../UI/controlcenter.ui" line="5174"/>
        <source>Magnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4597"/>
        <source>Generate Key Pair</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4866"/>
        <source>&amp;Maximum Mosaic Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4876"/>
        <source> MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5060"/>
        <source>Percent Transmitted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4954"/>
        <location filename="../UI/controlcenter.ui" line="5080"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5258"/>
        <source>Transmit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1655"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2345"/>
        <source>&amp;Accept published listeners (connected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2355"/>
        <source>&amp;Accept published listeners (disconnected).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2365"/>
        <source>&amp;Ignore published listeners.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2435"/>
        <source>&amp;Keep only user-defined neighbors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1675"/>
        <location filename="../UI/controlcenter.ui" line="2573"/>
        <source>Max. Buffer Size (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="1680"/>
        <location filename="../UI/controlcenter.ui" line="2578"/>
        <source>Max. Content Length (Bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2588"/>
        <source>Uptime (Seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="2889"/>
        <source>&amp;Allow Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3795"/>
        <source>&amp;Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3840"/>
        <source>&amp;Log Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3847"/>
        <source>&amp;Scrambler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3897"/>
        <source>S&amp;uper Echo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="4002"/>
        <source>Passphrase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3562"/>
        <source>&amp;SSL Control String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="3572"/>
        <source>HIGH:!aNULL:!eNULL:!3DES:!EXPORT:@STRENGTH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5143"/>
        <source>Add Mosaic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5198"/>
        <source>Nova</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5280"/>
        <source>&amp;URLs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5770"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&amp;quot;The Dalmatian is a breed of dog, noted for its unique black- or brown-spotted coat. This dog is often used as a rescue dog, guardian, athletic partner, and, especially today, the Dalmatian remains most often an active, well-loved family member.&amp;quot; - Wikipedia.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5895"/>
        <source>Spot-On Graphical User Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5942"/>
        <source>Build Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5212"/>
        <location filename="../UI/controlcenter.ui" line="5982"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5990"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="5994"/>
        <source>&amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6001"/>
        <source>&amp;Tab Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6013"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6037"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/controlcenter.ui" line="6040"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>spoton_rosetta</name>
    <message>
        <location filename="../UI/rosetta.ui" line="14"/>
        <source>Spot-On: Rosetta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="36"/>
        <source>&amp;Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="49"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="72"/>
        <source>Copy &amp;Rosetta Public Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="81"/>
        <source>New Contact</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="118"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="125"/>
        <location filename="../UI/rosetta.ui" line="296"/>
        <location filename="../UI/rosetta.ui" line="343"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="169"/>
        <source>&amp;Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="155"/>
        <source>&amp;Decrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="69"/>
        <source>Copy your public key pairs to the clipboard buffer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="179"/>
        <source>&amp;Participant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="196"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="222"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="239"/>
        <source>&amp;Cipher Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="256"/>
        <source>&amp;Hash Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="273"/>
        <source>&amp;Sign message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="313"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="384"/>
        <source>Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="391"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="410"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="416"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="427"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="432"/>
        <source>&amp;Empty Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="440"/>
        <source>E&amp;nable Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="445"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="448"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="453"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/rosetta.ui" line="456"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="302"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="313"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="321"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="332"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="345"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="406"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="418"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="433"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="637"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="739"/>
        <source>Spot-On: Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="314"/>
        <source>Empty key. Really?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="322"/>
        <source>Invalid key. The key must start with either the letter K or the letter k.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="333"/>
        <source>Irregular data. Expecting 6 entries, received %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="346"/>
        <source>Invalid key type. Expecting &apos;rosetta&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="407"/>
        <source>You&apos;re attempting to add your own &apos;%1&apos; keys. Please do not do this!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="419"/>
        <source>Invalid &apos;rosetta&apos; public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="434"/>
        <source>Invalid signature public key signature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="526"/>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="549"/>
        <source>Invalid item data. This is a serious flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="555"/>
        <source>Please provide an actual message!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="564"/>
        <source>The method spoton_crypt::cipherKeyLength() failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="624"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="732"/>
        <source>A serious cryptographic error occurred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="658"/>
        <source>Empty input data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="689"/>
        <source>The computed hash does not match the provided hash.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="723"/>
        <source>The message was not signed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="727"/>
        <source>Invalid signature. Perhaps your contacts are not current.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="369"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="392"/>
        <location filename="../GUI/spot-on-rosetta.cc" line="756"/>
        <source>Spot-On: Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="303"/>
        <source>Invalid spoton_crypt object(s). This is a fatal flaw.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="372"/>
        <source>Unable to retrieve your %1 public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="395"/>
        <source>Unable to retrieve your %1 signature public key for comparison. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../GUI/spot-on-rosetta.cc" line="759"/>
        <source>Are you sure that you wish to remove the selected contact?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>statusbar</name>
    <message>
        <location filename="../UI/statusbar.ui" line="89"/>
        <source>Buzz activity detected!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="102"/>
        <source>You have received a new message.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="118"/>
        <source>New e-mail has arrived!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/statusbar.ui" line="147"/>
        <source>Log Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
